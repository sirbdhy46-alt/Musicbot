import sharp from "sharp";
import axios from "axios";
import fs from "node:fs";
import path from "node:path";
import gifenc from "gifenc";
const { GIFEncoder, quantize, applyPalette } = gifenc as unknown as {
  GIFEncoder: typeof import("gifenc").GIFEncoder;
  quantize: typeof import("gifenc").quantize;
  applyPalette: typeof import("gifenc").applyPalette;
};
import { AttachmentBuilder, type Guild } from "discord.js";

function escapeXml(s: string): string {
  return s.replace(/[<>&"']/g, (c) =>
    c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === "&" ? "&amp;" : c === '"' ? "&quot;" : "&apos;",
  );
}

// ─── Romantic cursive fonts (embedded via @font-face) ────────────────────────
const FONT_DIR = path.resolve("assets/fonts");
let DANCING_B64: string | null = null;
let GREAT_VIBES_B64: string | null = null;

function loadFonts() {
  if (DANCING_B64 === null) {
    try {
      DANCING_B64 = fs.readFileSync(path.join(FONT_DIR, "DancingScript.ttf")).toString("base64");
    } catch {
      DANCING_B64 = "";
    }
  }
  if (GREAT_VIBES_B64 === null) {
    try {
      GREAT_VIBES_B64 = fs.readFileSync(path.join(FONT_DIR, "GreatVibes-Regular.ttf")).toString("base64");
    } catch {
      GREAT_VIBES_B64 = "";
    }
  }
}

function fontStyleBlock(): string {
  loadFonts();
  return `<style><![CDATA[
    @font-face {
      font-family: 'AetherCursive';
      src: url('data:font/ttf;base64,${GREAT_VIBES_B64}') format('truetype');
      font-weight: 400;
    }
    @font-face {
      font-family: 'AetherScript';
      src: url('data:font/ttf;base64,${DANCING_B64}') format('truetype');
      font-weight: 700;
    }
  ]]></style>`;
}

// ─── Theme system ────────────────────────────────────────────────────────────
export interface Theme {
  id: string;
  name: string;
  bg: [string, string, string];
  accent: string;
  accentRgb: [number, number, number];
  glow: string;
  petal: string;
  vibe: string;
}

export const THEMES: Theme[] = [
  {
    id: "blood-rose",
    name: "blood rose",
    bg: ["rgb(8,4,8)", "rgb(28,8,16)", "rgb(70,12,28)"],
    accent: "rgb(220,38,38)",
    accentRgb: [220, 38, 38],
    glow: "rgba(220,38,38,0.6)",
    petal: "#ff6b6b",
    vibe: "stay forever",
  },
  {
    id: "midnight-velvet",
    name: "midnight velvet",
    bg: ["rgb(6,4,18)", "rgb(20,10,40)", "rgb(60,16,80)"],
    accent: "rgb(196,80,200)",
    accentRgb: [196, 80, 200],
    glow: "rgba(196,80,200,0.55)",
    petal: "#e0a3ff",
    vibe: "lost in violet",
  },
  {
    id: "cherry-bloom",
    name: "cherry bloom",
    bg: ["rgb(20,4,8)", "rgb(50,8,18)", "rgb(120,18,40)"],
    accent: "rgb(255,90,120)",
    accentRgb: [255, 90, 120],
    glow: "rgba(255,90,120,0.55)",
    petal: "#ffd1dc",
    vibe: "petals & poison",
  },
  {
    id: "obsidian-gold",
    name: "obsidian gold",
    bg: ["rgb(4,4,6)", "rgb(20,18,8)", "rgb(50,40,8)"],
    accent: "rgb(240,180,60)",
    accentRgb: [240, 180, 60],
    glow: "rgba(240,180,60,0.55)",
    petal: "#fff4b8",
    vibe: "gilded silence",
  },
  {
    id: "ember-mist",
    name: "ember mist",
    bg: ["rgb(8,8,8)", "rgb(40,18,12)", "rgb(120,38,18)"],
    accent: "rgb(255,120,60)",
    accentRgb: [255, 120, 60],
    glow: "rgba(255,120,60,0.55)",
    petal: "#ffb38a",
    vibe: "smoke & fire",
  },
  {
    id: "rose-noir",
    name: "rose noir",
    bg: ["rgb(6,4,10)", "rgb(18,8,22)", "rgb(50,12,40)"],
    accent: "rgb(225,80,140)",
    accentRgb: [225, 80, 140],
    glow: "rgba(225,80,140,0.55)",
    petal: "#ffc1d6",
    vibe: "kiss the dark",
  },
  {
    id: "frost-crimson",
    name: "frost crimson",
    bg: ["rgb(4,8,14)", "rgb(8,18,32)", "rgb(40,16,40)"],
    accent: "rgb(255,80,120)",
    accentRgb: [255, 80, 120],
    glow: "rgba(255,120,180,0.55)",
    petal: "#a8d8ff",
    vibe: "frozen heart",
  },
  {
    id: "dark-amethyst",
    name: "dark amethyst",
    bg: ["rgb(8,4,18)", "rgb(30,12,50)", "rgb(70,30,120)"],
    accent: "rgb(180,120,255)",
    accentRgb: [180, 120, 255],
    glow: "rgba(180,120,255,0.55)",
    petal: "#dabaff",
    vibe: "dreaming awake",
  },
  {
    id: "ivory-blood",
    name: "ivory blood",
    bg: ["rgb(20,16,18)", "rgb(40,28,30)", "rgb(80,20,28)"],
    accent: "rgb(245,235,220)",
    accentRgb: [245, 235, 220],
    glow: "rgba(255,200,200,0.55)",
    petal: "#fff0e0",
    vibe: "porcelain hearts",
  },
  {
    id: "neon-sin",
    name: "neon sin",
    bg: ["rgb(4,4,12)", "rgb(20,4,30)", "rgb(80,8,80)"],
    accent: "rgb(255,40,180)",
    accentRgb: [255, 40, 180],
    glow: "rgba(255,40,180,0.7)",
    petal: "#ff8fd9",
    vibe: "electric romance",
  },
];

export function getTheme(id?: string | null): Theme {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}

// ─── Color roles ─────────────────────────────────────────────────────────────
export interface ColorRole {
  name: string;
  hex: string;
  rgb: [number, number, number];
}

export const COLOR_ROLES: ColorRole[] = [
  { name: "✦ crimson", hex: "#dc143c", rgb: [220, 20, 60] },
  { name: "✦ scarlet", hex: "#ff2400", rgb: [255, 36, 0] },
  { name: "✦ ember", hex: "#ff5722", rgb: [255, 87, 34] },
  { name: "✦ amber", hex: "#ffb300", rgb: [255, 179, 0] },
  { name: "✦ gold", hex: "#ffd700", rgb: [255, 215, 0] },
  { name: "✦ lime", hex: "#a4e057", rgb: [164, 224, 87] },
  { name: "✦ emerald", hex: "#10b981", rgb: [16, 185, 129] },
  { name: "✦ teal", hex: "#14b8a6", rgb: [20, 184, 166] },
  { name: "✦ cyan", hex: "#06b6d4", rgb: [6, 182, 212] },
  { name: "✦ sky", hex: "#3b82f6", rgb: [59, 130, 246] },
  { name: "✦ sapphire", hex: "#1e40af", rgb: [30, 64, 175] },
  { name: "✦ indigo", hex: "#6366f1", rgb: [99, 102, 241] },
  { name: "✦ violet", hex: "#8b5cf6", rgb: [139, 92, 246] },
  { name: "✦ magenta", hex: "#d946ef", rgb: [217, 70, 239] },
  { name: "✦ pink", hex: "#ec4899", rgb: [236, 72, 153] },
  { name: "✦ rose", hex: "#f43f5e", rgb: [244, 63, 94] },
  { name: "✦ pearl", hex: "#f5f5f5", rgb: [245, 245, 245] },
  { name: "✦ slate", hex: "#475569", rgb: [71, 85, 105] },
];

export function colorRoleHexToInt(hex: string): number {
  return parseInt(hex.replace("#", ""), 16);
}

// ─── Server icon download (cached per session) ───────────────────────────────
const iconCache = new Map<string, Buffer>();
async function fetchGuildIcon(guild: Guild): Promise<Buffer | null> {
  const url = guild.iconURL({ size: 256, extension: "png" });
  if (!url) return null;
  if (iconCache.has(url)) return iconCache.get(url)!;
  try {
    const res = await axios.get<ArrayBuffer>(url, { responseType: "arraybuffer", timeout: 8000 });
    const buf = Buffer.from(res.data);
    iconCache.set(url, buf);
    return buf;
  } catch {
    return null;
  }
}

function iconClipDef(id: string, x: number, y: number, size: number): string {
  return `<clipPath id="${id}"><circle cx="${x + size / 2}" cy="${y + size / 2}" r="${size / 2}" /></clipPath>`;
}

function iconImage(b64: string | null, x: number, y: number, size: number, clipId: string, accent: string): string {
  if (!b64) {
    return `<circle cx="${x + size / 2}" cy="${y + size / 2}" r="${size / 2}" fill="${accent}" opacity="0.3" />
            <text x="${x + size / 2}" y="${y + size / 2 + 14}" text-anchor="middle"
              font-family="Impact" font-size="${size * 0.5}" font-weight="900" fill="white">A</text>`;
  }
  return `<image href="data:image/png;base64,${b64}" x="${x}" y="${y}" width="${size}" height="${size}"
            clip-path="url(#${clipId})" preserveAspectRatio="xMidYMid slice" />
          <circle cx="${x + size / 2}" cy="${y + size / 2}" r="${size / 2}" fill="none"
            stroke="${accent}" stroke-width="3" />`;
}

// Decorative romantic flourishes
function flourishes(W: number, H: number, theme: Theme, density = 1): string {
  const parts: string[] = [];
  const n = Math.round(8 * density);
  for (let i = 0; i < n; i++) {
    const x = (i + 0.5) * (W / n) + (i % 2 ? -20 : 20);
    const y = i % 2 ? 30 : H - 30;
    const size = 14 + (i % 3) * 4;
    parts.push(`<text x="${x}" y="${y}" text-anchor="middle" font-family="serif"
      font-size="${size}" fill="${theme.accent}" opacity="${0.25 + (i % 3) * 0.1}">❀</text>`);
  }
  // Corner roses
  parts.push(`<text x="40" y="50" font-family="serif" font-size="28" fill="${theme.accent}" opacity="0.4">❦</text>`);
  parts.push(`<text x="${W - 40}" y="50" text-anchor="end" font-family="serif" font-size="28" fill="${theme.accent}" opacity="0.4">❦</text>`);
  parts.push(`<text x="40" y="${H - 30}" font-family="serif" font-size="28" fill="${theme.accent}" opacity="0.4">❦</text>`);
  parts.push(`<text x="${W - 40}" y="${H - 30}" text-anchor="end" font-family="serif" font-size="28" fill="${theme.accent}" opacity="0.4">❦</text>`);
  return parts.join("\n");
}

// ─── Color palette image (bigger, romantic) ──────────────────────────────────
export async function makeColorPaletteImage(themeId?: string): Promise<AttachmentBuilder> {
  const theme = getTheme(themeId);
  const W = 1400;
  const COLS = 6;
  const ROWS = Math.ceil(COLOR_ROLES.length / COLS);
  const PAD = 50;
  const HEADER = 220;
  const CELL_W = (W - PAD * 2) / COLS;
  const CELL_H = 180;
  const H = HEADER + PAD + ROWS * CELL_H + 100;

  const swatches = COLOR_ROLES.map((c, idx) => {
    const col = idx % COLS;
    const row = Math.floor(idx / COLS);
    const x = PAD + col * CELL_W + 14;
    const y = HEADER + PAD + row * CELL_H;
    const w = CELL_W - 28;
    const h = CELL_H - 30;
    return `
      <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="14" fill="${c.hex}" />
      <rect x="${x}" y="${y}" width="${w}" height="${h}" rx="14" fill="none"
        stroke="rgba(255,255,255,0.22)" stroke-width="1.5" />
      <text x="${x + w / 2}" y="${y + h - 24}" text-anchor="middle"
            font-family="AetherScript, 'Brush Script MT', cursive" font-weight="700"
            font-size="26" fill="rgba(0,0,0,0.7)">${escapeXml(c.name.replace("✦ ", ""))}</text>
      <text x="${x + w / 2}" y="${y + h + 18}" text-anchor="middle"
            font-family="'Courier New', monospace"
            font-size="13" fill="rgba(220,220,230,0.75)">${c.hex.toUpperCase()}</text>
    `;
  }).join("");

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${fontStyleBlock()}
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${theme.bg[0]}" />
        <stop offset="55%" stop-color="${theme.bg[1]}" />
        <stop offset="100%" stop-color="${theme.bg[2]}" />
      </linearGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="3.2" /></filter>
    </defs>
    <rect width="${W}" height="${H}" fill="url(#bg)" />
    <rect x="14" y="14" width="${W - 28}" height="${H - 28}" rx="12" fill="none"
      stroke="${theme.glow}" stroke-width="2" />
    ${flourishes(W, H, theme, 1.4)}
    <text x="${W / 2}" y="100" text-anchor="middle"
      font-family="AetherCursive, 'Brush Script MT', cursive"
      font-size="92" fill="${theme.accent}" filter="url(#glow)">choose your hue</text>
    <text x="${W / 2}" y="100" text-anchor="middle"
      font-family="AetherCursive, 'Brush Script MT', cursive"
      font-size="92" fill="white">choose your hue</text>
    <text x="${W / 2}" y="148" text-anchor="middle"
      font-family="serif" letter-spacing="10"
      font-size="14" fill="rgba(220,220,230,0.65)">— ${escapeXml(theme.vibe.toUpperCase())} —</text>
    ${swatches}
    <text x="${W / 2}" y="${H - 38}" text-anchor="middle"
      font-family="AetherScript, cursive"
      font-size="22" fill="rgba(220,220,230,0.7)">click a button below to claim your color</text>
    <text x="${W - 28}" y="${H - 18}" text-anchor="end"
      font-family="serif" letter-spacing="3"
      font-size="11" fill="rgba(160,160,180,0.65)">AETHER · ${escapeXml(theme.name.toUpperCase())}</text>
  </svg>`;

  const buf = await sharp(Buffer.from(svg)).png().toBuffer();
  return new AttachmentBuilder(buf, { name: "color-palette.png" });
}

// ─── Server info image (bigger, romantic, with server icon) ──────────────────
export async function makeServerInfoImage(guild: Guild, themeId?: string): Promise<AttachmentBuilder> {
  const theme = getTheme(themeId);
  const W = 1400;
  const H = 600;
  const name = guild.name.length > 26 ? guild.name.slice(0, 24) + "…" : guild.name;
  const memberCount = guild.memberCount;
  const channelCount = guild.channels.cache.size;
  const roleCount = guild.roles.cache.size;
  const boostTier = guild.premiumTier;
  const boostCount = guild.premiumSubscriptionCount ?? 0;
  const created = guild.createdAt.toISOString().slice(0, 10);

  const iconBuf = await fetchGuildIcon(guild);
  const iconB64 = iconBuf ? iconBuf.toString("base64") : null;
  const ICON_SIZE = 200;
  const ICON_X = 80;
  const ICON_Y = 200;

  const stat = (label: string, value: string, x: number) => `
    <text x="${x}" y="490" font-family="serif" letter-spacing="4"
      font-size="14" fill="rgba(220,220,230,0.7)">${escapeXml(label.toUpperCase())}</text>
    <text x="${x}" y="540" font-family="AetherScript, cursive"
      font-size="48" font-weight="700" fill="white">${escapeXml(value)}</text>
  `;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${fontStyleBlock()}
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${theme.bg[0]}" />
        <stop offset="55%" stop-color="${theme.bg[1]}" />
        <stop offset="100%" stop-color="${theme.bg[2]}" />
      </linearGradient>
      <linearGradient id="line" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stop-color="rgba(${theme.accentRgb.join(",")},0)" />
        <stop offset="50%" stop-color="rgba(${theme.accentRgb.join(",")},1)" />
        <stop offset="100%" stop-color="rgba(${theme.accentRgb.join(",")},0)" />
      </linearGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="4" /></filter>
      ${iconClipDef("icon-clip", ICON_X, ICON_Y, ICON_SIZE)}
    </defs>
    <rect width="${W}" height="${H}" fill="url(#bg)" />
    <rect x="16" y="16" width="${W - 32}" height="${H - 32}" rx="14" fill="none"
      stroke="${theme.glow}" stroke-width="2" />
    ${flourishes(W, H, theme, 1.4)}

    ${iconImage(iconB64, ICON_X, ICON_Y, ICON_SIZE, "icon-clip", theme.accent)}

    <text x="320" y="160" font-family="serif" letter-spacing="8"
      font-size="18" fill="rgba(${theme.accentRgb.join(",")},0.95)">— WELCOME TO —</text>
    <text x="320" y="290" font-family="AetherCursive, 'Brush Script MT', cursive"
      font-size="120" fill="${theme.accent}" filter="url(#glow)">${escapeXml(name)}</text>
    <text x="320" y="290" font-family="AetherCursive, 'Brush Script MT', cursive"
      font-size="120" fill="white">${escapeXml(name)}</text>
    <text x="320" y="340" font-family="AetherScript, cursive"
      font-size="34" fill="rgba(220,220,230,0.85)">${escapeXml(theme.vibe)}</text>

    <rect x="80" y="430" width="${W - 160}" height="3" fill="url(#line)" />

    ${stat("members", memberCount.toLocaleString(), 80)}
    ${stat("channels", channelCount.toString(), 360)}
    ${stat("roles", roleCount.toString(), 600)}
    ${stat("boosts", `${boostCount} · T${boostTier}`, 800)}
    ${stat("since", created, 1100)}

    <text x="${W - 28}" y="${H - 22}" text-anchor="end"
      font-family="serif" letter-spacing="3"
      font-size="11" fill="rgba(160,160,180,0.65)">AETHER · ${escapeXml(theme.name.toUpperCase())}</text>
  </svg>`;

  const buf = await sharp(Buffer.from(svg)).png().toBuffer();
  return new AttachmentBuilder(buf, { name: "server-info.png" });
}

// ─── Animated welcome GIF (bigger, romantic, themed, with server icon) ───────
async function frameToRGBA(svg: string, w: number, h: number): Promise<Uint8Array> {
  const { data } = await sharp(Buffer.from(svg))
    .resize(w, h)
    .raw()
    .ensureAlpha()
    .toBuffer({ resolveWithObject: true });
  return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
}

export async function makeAnimatedWelcomeGif(guild: Guild, themeId?: string): Promise<AttachmentBuilder> {
  const theme = getTheme(themeId);
  const W = 800;
  const H = 320;
  const FRAMES = 14;
  const name = guild.name.length > 22 ? guild.name.slice(0, 20) + "…" : guild.name;
  const enc = GIFEncoder();

  const iconBuf = await fetchGuildIcon(guild);
  const iconB64 = iconBuf ? iconBuf.toString("base64") : null;
  const ICON_SIZE = 130;
  const ICON_X = 50;
  const ICON_Y = (H - ICON_SIZE) / 2;

  for (let f = 0; f < FRAMES; f++) {
    const t = f / FRAMES;
    const pulse = 0.6 + 0.4 * Math.sin(t * Math.PI * 2);
    const sweepX = -240 + (W + 480) * t;
    const blur = 2 + pulse * 5;
    const heart1Y = 30 + Math.sin(t * Math.PI * 2) * 6;
    const heart2Y = H - 50 + Math.cos(t * Math.PI * 2) * 6;

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
      ${fontStyleBlock()}
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="${theme.bg[0]}" />
          <stop offset="55%" stop-color="${theme.bg[1]}" />
          <stop offset="100%" stop-color="${theme.bg[2]}" />
        </linearGradient>
        <linearGradient id="sweep" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="rgba(255,255,255,0)" />
          <stop offset="50%" stop-color="rgba(${theme.accentRgb.join(",")},0.5)" />
          <stop offset="100%" stop-color="rgba(255,255,255,0)" />
        </linearGradient>
        <filter id="glow"><feGaussianBlur stdDeviation="${blur}" /></filter>
        ${iconClipDef("ic", ICON_X, ICON_Y, ICON_SIZE)}
      </defs>
      <rect width="${W}" height="${H}" fill="url(#bg)" />
      <rect x="8" y="8" width="${W - 16}" height="${H - 16}" rx="10" fill="none"
        stroke="rgba(${theme.accentRgb.join(",")},${0.4 + pulse * 0.4})" stroke-width="2" />
      <rect x="${sweepX}" y="0" width="240" height="${H}" fill="url(#sweep)" opacity="0.8" />

      ${iconImage(iconB64, ICON_X, ICON_Y, ICON_SIZE, "ic", theme.accent)}

      <text x="${ICON_X + ICON_SIZE + 40}" y="90" font-family="serif" letter-spacing="6"
        font-size="14" fill="rgba(${theme.accentRgb.join(",")},${0.75 + pulse * 0.25})">— WELCOME TO —</text>
      <text x="${ICON_X + ICON_SIZE + 40}" y="190" font-family="AetherCursive, cursive"
        font-size="76" fill="${theme.accent}" filter="url(#glow)">${escapeXml(name)}</text>
      <text x="${ICON_X + ICON_SIZE + 40}" y="190" font-family="AetherCursive, cursive"
        font-size="76" fill="white">${escapeXml(name)}</text>
      <text x="${ICON_X + ICON_SIZE + 40}" y="240" font-family="AetherScript, cursive"
        font-size="28" fill="rgba(220,220,230,0.8)">${escapeXml(theme.vibe)}</text>
      <text x="${ICON_X + ICON_SIZE + 40}" y="280" font-family="serif" letter-spacing="4"
        font-size="11" fill="rgba(220,220,230,0.55)">THE GATES ARE OPEN · STAY AWHILE</text>

      <text x="${W - 60}" y="${heart1Y + 30}" font-family="serif" font-size="22"
        fill="${theme.accent}" opacity="${0.5 + pulse * 0.4}">❀</text>
      <text x="${W - 100}" y="${heart2Y}" font-family="serif" font-size="18"
        fill="${theme.petal}" opacity="${0.4 + pulse * 0.4}">❦</text>

      <text x="${W - 14}" y="${H - 12}" text-anchor="end"
        font-family="serif" letter-spacing="2"
        font-size="9" fill="rgba(160,160,180,0.55)">AETHER · ${escapeXml(theme.name.toUpperCase())}</text>
    </svg>`;

    const rgba = await frameToRGBA(svg, W, H);
    const palette = quantize(rgba, 96);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, W, H, { palette, delay: 90 });
  }
  enc.finish();
  const buf = Buffer.from(enc.bytes());
  return new AttachmentBuilder(buf, { name: "welcome.gif" });
}

// ─── Section banner (bigger, romantic) ───────────────────────────────────────
export async function makeCategoryBanner(
  category: string,
  subtitle: string,
  themeId?: string,
): Promise<AttachmentBuilder> {
  const theme = getTheme(themeId);
  const W = 1200;
  const H = 280;
  const cleaned = category.replace(/^[^\p{L}\p{N}]+/u, "").trim().toLowerCase();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${fontStyleBlock()}
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${theme.bg[0]}" />
        <stop offset="55%" stop-color="${theme.bg[1]}" />
        <stop offset="100%" stop-color="${theme.bg[2]}" />
      </linearGradient>
      <linearGradient id="line" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stop-color="rgba(${theme.accentRgb.join(",")},0)" />
        <stop offset="50%" stop-color="rgba(${theme.accentRgb.join(",")},1)" />
        <stop offset="100%" stop-color="rgba(${theme.accentRgb.join(",")},0)" />
      </linearGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="3" /></filter>
    </defs>
    <rect width="${W}" height="${H}" fill="url(#bg)" />
    <rect x="12" y="12" width="${W - 24}" height="${H - 24}" rx="12" fill="none"
      stroke="${theme.glow}" stroke-width="2" />
    ${flourishes(W, H, theme, 1)}
    <text x="60" y="100" font-family="serif" letter-spacing="6"
      font-size="14" fill="rgba(${theme.accentRgb.join(",")},0.95)">— SECTION —</text>
    <text x="60" y="200" font-family="AetherCursive, cursive"
      font-size="92" fill="${theme.accent}" filter="url(#glow)">${escapeXml(cleaned)}</text>
    <text x="60" y="200" font-family="AetherCursive, cursive"
      font-size="92" fill="white">${escapeXml(cleaned)}</text>
    <rect x="60" y="220" width="${W - 120}" height="2" fill="url(#line)" />
    <text x="60" y="250" font-family="AetherScript, cursive"
      font-size="22" fill="rgba(220,220,230,0.8)">${escapeXml(subtitle)}</text>
    <text x="${W - 28}" y="${H - 22}" text-anchor="end"
      font-family="serif" letter-spacing="3"
      font-size="11" fill="rgba(160,160,180,0.65)">AETHER · ${escapeXml(theme.name.toUpperCase())}</text>
  </svg>`;
  const buf = await sharp(Buffer.from(svg)).png().toBuffer();
  const safeName = cleaned.replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "section";
  return new AttachmentBuilder(buf, { name: `banner-${safeName}.png` });
}

// ─── Selfrole panel image (bigger, romantic) ─────────────────────────────────
export async function makeSelfrolePanelImage(
  panelName: string,
  themeId?: string,
): Promise<AttachmentBuilder> {
  const theme = getTheme(themeId);
  const W = 1200;
  const H = 320;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    ${fontStyleBlock()}
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${theme.bg[0]}" />
        <stop offset="55%" stop-color="${theme.bg[1]}" />
        <stop offset="100%" stop-color="${theme.bg[2]}" />
      </linearGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="3.4" /></filter>
    </defs>
    <rect width="${W}" height="${H}" fill="url(#bg)" />
    <rect x="14" y="14" width="${W - 28}" height="${H - 28}" rx="14" fill="none"
      stroke="${theme.glow}" stroke-width="2" />
    ${flourishes(W, H, theme, 1.2)}
    <text x="${W / 2}" y="120" text-anchor="middle"
      font-family="serif" letter-spacing="8"
      font-size="14" fill="rgba(${theme.accentRgb.join(",")},0.95)">— SELF-ROLES —</text>
    <text x="${W / 2}" y="220" text-anchor="middle"
      font-family="AetherCursive, cursive"
      font-size="100" fill="${theme.accent}" filter="url(#glow)">${escapeXml(panelName)}</text>
    <text x="${W / 2}" y="220" text-anchor="middle"
      font-family="AetherCursive, cursive"
      font-size="100" fill="white">${escapeXml(panelName)}</text>
    <text x="${W / 2}" y="270" text-anchor="middle"
      font-family="AetherScript, cursive"
      font-size="24" fill="rgba(220,220,230,0.8)">tap a button below to claim · tap again to remove</text>
  </svg>`;
  const buf = await sharp(Buffer.from(svg)).png().toBuffer();
  return new AttachmentBuilder(buf, { name: "selfrole-panel.png" });
}
