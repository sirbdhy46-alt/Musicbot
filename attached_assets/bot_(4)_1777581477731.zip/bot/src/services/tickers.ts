import type { Client } from "discord.js";
import { ChannelType } from "discord.js";
import { db } from "../db.ts";
import { computeCount, renderTemplate } from "../commands/counter.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { emoji } from "./emojis.ts";

export function startTickers(client: Client) {
  // counters: every 10 minutes
  setInterval(async () => {
    const rows = db
      .prepare("SELECT guild_id, channel_id, type, template FROM counters")
      .all() as { guild_id: string; channel_id: string; type: string; template: string }[];
    for (const r of rows) {
      const g = client.guilds.cache.get(r.guild_id);
      if (!g) continue;
      const ch = g.channels.cache.get(r.channel_id);
      if (!ch) {
        db.prepare("DELETE FROM counters WHERE guild_id = ? AND channel_id = ?").run(r.guild_id, r.channel_id);
        continue;
      }
      const newName = renderTemplate(r.template, computeCount(g, r.type));
      if (ch.name !== newName) {
        await ch.setName(newName, "counter update").catch(() => null);
      }
    }
  }, 10 * 60_000);

  // reminders: every 15 seconds
  setInterval(async () => {
    const due = db
      .prepare("SELECT id, user_id, channel_id, message FROM reminders WHERE fired = 0 AND remind_at <= ? LIMIT 50")
      .all(Date.now()) as { id: number; user_id: string; channel_id: string; message: string }[];
    for (const r of due) {
      try {
        const ch = await client.channels.fetch(r.channel_id).catch(() => null);
        if (ch?.isTextBased() && "send" in ch) {
          await ch.send({
            content: `<@${r.user_id}>`,
            embeds: [
              aetherEmbed({
                description: `# ${emoji("aether_moon")} reminder\n> ${r.message}`,
                color: COLORS.info,
              }),
            ],
          });
        } else {
          const u = await client.users.fetch(r.user_id).catch(() => null);
          await u?.send({
            embeds: [
              aetherEmbed({
                description: `# ${emoji("aether_moon")} reminder\n> ${r.message}`,
                color: COLORS.info,
              }),
            ],
          });
        }
      } catch {
        /* ignore */
      }
      db.prepare("UPDATE reminders SET fired = 1 WHERE id = ?").run(r.id);
    }
  }, 15_000);

  // bump reminders: every minute
  setInterval(async () => {
    const due = db
      .prepare("SELECT guild_id, channel_id, role_id, next_bump FROM bump_config WHERE next_bump > 0 AND next_bump <= ?")
      .all(Date.now()) as { guild_id: string; channel_id: string | null; role_id: string | null; next_bump: number }[];
    for (const r of due) {
      const g = client.guilds.cache.get(r.guild_id);
      if (!g || !r.channel_id) continue;
      const ch = g.channels.cache.get(r.channel_id);
      if (ch?.type === ChannelType.GuildText) {
        await ch
          .send({
            content: r.role_id ? `<@&${r.role_id}>` : undefined,
            embeds: [
              aetherEmbed({
                description: `# ${emoji("aether_arrow")} bump time\n> run \`/bump\` to push the server up the disboard list`,
                color: COLORS.accent,
              }),
            ],
          })
          .catch(() => null);
      }
      db.prepare("UPDATE bump_config SET next_bump = 0 WHERE guild_id = ?").run(r.guild_id);
    }
  }, 60_000);

  // populate invite cache for all guilds (after ready)
  (async () => {
    const { refreshInviteCache } = await import("../events/guildMember.ts");
    for (const g of client.guilds.cache.values()) {
      try {
        const fresh = await g.invites.fetch();
        await refreshInviteCache(g.id, fresh);
      } catch {
        /* perms */
      }
    }
  })();
}
