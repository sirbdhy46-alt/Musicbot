import type { Guild } from "discord.js";
import { db } from "../db.ts";
import { aetherEmbed } from "../embeds.ts";

export async function logEvent(
  guild: Guild,
  event: string,
  opts: { description: string; color?: number; title?: string },
) {
  const cfg = db
    .prepare("SELECT channel_id, events FROM log_config WHERE guild_id = ?")
    .get(guild.id) as { channel_id: string | null; events: string } | undefined;
  if (!cfg?.channel_id) return;
  const events: string[] = JSON.parse(cfg.events);
  if (!events.includes(event)) return;
  const ch = await guild.channels.fetch(cfg.channel_id).catch(() => null);
  if (!ch?.isTextBased() || !("send" in ch)) return;
  await ch
    .send({
      embeds: [
        aetherEmbed({
          title: opts.title ?? `# ${event}`,
          description: opts.description,
          color: opts.color,
          timestamp: true,
        }),
      ],
    })
    .catch(() => null);
}
