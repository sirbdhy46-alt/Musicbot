import { ChannelType, type Guild } from "discord.js";
import type { ServerTemplate } from "../data/templates.ts";

export interface ApplyResult {
  rolesCreated: number;
  channelsCreated: number;
  errors: string[];
}

export async function applyTemplate(
  guild: Guild,
  template: ServerTemplate,
  options: { wipe?: boolean } = {},
): Promise<ApplyResult> {
  const result: ApplyResult = { rolesCreated: 0, channelsCreated: 0, errors: [] };

  if (options.wipe) {
    for (const ch of guild.channels.cache.values()) {
      if ("deletable" in ch && ch.deletable && ch.id !== guild.systemChannelId) {
        await ch.delete("template wipe").catch(() => null);
      }
    }
    for (const r of guild.roles.cache.values()) {
      if (
        r.editable &&
        !r.managed &&
        r.id !== guild.id /* @everyone */
      ) {
        await r.delete("template wipe").catch(() => null);
      }
    }
  }

  // create roles top-down (later = lower position)
  for (const role of template.roles) {
    try {
      const existing = guild.roles.cache.find((r) => r.name === role.name);
      if (!existing) {
        await guild.roles.create({
          name: role.name,
          color: role.color,
          hoist: role.hoist,
          mentionable: role.mentionable,
          reason: "template apply",
        });
        result.rolesCreated++;
      }
    } catch (e) {
      result.errors.push(`role ${role.name}: ${(e as Error).message}`);
    }
  }

  for (const cat of template.categories) {
    try {
      const category = await guild.channels.create({
        name: cat.name,
        type: ChannelType.GuildCategory,
        reason: "template apply",
      });
      for (const ch of cat.channels) {
        const type =
          ch.type === "voice"
            ? ChannelType.GuildVoice
            : ch.type === "stage"
              ? ChannelType.GuildStageVoice
              : ch.type === "forum"
                ? ChannelType.GuildForum
                : ChannelType.GuildText;
        await guild.channels.create({
          name: ch.name,
          type,
          parent: category.id,
          topic: ch.topic,
          reason: "template apply",
        });
        result.channelsCreated++;
      }
    } catch (e) {
      result.errors.push(`category ${cat.name}: ${(e as Error).message}`);
    }
  }

  return result;
}
