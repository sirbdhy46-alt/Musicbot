import type { GuildMember } from "discord.js";
import { db } from "../db.ts";
import { aetherEmbed } from "../embeds.ts";
import { searchGif } from "./giphy.ts";
import { makeAnimatedWelcomeGif } from "./setupImages.ts";
import { COLORS } from "../config.ts";

export function formatTemplate(tpl: string, member: GuildMember): string {
  const g = member.guild;
  return tpl
    .replaceAll("{user}", `<@${member.id}>`)
    .replaceAll("{user.name}", member.user.username)
    .replaceAll("{user.tag}", member.user.tag)
    .replaceAll("{user.id}", member.id)
    .replaceAll("{user.mention}", `<@${member.id}>`)
    .replaceAll("{server}", g.name)
    .replaceAll("{server.name}", g.name)
    .replaceAll("{member.count}", String(g.memberCount))
    .replaceAll("{server.members}", String(g.memberCount));
}

export async function handleJoin(member: GuildMember): Promise<void> {
  const cfg = db
    .prepare(
      "SELECT welcome_enabled, welcome_channel, welcome_message, welcome_gif_query FROM guild_config WHERE guild_id = ?",
    )
    .get(member.guild.id) as
    | {
        welcome_enabled: number;
        welcome_channel: string | null;
        welcome_message: string | null;
        welcome_gif_query: string | null;
      }
    | undefined;
  if (!cfg?.welcome_enabled || !cfg.welcome_channel) return;
  const channel = await member.guild.channels.fetch(cfg.welcome_channel).catch(() => null);
  if (!channel?.isTextBased()) return;

  const msg = formatTemplate(
    cfg.welcome_message ??
      "# welcome {user.name}\n> you are member **{member.count}** of **{server}**\n> stay awhile.",
    member,
  );

  const banner = await makeAnimatedWelcomeGif(member.guild).catch(() => null);
  let imageUrl: string | undefined;
  let files: { attachment: Buffer; name: string }[] | undefined;
  if (banner) {
    imageUrl = "attachment://welcome.gif";
    const raw = banner.attachment as Buffer;
    files = [{ attachment: raw, name: "welcome.gif" }];
  } else {
    const gif = await searchGif(cfg.welcome_gif_query ?? "welcome aesthetic");
    imageUrl = gif ?? undefined;
  }

  const embed = aetherEmbed({
    description: msg,
    color: COLORS.accent,
    thumbnail: member.user.displayAvatarURL({ size: 256 }),
    image: imageUrl,
    timestamp: true,
  });
  await channel
    .send({ content: `<@${member.id}>`, embeds: [embed], ...(files ? { files } : {}) })
    .catch(() => null);
}

export async function handleLeave(member: GuildMember): Promise<void> {
  const cfg = db
    .prepare(
      "SELECT leave_enabled, leave_channel, leave_message FROM guild_config WHERE guild_id = ?",
    )
    .get(member.guild.id) as
    | {
        leave_enabled: number;
        leave_channel: string | null;
        leave_message: string | null;
      }
    | undefined;
  if (!cfg?.leave_enabled || !cfg.leave_channel) return;
  const channel = await member.guild.channels.fetch(cfg.leave_channel).catch(() => null);
  if (!channel?.isTextBased()) return;
  const msg = formatTemplate(
    cfg.leave_message ?? "> **{user.tag}** drifted away from **{server}**",
    member,
  );
  const embed = aetherEmbed({
    description: msg,
    color: COLORS.ghost,
    thumbnail: member.user.displayAvatarURL({ size: 256 }),
    timestamp: true,
  });
  await channel.send({ embeds: [embed] }).catch(() => null);
}
