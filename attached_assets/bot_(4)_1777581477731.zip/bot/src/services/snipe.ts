import type { Message, PartialMessage } from "discord.js";

interface Snipe {
  authorId: string;
  authorTag: string;
  authorAvatar: string;
  content: string;
  attachments: string[];
  ts: number;
}

const deleted = new Map<string, Snipe[]>();
const edited = new Map<string, { before: string; after: string; authorTag: string; authorAvatar: string; ts: number }[]>();

const MAX = 10;

export function recordDelete(message: Message | PartialMessage) {
  if (!message.channel || !message.author) return;
  const arr = deleted.get(message.channel.id) ?? [];
  arr.unshift({
    authorId: message.author.id,
    authorTag: message.author.tag ?? message.author.username ?? "unknown",
    authorAvatar: message.author.displayAvatarURL?.() ?? "",
    content: message.content ?? "",
    attachments: [...(message.attachments?.values() ?? [])].map((a) => a.url),
    ts: Date.now(),
  });
  deleted.set(message.channel.id, arr.slice(0, MAX));
}

export function recordEdit(oldMessage: Message | PartialMessage, newMessage: Message) {
  if (!newMessage.channel || !newMessage.author || newMessage.author.bot) return;
  const arr = edited.get(newMessage.channel.id) ?? [];
  arr.unshift({
    before: oldMessage.content ?? "",
    after: newMessage.content,
    authorTag: newMessage.author.tag,
    authorAvatar: newMessage.author.displayAvatarURL(),
    ts: Date.now(),
  });
  edited.set(newMessage.channel.id, arr.slice(0, MAX));
}

export function getDeleted(channelId: string, index = 0): Snipe | undefined {
  return deleted.get(channelId)?.[index];
}

export function getEdited(channelId: string, index = 0) {
  return edited.get(channelId)?.[index];
}
