import { db } from "../db.ts";
import type { GuildMember, Message } from "discord.js";

const COOLDOWN_MS = 60_000;

export function xpForLevel(level: number): number {
  return 5 * level * level + 50 * level + 100;
}

export function totalXpForLevel(level: number): number {
  let total = 0;
  for (let i = 0; i < level; i++) total += xpForLevel(i);
  return total;
}

export function levelFromXp(xp: number): { level: number; remaining: number; needed: number } {
  let level = 0;
  let remaining = xp;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level++;
  }
  return { level, remaining, needed: xpForLevel(level) };
}

export function getUserLevel(guildId: string, userId: string) {
  const row = db
    .prepare("SELECT * FROM user_levels WHERE guild_id = ? AND user_id = ?")
    .get(guildId, userId) as
    | { guild_id: string; user_id: string; xp: number; level: number; last_msg: number }
    | undefined;
  return row ?? { guild_id: guildId, user_id: userId, xp: 0, level: 0, last_msg: 0 };
}

export function addXp(
  guildId: string,
  userId: string,
  amount: number,
): { leveledUp: boolean; level: number; xp: number } {
  const cur = getUserLevel(guildId, userId);
  const newXp = cur.xp + amount;
  const { level } = levelFromXp(newXp);
  const leveledUp = level > cur.level;
  db.prepare(
    `INSERT INTO user_levels (guild_id, user_id, xp, level, last_msg)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = excluded.xp, level = excluded.level, last_msg = excluded.last_msg`,
  ).run(guildId, userId, newXp, level, Date.now());
  return { leveledUp, level, xp: newXp };
}

export async function handleMessageXp(message: Message): Promise<{
  leveledUp: boolean;
  level: number;
} | null> {
  if (!message.guild || message.author.bot) return null;
  const cur = getUserLevel(message.guild.id, message.author.id);
  if (Date.now() - cur.last_msg < COOLDOWN_MS) return null;
  const gain = 15 + Math.floor(Math.random() * 11);
  const result = addXp(message.guild.id, message.author.id, gain);
  return { leveledUp: result.leveledUp, level: result.level };
}

export function getLeaderboard(guildId: string, limit = 10) {
  return db
    .prepare(
      "SELECT user_id, xp, level FROM user_levels WHERE guild_id = ? ORDER BY xp DESC LIMIT ?",
    )
    .all(guildId, limit) as { user_id: string; xp: number; level: number }[];
}

export function setUserXp(guildId: string, userId: string, xp: number) {
  const { level } = levelFromXp(xp);
  db.prepare(
    `INSERT INTO user_levels (guild_id, user_id, xp, level, last_msg)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = excluded.xp, level = excluded.level`,
  ).run(guildId, userId, xp, level, Date.now());
}

export function getRank(guildId: string, userId: string): number {
  const all = db
    .prepare("SELECT user_id FROM user_levels WHERE guild_id = ? ORDER BY xp DESC")
    .all(guildId) as { user_id: string }[];
  const idx = all.findIndex((r) => r.user_id === userId);
  return idx === -1 ? all.length + 1 : idx + 1;
}

export function addLevelReward(guildId: string, level: number, roleId: string) {
  db.prepare(
    `INSERT INTO level_rewards (guild_id, level, role_id) VALUES (?, ?, ?)
     ON CONFLICT(guild_id, level) DO UPDATE SET role_id = excluded.role_id`,
  ).run(guildId, level, roleId);
}

export function removeLevelReward(guildId: string, level: number) {
  db.prepare("DELETE FROM level_rewards WHERE guild_id = ? AND level = ?").run(guildId, level);
}

export function getLevelRewards(guildId: string) {
  return db
    .prepare("SELECT level, role_id FROM level_rewards WHERE guild_id = ? ORDER BY level ASC")
    .all(guildId) as { level: number; role_id: string }[];
}

export async function applyLevelRewards(member: GuildMember, newLevel: number, stack: boolean) {
  const rewards = getLevelRewards(member.guild.id);
  const earned = rewards.filter((r) => r.level <= newLevel);
  if (!earned.length) return;
  try {
    if (stack) {
      for (const r of earned) {
        if (!member.roles.cache.has(r.role_id)) {
          await member.roles.add(r.role_id).catch(() => null);
        }
      }
    } else {
      const top = earned[earned.length - 1];
      if (top && !member.roles.cache.has(top.role_id)) {
        await member.roles.add(top.role_id).catch(() => null);
      }
      for (const r of earned.slice(0, -1)) {
        if (member.roles.cache.has(r.role_id)) {
          await member.roles.remove(r.role_id).catch(() => null);
        }
      }
    }
  } catch {
    /* ignore */
  }
}
