import {
  ChannelType,
  PermissionFlagsBits,
  type VoiceState,
  type Guild,
} from "discord.js";
import { db } from "../db.ts";

export function setupVoiceMaster(
  guildId: string,
  joinChannelId: string,
  categoryId: string,
) {
  db.prepare(
    "UPDATE guild_config SET vm_join_channel = ?, vm_category = ? WHERE guild_id = ?",
  ).run(joinChannelId, categoryId, guildId);
}

export function isOwner(channelId: string, userId: string): boolean {
  const row = db
    .prepare("SELECT owner_id FROM voice_owners WHERE channel_id = ?")
    .get(channelId) as { owner_id: string } | undefined;
  return row?.owner_id === userId;
}

export function getOwner(channelId: string): string | null {
  const row = db
    .prepare("SELECT owner_id FROM voice_owners WHERE channel_id = ?")
    .get(channelId) as { owner_id: string } | undefined;
  return row?.owner_id ?? null;
}

export async function handleVoiceUpdate(
  oldState: VoiceState,
  newState: VoiceState,
): Promise<void> {
  const guild = newState.guild;
  const cfg = db
    .prepare("SELECT vm_join_channel, vm_category FROM guild_config WHERE guild_id = ?")
    .get(guild.id) as { vm_join_channel: string | null; vm_category: string | null } | undefined;

  // user joined the trigger channel -> create a new voice
  if (
    cfg?.vm_join_channel &&
    newState.channelId === cfg.vm_join_channel &&
    newState.member
  ) {
    try {
      const channel = await guild.channels.create({
        name: `${newState.member.displayName}'s room`,
        type: ChannelType.GuildVoice,
        parent: cfg.vm_category ?? undefined,
        permissionOverwrites: [
          {
            id: newState.member.id,
            allow: [
              PermissionFlagsBits.ManageChannels,
              PermissionFlagsBits.MoveMembers,
              PermissionFlagsBits.MuteMembers,
              PermissionFlagsBits.DeafenMembers,
            ],
          },
        ],
      });
      db.prepare(
        "INSERT INTO voice_owners (channel_id, owner_id, guild_id, ts) VALUES (?, ?, ?, ?)",
      ).run(channel.id, newState.member.id, guild.id, Date.now());
      await newState.member.voice.setChannel(channel).catch(() => null);
    } catch {
      /* ignore */
    }
  }

  // user left a vm channel that's now empty -> delete
  if (oldState.channelId && oldState.channelId !== newState.channelId) {
    const owner = db
      .prepare("SELECT 1 FROM voice_owners WHERE channel_id = ?")
      .get(oldState.channelId);
    if (owner) {
      const ch = await guild.channels.fetch(oldState.channelId).catch(() => null);
      if (ch && ch.type === ChannelType.GuildVoice && ch.members.size === 0) {
        await ch.delete("vm: empty").catch(() => null);
        db.prepare("DELETE FROM voice_owners WHERE channel_id = ?").run(oldState.channelId);
      }
    }
  }
}

export async function cleanupOrphanedVoices(guild: Guild) {
  const rows = db
    .prepare("SELECT channel_id FROM voice_owners WHERE guild_id = ?")
    .all(guild.id) as { channel_id: string }[];
  for (const r of rows) {
    const ch = await guild.channels.fetch(r.channel_id).catch(() => null);
    if (!ch) {
      db.prepare("DELETE FROM voice_owners WHERE channel_id = ?").run(r.channel_id);
    } else if (ch.type === ChannelType.GuildVoice && ch.members.size === 0) {
      await ch.delete("vm: orphaned").catch(() => null);
      db.prepare("DELETE FROM voice_owners WHERE channel_id = ?").run(r.channel_id);
    }
  }
}
