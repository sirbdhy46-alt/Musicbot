import axios from "axios";

const GIPHY_BASE = "https://api.giphy.com/v1/gifs";

export async function searchGif(
  query: string,
  rating: "g" | "pg" | "pg-13" | "r" = "pg-13",
): Promise<string | null> {
  const key = process.env.GIPHY_API_KEY;
  if (!key) return null;
  try {
    const { data } = await axios.get(`${GIPHY_BASE}/search`, {
      params: { api_key: key, q: query, limit: 25, rating },
      timeout: 7000,
    });
    const items = data?.data ?? [];
    if (!items.length) return null;
    const pick = items[Math.floor(Math.random() * items.length)];
    return pick?.images?.original?.url ?? null;
  } catch {
    return null;
  }
}

export async function randomGif(
  tag: string,
  rating: "g" | "pg" | "pg-13" | "r" = "pg-13",
): Promise<string | null> {
  const key = process.env.GIPHY_API_KEY;
  if (!key) return null;
  try {
    const { data } = await axios.get(`${GIPHY_BASE}/random`, {
      params: { api_key: key, tag, rating },
      timeout: 7000,
    });
    return data?.data?.images?.original?.url ?? null;
  } catch {
    return null;
  }
}

// Curated fallback GIF pool per "vibe" — public Giphy CDN URLs that work
// even when GIPHY_API_KEY is missing. Each entry is a list of permalinks.
const FALLBACKS: Record<string, string[]> = {
  ban: [
    "https://media.giphy.com/media/3o7TKsQ8gqVrXnRyFG/giphy.gif",
    "https://media.giphy.com/media/3o6MbsRfxr2ofLZRK0/giphy.gif",
    "https://media.giphy.com/media/UrHsoaYufuMHK/giphy.gif",
  ],
  kick: [
    "https://media.giphy.com/media/Hcw7rjsIsHcmk/giphy.gif",
    "https://media.giphy.com/media/26gsspfbuEfn1jbfO/giphy.gif",
    "https://media.giphy.com/media/3oz8xRF4ZOoCu5UUco/giphy.gif",
  ],
  mute: [
    "https://media.giphy.com/media/3o7TKMt1VVNkHV2PaE/giphy.gif",
    "https://media.giphy.com/media/MTclfCr4tVgis/giphy.gif",
    "https://media.giphy.com/media/3oEjI8VMeISGfnV1u0/giphy.gif",
  ],
  unmute: [
    "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif",
    "https://media.giphy.com/media/3o7abAHdYvZdBNnGZq/giphy.gif",
  ],
  warn: [
    "https://media.giphy.com/media/3o7btXIelzs8nBnznG/giphy.gif",
    "https://media.giphy.com/media/3o7TKMt1VVNkHV2PaE/giphy.gif",
    "https://media.giphy.com/media/26ufdipQqU2lhNA4g/giphy.gif",
  ],
  jail: [
    "https://media.giphy.com/media/xT9DPjAEYuEvL3fwms/giphy.gif",
    "https://media.giphy.com/media/26FPJGjhefSJuaRhu/giphy.gif",
    "https://media.giphy.com/media/3o6Mb3R6WhHJwGmcec/giphy.gif",
  ],
  unjail: [
    "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif",
    "https://media.giphy.com/media/3o7TKMt1VVNkHV2PaE/giphy.gif",
  ],
  unban: [
    "https://media.giphy.com/media/26FPJGjhefSJuaRhu/giphy.gif",
    "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif",
  ],
  clear: [
    "https://media.giphy.com/media/3o7btMUVwsaIK2YYsg/giphy.gif",
  ],
  lock: [
    "https://media.giphy.com/media/26gsspfbuEfn1jbfO/giphy.gif",
  ],
  unlock: [
    "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif",
  ],
  hug: [
    "https://media.giphy.com/media/od5H3PmEG5EVq/giphy.gif",
    "https://media.giphy.com/media/PHZ7v9tfQu0sM/giphy.gif",
    "https://media.giphy.com/media/wnsgren9NtITS/giphy.gif",
  ],
  kiss: [
    "https://media.giphy.com/media/G3va31oEEnIkM/giphy.gif",
    "https://media.giphy.com/media/12VXIZA1FXdXHy/giphy.gif",
    "https://media.giphy.com/media/zkppEMFvRX5FC/giphy.gif",
  ],
  slap: [
    "https://media.giphy.com/media/Gf3AUz3eBNbTW/giphy.gif",
    "https://media.giphy.com/media/Zau0yrl17uzdK/giphy.gif",
    "https://media.giphy.com/media/jLeyZWgtwgr2U/giphy.gif",
  ],
  pat: [
    "https://media.giphy.com/media/L2z7dnOduqEow/giphy.gif",
    "https://media.giphy.com/media/4HP0ddZnNVvKU/giphy.gif",
  ],
  cry: [
    "https://media.giphy.com/media/d2lcHJTG5Tscg/giphy.gif",
  ],
  default: [
    "https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif",
    "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif",
  ],
};

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Returns a vibe GIF URL for an action. Tries Giphy search first;
 * falls back to a curated public CDN URL pool so GIFs work even
 * without GIPHY_API_KEY configured.
 */
export async function vibeGif(action: string, query?: string): Promise<string> {
  const key = process.env.GIPHY_API_KEY;
  const q = query ?? `anime ${action}`;
  if (key) {
    const found = await searchGif(q, "pg-13");
    if (found) return found;
  }
  const pool = FALLBACKS[action] ?? FALLBACKS.default;
  return pick(pool);
}

export async function trendingGifs(limit = 10): Promise<string[]> {
  const key = process.env.GIPHY_API_KEY;
  if (!key) return [];
  try {
    const { data } = await axios.get(`${GIPHY_BASE}/trending`, {
      params: { api_key: key, limit },
      timeout: 7000,
    });
    return (data?.data ?? [])
      .map((g: { images?: { original?: { url?: string } } }) => g.images?.original?.url)
      .filter(Boolean) as string[];
  } catch {
    return [];
  }
}
