import { AttachmentBuilder, type ColorResolvable } from "discord.js";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
const BANNERS_DIR = resolve(__dirname, "../../assets/banners");
const ASSETS_DIR = resolve(__dirname, "../../assets");

export type ActionName =
  | "ban"
  | "hardban"
  | "unban"
  | "kick"
  | "mute"
  | "unmute"
  | "warn"
  | "jail"
  | "unjail"
  | "lock"
  | "unlock"
  | "lockdown"
  | "isolate"
  | "nuke"
  | "clear"
  | "slowmode"
  | "forcenick"
  | "hug"
  | "slap"
  | "roast"
  | "compliment"
  | "ship"
  | "8ball"
  | "coinflip"
  | "rps";

/**
 * Returns an attachment + image URL for the given action's themed banner.
 * Use the returned `image` field on an embed via `aetherEmbed({ image })`,
 * and pass the `attachment` in the `files` array on the message.
 *
 * Example:
 *   const b = actionBanner("ban");
 *   await i.reply({ embeds: [aetherEmbed({ image: b?.image, ... })], files: b ? [b.attachment] : [] });
 */
export function actionBanner(name: ActionName): { attachment: AttachmentBuilder; image: string } | null {
  // jail uses the dedicated welcome GIF
  if (name === "jail") {
    const p = resolve(ASSETS_DIR, "jail_welcome.gif");
    if (!existsSync(p)) return null;
    const fileName = "jail_welcome.gif";
    return {
      attachment: new AttachmentBuilder(p, { name: fileName }),
      image: `attachment://${fileName}`,
    };
  }
  const p = resolve(BANNERS_DIR, `${name}.gif`);
  if (!existsSync(p)) return null;
  const fileName = `${name}.gif`;
  return {
    attachment: new AttachmentBuilder(p, { name: fileName }),
    image: `attachment://${fileName}`,
  };
}

/**
 * The animated loading bar attachment. Use with deferred replies for slow operations.
 */
export function loadingBar(): { attachment: AttachmentBuilder; image: string } | null {
  const p = resolve(ASSETS_DIR, "loading_bar.gif");
  if (!existsSync(p)) return null;
  return {
    attachment: new AttachmentBuilder(p, { name: "loading_bar.gif" }),
    image: "attachment://loading_bar.gif",
  };
}

/**
 * Build a one-shot reply payload for an action (`/ban`, `/hug`, etc).
 * Returns `{ embeds, files }` you can spread directly into `i.reply()` or
 * `i.editReply()`. Falls back to embed-only if the banner asset is missing.
 */
export function actionReply(
  name: ActionName,
  opts: {
    title: string;
    description: string;
    color?: ColorResolvable;
    footer?: string;
    timestamp?: boolean;
    vibeGif?: string | null;
  },
) {
  const banner = actionBanner(name);
  // If a vibe GIF URL is provided, use it as the big animated image and
  // demote the styled banner to a thumbnail (top-right corner).
  const useVibeAsImage = !!opts.vibeGif;
  return {
    embeds: [
      aetherEmbed({
        title: opts.title,
        description: opts.description,
        color: opts.color ?? COLORS.primary,
        footer: opts.footer,
        timestamp: opts.timestamp,
        image: useVibeAsImage ? (opts.vibeGif as string) : banner?.image,
        thumbnail: useVibeAsImage ? (banner?.image ?? undefined) : undefined,
      }),
    ],
    files: banner ? [banner.attachment] : [],
  };
}

/**
 * Loading bar reply payload — for use with deferred replies on slow ops.
 */
export function loadingReply(opts: { title?: string; description?: string } = {}) {
  const bar = loadingBar();
  return {
    embeds: [
      aetherEmbed({
        title: opts.title ?? "◐ working...",
        description: opts.description ?? "> please wait",
        color: COLORS.ghost,
        image: bar?.image,
      }),
    ],
    files: bar ? [bar.attachment] : [],
  };
}
