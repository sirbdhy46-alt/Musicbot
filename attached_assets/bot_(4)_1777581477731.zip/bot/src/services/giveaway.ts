import type { Client } from "discord.js";
import { db } from "../db.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

export interface GiveawayRow {
  id: number;
  guild_id: string;
  channel_id: string;
  message_id: string;
  prize: string;
  winners: number;
  ends_at: number;
  ended: number;
  host_id: string;
  entries: string;
}

export function createGiveaway(g: Omit<GiveawayRow, "id" | "ended" | "entries">) {
  const stmt = db.prepare(
    `INSERT INTO giveaways (guild_id, channel_id, message_id, prize, winners, ends_at, host_id, entries)
     VALUES (?, ?, ?, ?, ?, ?, ?, '[]')`,
  );
  const result = stmt.run(
    g.guild_id,
    g.channel_id,
    g.message_id,
    g.prize,
    g.winners,
    g.ends_at,
    g.host_id,
  );
  return Number(result.lastInsertRowid);
}

export function addEntry(messageId: string, userId: string): boolean {
  const row = db
    .prepare("SELECT id, entries FROM giveaways WHERE message_id = ? AND ended = 0")
    .get(messageId) as { id: number; entries: string } | undefined;
  if (!row) return false;
  const list = JSON.parse(row.entries) as string[];
  if (list.includes(userId)) return false;
  list.push(userId);
  db.prepare("UPDATE giveaways SET entries = ? WHERE id = ?").run(JSON.stringify(list), row.id);
  return true;
}

export function removeEntry(messageId: string, userId: string): boolean {
  const row = db
    .prepare("SELECT id, entries FROM giveaways WHERE message_id = ? AND ended = 0")
    .get(messageId) as { id: number; entries: string } | undefined;
  if (!row) return false;
  const list = (JSON.parse(row.entries) as string[]).filter((x) => x !== userId);
  db.prepare("UPDATE giveaways SET entries = ? WHERE id = ?").run(JSON.stringify(list), row.id);
  return true;
}

function pickWinners(entries: string[], count: number): string[] {
  const pool = [...entries];
  const winners: string[] = [];
  while (winners.length < count && pool.length) {
    const i = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(i, 1)[0]);
  }
  return winners;
}

export async function endGiveaway(client: Client, id: number, reroll = false): Promise<string[]> {
  const row = db.prepare("SELECT * FROM giveaways WHERE id = ?").get(id) as
    | GiveawayRow
    | undefined;
  if (!row) return [];
  const entries = JSON.parse(row.entries) as string[];
  const winners = pickWinners(entries, row.winners);
  if (!reroll) {
    db.prepare("UPDATE giveaways SET ended = 1 WHERE id = ?").run(id);
  }
  try {
    const channel = await client.channels.fetch(row.channel_id).catch(() => null);
    if (channel?.isTextBased() && "messages" in channel && "send" in channel) {
      const msg = await channel.messages.fetch(row.message_id).catch(() => null);
      const winnerText = winners.length
        ? winners.map((w) => `<@${w}>`).join(", ")
        : "_no entries_";
      const embed = aetherEmbed({
        title: reroll ? "♛ giveaway rerolled" : "♛ giveaway ended",
        description: `# ${row.prize}\n> **winners**: ${winnerText}\n> **entries**: ${entries.length}`,
        color: COLORS.accent,
      });
      if (msg) await msg.edit({ embeds: [embed], components: [] }).catch(() => null);
      await channel.send({
        content: winners.length
          ? `congrats ${winners.map((w) => `<@${w}>`).join(", ")} — you won **${row.prize}**`
          : `no one entered the giveaway for **${row.prize}**`,
      });
    }
  } catch {
    /* ignore */
  }
  return winners;
}

export function tickGiveaways(client: Client) {
  const rows = db
    .prepare("SELECT id FROM giveaways WHERE ended = 0 AND ends_at <= ?")
    .all(Date.now()) as { id: number }[];
  for (const r of rows) {
    void endGiveaway(client, r.id);
  }
}
