import type { Client } from "discord.js";
import { readFileSync, readdirSync, existsSync } from "node:fs";
import { join, dirname, resolve, basename } from "node:path";
import { fileURLToPath } from "node:url";

// path to the bot's bundled emoji folder
const __dirname = dirname(fileURLToPath(import.meta.url));
export const EMOJI_DIR = resolve(__dirname, "../../assets/emojis");

export const EMOJI_NAMES = [
  // static (existing)
  "aether_logo",
  "aether_check",
  "aether_x",
  "aether_warn",
  "aether_info",
  "aether_lock",
  "aether_unlock",
  "aether_ban",
  "aether_kick",
  "aether_mute",
  "aether_star",
  "aether_arrow",
  "aether_dot",
  "aether_diamond",
  "aether_skull",
  "aether_crown",
  "aether_heart",
  "aether_fire",
  "aether_sparkle",
  "aether_cross",
  "aether_shield",
  "aether_eye",
  "aether_moon",
  "aether_blood",
  "aether_ghost",
  "aether_coin",
  "aether_owner",
  "aether_voice",
  "aether_ticket",
  "aether_loading",
  // new static set
  "aether_alert",
  "aether_hammer",
  "aether_banhammer",
  "aether_boot",
  "aether_avatar",
  // new animated set (.gif → discord renders as <a:name:id>)
  "aether_loading_spin",
  "aether_alert_pulse",
  "aether_logo_glow",
  "aether_avatar_glow",
  "aether_dots",
  "aether_pulse",
  "aether_loadbar",
  "aether_skull_pulse",
] as const;

export type EmojiName = (typeof EMOJI_NAMES)[number];

const FALLBACKS: Record<EmojiName, string> = {
  aether_logo: "✦",
  aether_check: "✓",
  aether_x: "✕",
  aether_warn: "⚠",
  aether_info: "ℹ",
  aether_lock: "🔒",
  aether_unlock: "🔓",
  aether_ban: "⛔",
  aether_kick: "👢",
  aether_mute: "🔇",
  aether_star: "⭐",
  aether_arrow: "›",
  aether_dot: "•",
  aether_diamond: "◆",
  aether_skull: "☠",
  aether_crown: "♛",
  aether_heart: "♡",
  aether_fire: "✧",
  aether_sparkle: "✦",
  aether_cross: "✕",
  aether_shield: "🛡",
  aether_eye: "👁",
  aether_moon: "☾",
  aether_blood: "🩸",
  aether_ghost: "༒",
  aether_coin: "◉",
  aether_owner: "♛",
  aether_voice: "🎙",
  aether_ticket: "✉",
  aether_loading: "◐",
  aether_alert: "🚨",
  aether_hammer: "🔨",
  aether_banhammer: "💀",
  aether_boot: "👢",
  aether_avatar: "Ⓐ",
  aether_loading_spin: "◐",
  aether_alert_pulse: "🚨",
  aether_logo_glow: "✦",
  aether_avatar_glow: "Ⓐ",
  aether_dots: "•••",
  aether_pulse: "◉",
  aether_loadbar: "▰▱▱",
  aether_skull_pulse: "☠",
};

const map = new Map<string, string>();
let loadedNames: string[] = [];
let missingNames: string[] = [...EMOJI_NAMES];

export async function loadAppEmojis(client: Client): Promise<void> {
  try {
    const app = client.application;
    if (!app) return;
    await app.fetch().catch(() => null);
    const fetched = await app.emojis.fetch().catch(() => null);
    if (!fetched) return;
    map.clear();
    loadedNames = [];
    for (const e of fetched.values()) {
      if (!e.name) continue;
      map.set(e.name, e.toString());
      loadedNames.push(e.name);
    }
    missingNames = EMOJI_NAMES.filter((n) => !map.has(n));
    console.log(
      `✦ emoji pack: ${loadedNames.length} app emoji(s) loaded · ${missingNames.length} missing`,
    );
    if (missingNames.length) {
      console.log(`  missing: ${missingNames.join(", ")}`);
      console.log(
        `  run 'pnpm --filter @workspace/bot run upload-emojis' to publish them from artifacts/bot/assets/emojis`,
      );
    }
  } catch (err) {
    console.error("failed to load app emojis", err);
  }
}

export function emoji(name: EmojiName): string {
  return map.get(name) ?? FALLBACKS[name] ?? "•";
}

export function getEmojiStatus() {
  return { loaded: loadedNames, missing: missingNames, all: [...EMOJI_NAMES] };
}

/**
 * Discover emoji asset files on disk. Returns a list of `{ name, path, animated }`
 * where `name` is the emoji name (file stem) and `animated` is true for `.gif`.
 */
export function discoverEmojiAssets(): Array<{
  name: string;
  path: string;
  animated: boolean;
}> {
  if (!existsSync(EMOJI_DIR)) return [];
  const out: Array<{ name: string; path: string; animated: boolean }> = [];
  const seen = new Set<string>();
  for (const file of readdirSync(EMOJI_DIR).sort()) {
    const ext = file.split(".").pop()?.toLowerCase();
    if (!ext || !["png", "gif", "jpg", "jpeg", "webp"].includes(ext)) continue;
    const name = basename(file, "." + ext);
    if (seen.has(name)) continue; // prefer .gif over .png if both exist? handled below
    seen.add(name);
    out.push({
      name,
      path: join(EMOJI_DIR, file),
      animated: ext === "gif",
    });
  }
  return out;
}

export function readEmojiAsset(filePath: string): Buffer {
  return readFileSync(filePath);
}
