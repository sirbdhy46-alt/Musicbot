import { AuditLogEvent, type GuildAuditLogsEntry, type Guild } from "discord.js";
import { db } from "../db.ts";

interface ActionRecord {
  ts: number;
  type: string;
}

const userActions = new Map<string, ActionRecord[]>();
const WINDOW_MS = 30_000;

export function isWhitelisted(guildId: string, userId: string, ownerId: string): boolean {
  if (userId === ownerId) return true;
  const row = db
    .prepare("SELECT 1 FROM antinuke_whitelist WHERE guild_id = ? AND user_id = ?")
    .get(guildId, userId);
  return Boolean(row);
}

export function whitelistAdd(guildId: string, userId: string) {
  db.prepare(
    "INSERT OR IGNORE INTO antinuke_whitelist (guild_id, user_id) VALUES (?, ?)",
  ).run(guildId, userId);
}

export function whitelistRemove(guildId: string, userId: string) {
  db.prepare("DELETE FROM antinuke_whitelist WHERE guild_id = ? AND user_id = ?").run(
    guildId,
    userId,
  );
}

export function whitelistList(guildId: string): string[] {
  return (
    db
      .prepare("SELECT user_id FROM antinuke_whitelist WHERE guild_id = ?")
      .all(guildId) as { user_id: string }[]
  ).map((r) => r.user_id);
}

export function setModule(
  guildId: string,
  module: string,
  enabled: boolean,
  threshold = 3,
) {
  db.prepare(
    `INSERT INTO antinuke_modules (guild_id, module, enabled, threshold)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(guild_id, module) DO UPDATE SET enabled = excluded.enabled, threshold = excluded.threshold`,
  ).run(guildId, module, enabled ? 1 : 0, threshold);
}

export function getModule(
  guildId: string,
  module: string,
): { enabled: boolean; threshold: number } {
  const row = db
    .prepare("SELECT enabled, threshold FROM antinuke_modules WHERE guild_id = ? AND module = ?")
    .get(guildId, module) as { enabled: number; threshold: number } | undefined;
  return { enabled: Boolean(row?.enabled), threshold: row?.threshold ?? 3 };
}

export function listModules(guildId: string) {
  return db
    .prepare("SELECT module, enabled, threshold FROM antinuke_modules WHERE guild_id = ?")
    .all(guildId) as { module: string; enabled: number; threshold: number }[];
}

function track(userId: string, type: string): number {
  const now = Date.now();
  const arr = (userActions.get(userId) ?? []).filter((a) => now - a.ts < WINDOW_MS);
  arr.push({ ts: now, type });
  userActions.set(userId, arr);
  return arr.filter((a) => a.type === type).length;
}

export async function handleAuditLog(
  guild: Guild,
  entry: GuildAuditLogsEntry,
): Promise<void> {
  if (!entry.executorId) return;
  const config = db
    .prepare("SELECT antinuke_enabled, antinuke_punishment FROM guild_config WHERE guild_id = ?")
    .get(guild.id) as { antinuke_enabled: number; antinuke_punishment: string } | undefined;
  if (!config?.antinuke_enabled) return;
  if (isWhitelisted(guild.id, entry.executorId, guild.ownerId)) return;
  if (entry.executorId === guild.client.user?.id) return;

  const moduleMap: Record<number, string> = {
    [AuditLogEvent.ChannelDelete]: "channel",
    [AuditLogEvent.ChannelCreate]: "channel",
    [AuditLogEvent.RoleDelete]: "role",
    [AuditLogEvent.RoleCreate]: "role",
    [AuditLogEvent.MemberBanAdd]: "ban",
    [AuditLogEvent.MemberKick]: "kick",
    [AuditLogEvent.WebhookCreate]: "webhook",
    [AuditLogEvent.WebhookDelete]: "webhook",
    [AuditLogEvent.EmojiDelete]: "emoji",
    [AuditLogEvent.EmojiCreate]: "emoji",
    [AuditLogEvent.BotAdd]: "botadd",
  };

  const moduleName = moduleMap[entry.action];
  if (!moduleName) return;
  const mod = getModule(guild.id, moduleName);
  if (!mod.enabled) return;

  const count = track(entry.executorId, moduleName);
  if (count < mod.threshold) return;

  // PUNISH
  const punishment = config.antinuke_punishment ?? "ban";
  try {
    const member = await guild.members.fetch(entry.executorId).catch(() => null);
    if (!member) return;
    if (punishment === "ban") {
      await member.ban({ reason: `[anti-nuke] mass ${moduleName}` }).catch(() => null);
    } else if (punishment === "kick") {
      await member.kick(`[anti-nuke] mass ${moduleName}`).catch(() => null);
    } else if (punishment === "strip") {
      await member.roles.set([], `[anti-nuke] mass ${moduleName}`).catch(() => null);
    }
    const logChannelId = (db
      .prepare("SELECT mod_log_channel FROM guild_config WHERE guild_id = ?")
      .get(guild.id) as { mod_log_channel: string | null } | undefined)?.mod_log_channel;
    if (logChannelId) {
      const ch = await guild.channels.fetch(logChannelId).catch(() => null);
      if (ch?.isTextBased()) {
        await ch.send({
          content: `# anti-nuke trigger\n> **module**: \`${moduleName}\`\n> **target**: <@${entry.executorId}>\n> **action**: \`${punishment}\`\n> **count**: ${count} in ${WINDOW_MS / 1000}s`,
        }).catch(() => null);
      }
    }
  } catch {
    /* ignore */
  }
}
