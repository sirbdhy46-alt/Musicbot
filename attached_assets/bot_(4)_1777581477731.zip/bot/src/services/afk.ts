import { db } from "../db.ts";

export function setAfk(guildId: string, userId: string, reason: string) {
  db.prepare(
    `INSERT INTO afk (guild_id, user_id, reason, since, mentions)
     VALUES (?, ?, ?, ?, 0)
     ON CONFLICT(guild_id, user_id) DO UPDATE SET reason = excluded.reason, since = excluded.since, mentions = 0`,
  ).run(guildId, userId, reason, Date.now());
}

export function clearAfk(
  guildId: string,
  userId: string,
): { since: number; mentions: number; reason: string } | null {
  const row = db
    .prepare("SELECT reason, since, mentions FROM afk WHERE guild_id = ? AND user_id = ?")
    .get(guildId, userId) as { reason: string; since: number; mentions: number } | undefined;
  if (!row) return null;
  db.prepare("DELETE FROM afk WHERE guild_id = ? AND user_id = ?").run(guildId, userId);
  return row;
}

export function getAfk(
  guildId: string,
  userId: string,
): { reason: string; since: number; mentions: number } | null {
  const row = db
    .prepare("SELECT reason, since, mentions FROM afk WHERE guild_id = ? AND user_id = ?")
    .get(guildId, userId) as { reason: string; since: number; mentions: number } | undefined;
  return row ?? null;
}

export function bumpAfkMentions(guildId: string, userId: string) {
  db.prepare(
    "UPDATE afk SET mentions = mentions + 1 WHERE guild_id = ? AND user_id = ?",
  ).run(guildId, userId);
}
