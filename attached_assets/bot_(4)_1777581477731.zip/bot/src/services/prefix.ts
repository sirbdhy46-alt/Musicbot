import type { Message, GuildMember } from "discord.js";
import { ChannelType, PermissionFlagsBits } from "discord.js";
import { db } from "../db.ts";
import { aetherEmbed, errorEmbed, successEmbed, warnEmbed } from "../embeds.ts";
import { COLORS, BOT_NAME } from "../config.ts";
import { emoji } from "./emojis.ts";
import { searchGif } from "./giphy.ts";
import { formatDuration, parseDuration } from "../util.ts";

export function getPrefix(guildId: string): string {
  const row = db
    .prepare("SELECT prefix FROM guild_config WHERE guild_id = ?")
    .get(guildId) as { prefix: string } | undefined;
  return row?.prefix ?? ",";
}

export function setPrefix(guildId: string, prefix: string) {
  db.prepare(
    "INSERT INTO guild_config (guild_id, prefix) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET prefix = excluded.prefix",
  ).run(guildId, prefix);
}

interface PrefixCtx {
  message: Message;
  args: string[];
  raw: string;
  prefix: string;
}

type Handler = (ctx: PrefixCtx) => Promise<void> | void;

const handlers = new Map<string, Handler>();
const aliases = new Map<string, string>();

function cmd(names: string[], handler: Handler) {
  const main = names[0];
  handlers.set(main, handler);
  for (const n of names.slice(1)) aliases.set(n, main);
}

function memberOk(message: Message, perm: bigint, label: string): boolean {
  if (!message.member?.permissions.has(perm)) {
    message.reply({ embeds: [errorEmbed(`you need **${label}** to do this`)] }).catch(() => null);
    return false;
  }
  return true;
}

function targetMember(message: Message, raw: string): GuildMember | null {
  if (!message.guild) return null;
  const id = raw.replace(/[<@!>]/g, "");
  return message.guild.members.cache.get(id) ?? null;
}

cmd(["help", "h", "commands", "cmds"], async ({ message, prefix }) => {
  await message.reply({
    embeds: [
      aetherEmbed({
        description: `# ${BOT_NAME} ${emoji("aether_logo")}\n> the all-in-one security bot\n> prefix: \`${prefix}\` · use \`/help\` for full list\n\n## prefix commands\n> ${emoji("aether_arrow")} ${prefix}prefix · ${prefix}ping · ${prefix}av · ${prefix}whois · ${prefix}si\n> ${emoji("aether_arrow")} ${prefix}ban · ${prefix}kick · ${prefix}warn · ${prefix}clear · ${prefix}timeout · ${prefix}lock · ${prefix}unlock · ${prefix}forcenick\n> ${emoji("aether_arrow")} ${prefix}hardban · ${prefix}lockdown · ${prefix}nuke · ${prefix}slowmode\n> ${emoji("aether_arrow")} ${prefix}snipe · ${prefix}esnipe · ${prefix}afk · ${prefix}rank · ${prefix}bal\n> ${emoji("aether_arrow")} ${prefix}8ball · ${prefix}coinflip · ${prefix}roast · ${prefix}hug · ${prefix}slap\n> ${emoji("aether_arrow")} ${prefix}remind · ${prefix}poll · ${prefix}membercount · ${prefix}firstmsg`,
        color: COLORS.accent,
      }),
    ],
  });
});

cmd(["prefix", "p"], async ({ message, args }) => {
  if (!message.guild) return;
  if (!args[0]) {
    await message.reply({
      embeds: [aetherEmbed({ description: `> current prefix: \`${getPrefix(message.guild.id)}\`` })],
    });
    return;
  }
  if (!memberOk(message, PermissionFlagsBits.ManageGuild, "manage server")) return;
  const np = args[0].slice(0, 4);
  setPrefix(message.guild.id, np);
  await message.reply({ embeds: [successEmbed(`prefix set to \`${np}\``)] });
});

cmd(["ping"], async ({ message }) => {
  await message.reply({
    embeds: [
      aetherEmbed({
        description: `${emoji("aether_dot")} **${message.client.ws.ping}ms** websocket`,
      }),
    ],
  });
});

cmd(["av", "avatar", "pfp"], async ({ message, args }) => {
  const user = args[0] ? (targetMember(message, args[0])?.user ?? message.author) : message.author;
  await message.reply({
    embeds: [
      aetherEmbed({
        title: user.tag,
        image: user.displayAvatarURL({ size: 1024, extension: "png" }),
        color: COLORS.accent,
      }),
    ],
  });
});

cmd(["whois", "userinfo", "ui"], async ({ message, args }) => {
  const m = args[0] ? targetMember(message, args[0]) : message.member;
  if (!m) return;
  await message.reply({
    embeds: [
      aetherEmbed({
        author: { name: m.user.tag, iconURL: m.user.displayAvatarURL() },
        thumbnail: m.user.displayAvatarURL({ size: 256 }),
        color: COLORS.accent,
        fields: [
          { name: `${emoji("aether_dot")} id`, value: m.id, inline: true },
          {
            name: `${emoji("aether_dot")} joined`,
            value: m.joinedAt ? `<t:${Math.floor(m.joinedAt.getTime() / 1000)}:R>` : "—",
            inline: true,
          },
          {
            name: `${emoji("aether_dot")} created`,
            value: `<t:${Math.floor(m.user.createdTimestamp / 1000)}:R>`,
            inline: true,
          },
          {
            name: `${emoji("aether_dot")} roles`,
            value:
              m.roles.cache
                .filter((r) => r.id !== message.guild!.id)
                .sort((a, b) => b.position - a.position)
                .map((r) => `<@&${r.id}>`)
                .slice(0, 20)
                .join(" ") || "_none_",
          },
        ],
      }),
    ],
  });
});

cmd(["si", "serverinfo"], async ({ message }) => {
  if (!message.guild) return;
  const g = message.guild;
  await message.reply({
    embeds: [
      aetherEmbed({
        title: g.name,
        thumbnail: g.iconURL({ size: 256 }) ?? undefined,
        color: COLORS.accent,
        fields: [
          { name: `${emoji("aether_dot")} members`, value: String(g.memberCount), inline: true },
          { name: `${emoji("aether_dot")} channels`, value: String(g.channels.cache.size), inline: true },
          { name: `${emoji("aether_dot")} roles`, value: String(g.roles.cache.size), inline: true },
          { name: `${emoji("aether_dot")} boosts`, value: `${g.premiumSubscriptionCount ?? 0} (tier ${g.premiumTier})`, inline: true },
          { name: `${emoji("aether_owner")} owner`, value: `<@${g.ownerId}>`, inline: true },
          { name: `${emoji("aether_dot")} created`, value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
        ],
      }),
    ],
  });
});

async function modPunish(message: Message, type: "ban" | "kick", duration?: number) {
  const args = message.content.trim().split(/\s+/).slice(1);
  if (!args[0]) return;
  if (!memberOk(message, type === "ban" ? PermissionFlagsBits.BanMembers : PermissionFlagsBits.KickMembers, type === "ban" ? "ban members" : "kick members")) return;
  const target = targetMember(message, args[0]);
  if (!target) {
    await message.reply({ embeds: [errorEmbed("user not found")] });
    return;
  }
  const reason = args.slice(1).join(" ") || "no reason";
  try {
    if (type === "ban") {
      await target.ban({ reason: `${message.author.tag}: ${reason}` });
    } else {
      await target.kick(`${message.author.tag}: ${reason}`);
    }
    db.prepare(
      "INSERT INTO mod_cases (guild_id, user_id, mod_id, type, reason, ts) VALUES (?, ?, ?, ?, ?, ?)",
    ).run(message.guild!.id, target.id, message.author.id, type, reason, Date.now());
    await message.reply({
      embeds: [
        successEmbed(
          `${type === "ban" ? emoji("aether_ban") : emoji("aether_kick")} ${type}ned **${target.user.tag}** — ${reason}`,
        ),
      ],
    });
  } catch (err) {
    await message.reply({ embeds: [errorEmbed((err as Error).message)] });
  }
}

cmd(["ban", "b"], async ({ message }) => modPunish(message, "ban"));
cmd(["kick", "k"], async ({ message }) => modPunish(message, "kick"));

cmd(["timeout", "mute", "to"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.ModerateMembers, "moderate members")) return;
  if (!args[0] || !args[1]) {
    await message.reply({ embeds: [errorEmbed("usage: `timeout <user> <duration> [reason]`")] });
    return;
  }
  const target = targetMember(message, args[0]);
  if (!target) return;
  const dur = parseDuration(args[1]);
  if (!dur || dur > 28 * 86400_000) {
    await message.reply({ embeds: [errorEmbed("invalid duration (max 28d)")] });
    return;
  }
  const reason = args.slice(2).join(" ") || "no reason";
  await target.timeout(dur, `${message.author.tag}: ${reason}`).catch(() => null);
  await message.reply({
    embeds: [successEmbed(`${emoji("aether_mute")} timed out **${target.user.tag}** for ${formatDuration(dur)}`)],
  });
});

cmd(["untimeout", "unmute", "ut"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.ModerateMembers, "moderate members")) return;
  if (!args[0]) return;
  const target = targetMember(message, args[0]);
  if (!target) return;
  await target.timeout(null).catch(() => null);
  await message.reply({ embeds: [successEmbed(`removed timeout from **${target.user.tag}**`)] });
});

cmd(["warn", "w"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.ModerateMembers, "moderate members")) return;
  if (!args[0]) return;
  const target = targetMember(message, args[0]);
  if (!target) return;
  const reason = args.slice(1).join(" ") || "no reason";
  db.prepare(
    "INSERT INTO warnings (guild_id, user_id, mod_id, reason, ts) VALUES (?, ?, ?, ?, ?)",
  ).run(message.guild!.id, target.id, message.author.id, reason, Date.now());
  await message.reply({
    embeds: [warnEmbed(`${emoji("aether_warn")} warned **${target.user.tag}** — ${reason}`)],
  });
});

cmd(["clear", "purge", "c"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.ManageMessages, "manage messages")) return;
  const n = Math.min(100, parseInt(args[0] ?? "10", 10) || 10);
  if (message.channel.type === ChannelType.GuildText) {
    const deleted = await message.channel.bulkDelete(n, true).catch(() => null);
    const reply = await message.channel.send({
      embeds: [successEmbed(`deleted **${deleted?.size ?? 0}** message(s)`)],
    });
    setTimeout(() => reply.delete().catch(() => null), 4000);
  }
});

cmd(["lock"], async ({ message }) => {
  if (!memberOk(message, PermissionFlagsBits.ManageChannels, "manage channels")) return;
  if (message.channel.type !== ChannelType.GuildText) return;
  await message.channel.permissionOverwrites.edit(message.guild!.id, { SendMessages: false });
  await message.reply({ embeds: [successEmbed(`${emoji("aether_lock")} channel locked`)] });
});

cmd(["unlock"], async ({ message }) => {
  if (!memberOk(message, PermissionFlagsBits.ManageChannels, "manage channels")) return;
  if (message.channel.type !== ChannelType.GuildText) return;
  await message.channel.permissionOverwrites.edit(message.guild!.id, { SendMessages: null });
  await message.reply({ embeds: [successEmbed(`${emoji("aether_unlock")} channel unlocked`)] });
});

cmd(["slowmode", "sm"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.ManageChannels, "manage channels")) return;
  if (message.channel.type !== ChannelType.GuildText) return;
  const sec = parseInt(args[0] ?? "0", 10) || 0;
  await message.channel.setRateLimitPerUser(sec).catch(() => null);
  await message.reply({ embeds: [successEmbed(`slowmode → ${sec}s`)] });
});

cmd(["forcenick", "fn"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.ManageNicknames, "manage nicknames")) return;
  if (!args[0]) return;
  const target = targetMember(message, args[0]);
  if (!target) return;
  const nick = args.slice(1).join(" ") || "moonlit ghost";
  db.prepare(
    "INSERT INTO forcenicks (guild_id, user_id, nick) VALUES (?, ?, ?) ON CONFLICT DO UPDATE SET nick = excluded.nick",
  ).run(message.guild!.id, target.id, nick);
  await target.setNickname(nick, "force-nick").catch(() => null);
  await message.reply({ embeds: [successEmbed(`force-nick set on **${target.user.tag}** → \`${nick}\``)] });
});

cmd(["unforcenick", "ufn"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.ManageNicknames, "manage nicknames")) return;
  if (!args[0]) return;
  const target = targetMember(message, args[0]);
  if (!target) return;
  db.prepare("DELETE FROM forcenicks WHERE guild_id = ? AND user_id = ?").run(message.guild!.id, target.id);
  await target.setNickname(null, "unforce-nick").catch(() => null);
  await message.reply({ embeds: [successEmbed(`force-nick removed from **${target.user.tag}**`)] });
});

cmd(["hardban", "hb"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.BanMembers, "ban members")) return;
  if (!args[0]) return;
  const id = args[0].replace(/[<@!>]/g, "");
  const reason = args.slice(1).join(" ") || "hardban";
  try {
    await message.guild!.bans.create(id, { reason: `[hardban] ${message.author.tag}: ${reason}` });
    db.prepare("INSERT OR IGNORE INTO hardban_list (guild_id, user_id) VALUES (?, ?)").run(message.guild!.id, id);
    await message.reply({ embeds: [successEmbed(`${emoji("aether_skull")} **hardbanned** \`${id}\` — they cannot rejoin`)] });
  } catch (err) {
    await message.reply({ embeds: [errorEmbed((err as Error).message)] });
  }
});

cmd(["unhardban", "uhb"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.BanMembers, "ban members")) return;
  if (!args[0]) return;
  const id = args[0].replace(/[<@!>]/g, "");
  db.prepare("DELETE FROM hardban_list WHERE guild_id = ? AND user_id = ?").run(message.guild!.id, id);
  await message.guild!.bans.remove(id, "unhardban").catch(() => null);
  await message.reply({ embeds: [successEmbed(`unhardbanned \`${id}\``)] });
});

cmd(["unban", "ub"], async ({ message, args }) => {
  if (!memberOk(message, PermissionFlagsBits.BanMembers, "ban members")) return;
  if (!args[0]) return;
  const id = args[0].replace(/[<@!>]/g, "");
  await message.guild!.bans.remove(id, `${message.author.tag}: unban`).catch(() => null);
  await message.reply({ embeds: [successEmbed(`unbanned \`${id}\``)] });
});

cmd(["lockdown", "ld"], async ({ message }) => {
  if (!memberOk(message, PermissionFlagsBits.Administrator, "administrator")) return;
  let count = 0;
  for (const ch of message.guild!.channels.cache.values()) {
    if (ch.type === ChannelType.GuildText) {
      await ch.permissionOverwrites.edit(message.guild!.id, { SendMessages: false }).catch(() => null);
      count++;
    }
  }
  await message.reply({ embeds: [warnEmbed(`${emoji("aether_lock")} **lockdown engaged** — locked ${count} text channel(s)`)] });
});

cmd(["unlockdown", "uld"], async ({ message }) => {
  if (!memberOk(message, PermissionFlagsBits.Administrator, "administrator")) return;
  let count = 0;
  for (const ch of message.guild!.channels.cache.values()) {
    if (ch.type === ChannelType.GuildText) {
      await ch.permissionOverwrites.edit(message.guild!.id, { SendMessages: null }).catch(() => null);
      count++;
    }
  }
  await message.reply({ embeds: [successEmbed(`${emoji("aether_unlock")} lockdown lifted on ${count} channel(s)`)] });
});

cmd(["nuke"], async ({ message }) => {
  if (!memberOk(message, PermissionFlagsBits.ManageChannels, "manage channels")) return;
  if (message.channel.type !== ChannelType.GuildText) return;
  const ch = message.channel;
  try {
    const cloned = await ch.clone({ reason: `nuke by ${message.author.tag}` });
    await cloned.setPosition(ch.position);
    await ch.delete(`nuke by ${message.author.tag}`);
    const gif = await searchGif("explosion aesthetic");
    await cloned.send({
      embeds: [
        aetherEmbed({
          description: `# channel nuked ${emoji("aether_fire")}\n> ${message.author} cleansed this channel`,
          color: COLORS.danger,
          image: gif ?? undefined,
        }),
      ],
    });
  } catch (err) {
    await message.reply({ embeds: [errorEmbed((err as Error).message)] }).catch(() => null);
  }
});

cmd(["snipe", "s"], async ({ message }) => {
  const { getDeleted } = await import("./snipe.ts");
  const last = getDeleted(message.channel.id);
  if (!last) {
    await message.reply({ embeds: [aetherEmbed({ description: "> nothing to snipe" })] });
    return;
  }
  await message.reply({
    embeds: [
      aetherEmbed({
        author: { name: last.authorTag, iconURL: last.authorAvatar || undefined },
        description: last.content || "_no content_",
        color: COLORS.ghost,
        footer: `sniped · ${new Date(last.ts).toLocaleString()}`,
      }),
    ],
  });
});

cmd(["esnipe", "es"], async ({ message }) => {
  const { getEdited } = await import("./snipe.ts");
  const last = getEdited(message.channel.id);
  if (!last) {
    await message.reply({ embeds: [aetherEmbed({ description: "> nothing to esnipe" })] });
    return;
  }
  await message.reply({
    embeds: [
      aetherEmbed({
        author: { name: last.authorTag, iconURL: last.authorAvatar || undefined },
        description: `**before:** ${last.before}\n**after:** ${last.after}`,
        color: COLORS.ghost,
      }),
    ],
  });
});

cmd(["afk"], async ({ message, args }) => {
  const reason = args.join(" ") || "afk";
  db.prepare(
    "INSERT INTO afk (guild_id, user_id, reason, since, mentions) VALUES (?, ?, ?, ?, 0) ON CONFLICT DO UPDATE SET reason = excluded.reason, since = excluded.since, mentions = 0",
  ).run(message.guild!.id, message.author.id, reason, Date.now());
  await message.reply({
    embeds: [aetherEmbed({ description: `> you are now **afk** — *${reason}*`, color: COLORS.ghost })],
  });
});

cmd(["bal", "balance"], async ({ message, args }) => {
  const user = args[0] ? (targetMember(message, args[0])?.user ?? message.author) : message.author;
  const row = db
    .prepare("SELECT coins, bank FROM economy WHERE guild_id = ? AND user_id = ?")
    .get(message.guild!.id, user.id) as { coins: number; bank: number } | undefined;
  await message.reply({
    embeds: [
      aetherEmbed({
        title: `${emoji("aether_coin")} ${user.username}'s balance`,
        description: `> wallet: **${row?.coins ?? 0}**\n> bank: **${row?.bank ?? 0}**\n> total: **${(row?.coins ?? 0) + (row?.bank ?? 0)}**`,
        color: COLORS.warning,
      }),
    ],
  });
});

cmd(["rank", "level", "lvl"], async ({ message, args }) => {
  const user = args[0] ? (targetMember(message, args[0])?.user ?? message.author) : message.author;
  const row = db
    .prepare("SELECT xp, level FROM user_levels WHERE guild_id = ? AND user_id = ?")
    .get(message.guild!.id, user.id) as { xp: number; level: number } | undefined;
  await message.reply({
    embeds: [
      aetherEmbed({
        title: `${emoji("aether_star")} ${user.username}`,
        description: `> level: **${row?.level ?? 0}**\n> xp: **${row?.xp ?? 0}**`,
        color: COLORS.accent,
      }),
    ],
  });
});

cmd(["8ball", "8b"], async ({ message, args }) => {
  const responses = [
    "absolutely",
    "no chance",
    "ask again later",
    "the void whispers yes",
    "the void whispers no",
    "signs point to yes",
    "signs point to no",
    "uncertain",
    "definitely",
    "in your dreams",
    "the moon agrees",
    "fate is silent",
  ];
  if (!args.length) return;
  const r = responses[Math.floor(Math.random() * responses.length)];
  await message.reply({
    embeds: [aetherEmbed({ description: `# 🎱\n> *${args.join(" ")}*\n## ${r}`, color: COLORS.info })],
  });
});

cmd(["coinflip", "cf"], async ({ message }) => {
  const r = Math.random() < 0.5 ? "heads" : "tails";
  await message.reply({
    embeds: [aetherEmbed({ description: `# coin · **${r}**`, color: COLORS.warning })],
  });
});

cmd(["roast"], async ({ message, args }) => {
  const target = args[0] ? targetMember(message, args[0])?.user.username : "you";
  const lines = [
    `${target} brings everyone joy — when they leave the room`,
    `${target}'s playlist is just elevator music with extra cringe`,
    `i've seen more personality in a saltine cracker than ${target}`,
    `${target} called themselves a 10/10 and the moon laughed`,
    `${target}'s wifi password is the most interesting thing about them`,
  ];
  await message.reply({
    embeds: [aetherEmbed({ description: `> ${lines[Math.floor(Math.random() * lines.length)]}`, color: COLORS.danger })],
  });
});

cmd(["hug"], async ({ message, args }) => {
  if (!args[0]) return;
  const t = targetMember(message, args[0])?.user;
  if (!t) return;
  const gif = await searchGif("anime hug aesthetic");
  await message.reply({
    embeds: [
      aetherEmbed({
        description: `> ${message.author} hugged ${t} ${emoji("aether_heart")}`,
        image: gif ?? undefined,
        color: COLORS.accent,
      }),
    ],
  });
});

cmd(["slap"], async ({ message, args }) => {
  if (!args[0]) return;
  const t = targetMember(message, args[0])?.user;
  if (!t) return;
  const gif = await searchGif("anime slap");
  await message.reply({
    embeds: [
      aetherEmbed({
        description: `> ${message.author} slapped ${t}`,
        image: gif ?? undefined,
        color: COLORS.danger,
      }),
    ],
  });
});

cmd(["remind", "remindme", "rm"], async ({ message, args }) => {
  if (!args[0]) return;
  const dur = parseDuration(args[0]);
  if (!dur) {
    await message.reply({ embeds: [errorEmbed("invalid duration (e.g. `30m`, `2h`, `1d`)")] });
    return;
  }
  const text = args.slice(1).join(" ") || "your reminder";
  db.prepare(
    "INSERT INTO reminders (user_id, channel_id, guild_id, message, remind_at) VALUES (?, ?, ?, ?, ?)",
  ).run(message.author.id, message.channel.id, message.guild?.id ?? null, text, Date.now() + dur);
  await message.reply({
    embeds: [successEmbed(`${emoji("aether_moon")} reminder set for ${formatDuration(dur)}`)],
  });
});

cmd(["membercount", "mc"], async ({ message }) => {
  if (!message.guild) return;
  const total = message.guild.memberCount;
  const bots = message.guild.members.cache.filter((m) => m.user.bot).size;
  await message.reply({
    embeds: [
      aetherEmbed({
        description: `# ${message.guild.name}\n> total: **${total}**\n> humans: **${total - bots}**\n> bots: **${bots}**`,
        color: COLORS.accent,
      }),
    ],
  });
});

cmd(["firstmsg", "first", "fm"], async ({ message }) => {
  if (message.channel.type !== ChannelType.GuildText) return;
  const msgs = await message.channel.messages.fetch({ after: "0", limit: 1 }).catch(() => null);
  const first = msgs?.first();
  if (!first) {
    await message.reply({ embeds: [errorEmbed("couldn't find first message")] });
    return;
  }
  await message.reply({
    embeds: [
      aetherEmbed({
        description: `# first message\n> by ${first.author}\n> [jump →](${first.url})\n> *${first.content || "no content"}*`,
      }),
    ],
  });
});

export async function dispatchPrefix(message: Message): Promise<boolean> {
  if (!message.guild || message.author.bot) return false;
  const prefix = getPrefix(message.guild.id);
  if (!message.content.startsWith(prefix)) return false;
  const without = message.content.slice(prefix.length).trim();
  if (!without) return false;
  const parts = without.split(/\s+/);
  let name = parts[0].toLowerCase();
  const args = parts.slice(1);

  // resolve alias (built-in)
  if (aliases.has(name)) name = aliases.get(name)!;

  // resolve guild custom alias
  const customAlias = db
    .prepare("SELECT command FROM aliases WHERE guild_id = ? AND alias = ?")
    .get(message.guild.id, name) as { command: string } | undefined;
  if (customAlias) {
    if (aliases.has(customAlias.command)) name = aliases.get(customAlias.command)!;
    else name = customAlias.command;
  }

  const handler = handlers.get(name);
  if (!handler) return false;

  // disabled commands
  const disabled = db
    .prepare("SELECT 1 FROM disabled_commands WHERE guild_id = ? AND command = ?")
    .get(message.guild.id, name);
  if (disabled) return false;

  try {
    await handler({ message, args, raw: without, prefix });
  } catch (err) {
    await message
      .reply({ embeds: [errorEmbed((err as Error).message ?? "command failed")] })
      .catch(() => null);
  }
  return true;
}

export function listPrefixCommands() {
  return [...handlers.keys()];
}
