import { type ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { errorEmbed } from "./embeds.ts";

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const sec = Math.floor(ms / 1000);
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ${sec % 60}s`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ${min % 60}m`;
  const d = Math.floor(hr / 24);
  return `${d}d ${hr % 24}h`;
}

export function parseDuration(input: string): number | null {
  const re = /(\d+)\s*(s|sec|secs|seconds|m|min|mins|minutes|h|hr|hrs|hours|d|day|days|w|weeks)/gi;
  let total = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(input))) {
    const n = parseInt(m[1], 10);
    const u = m[2].toLowerCase();
    if (u.startsWith("s")) total += n * 1000;
    else if (u.startsWith("min") || u === "m") total += n * 60_000;
    else if (u.startsWith("h")) total += n * 3_600_000;
    else if (u.startsWith("d")) total += n * 86_400_000;
    else if (u.startsWith("w")) total += n * 604_800_000;
  }
  return total > 0 ? total : null;
}

export async function ensurePermission(
  interaction: ChatInputCommandInteraction,
  permission: bigint,
  label: string,
): Promise<boolean> {
  if (!interaction.memberPermissions?.has(permission)) {
    await interaction.reply({
      embeds: [errorEmbed(`you need **${label}** to do this`)],
      ephemeral: true,
    });
    return false;
  }
  return true;
}

export const Perm = PermissionFlagsBits;

export function trim(text: string, max = 1024): string {
  return text.length > max ? text.slice(0, max - 1) + "…" : text;
}

export function progressBar(current: number, total: number, size = 14): string {
  const ratio = Math.min(1, Math.max(0, current / total));
  const filled = Math.round(ratio * size);
  return `${"▰".repeat(filled)}${"▱".repeat(size - filled)}`;
}

export function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}
