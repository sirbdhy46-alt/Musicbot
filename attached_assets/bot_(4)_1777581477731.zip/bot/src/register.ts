import "dotenv/config";
import { REST, Routes } from "discord.js";
import { ensureEnv } from "./config.ts";
import { getAllCommands } from "./commandRegistry.ts";

import "./commands/utility.ts";
import "./commands/moderation.ts";
import "./commands/jail.ts";
import "./commands/antinuke.ts";
import "./commands/welcome.ts";
import "./commands/leveling.ts";
import "./commands/afk.ts";
import "./commands/templates.ts";
import "./commands/theme.ts";
import "./commands/embed.ts";
import "./commands/selfroles.ts";
import "./commands/reactionroles.ts";
import "./commands/voicemaster.ts";
import "./commands/giveaway.ts";
import "./commands/snipe.ts";
import "./commands/fun.ts";
import "./commands/autoresponder.ts";
import "./commands/starboard.ts";
import "./commands/economy.ts";
import "./commands/prefix.ts";
import "./commands/sticky.ts";
import "./commands/autorole.ts";
import "./commands/counter.ts";
import "./commands/tickets.ts";
import "./commands/logging.ts";
import "./commands/poll.ts";
import "./commands/remind.ts";
import "./commands/bump.ts";
import "./commands/highlight.ts";
import "./commands/invites.ts";
import "./commands/customrole.ts";
import "./commands/extramod.ts";
import "./commands/extrainfo.ts";

const env = ensureEnv();

(async () => {
  const rest = new REST({ version: "10" }).setToken(env.token);
  const body = getAllCommands().map((c) => c.data.toJSON());
  console.log(`◐ deploying ${body.length} commands...`);
  await rest.put(Routes.applicationCommands(env.clientId), { body });
  console.log(`✓ deployed ${body.length} commands`);
})();
