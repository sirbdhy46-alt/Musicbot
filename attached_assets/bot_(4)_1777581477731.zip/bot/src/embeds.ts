import { EmbedBuilder, type ColorResolvable } from "discord.js";
import { COLORS, FOOTER } from "./config.ts";

export interface AetherEmbedOptions {
  title?: string;
  description?: string;
  color?: ColorResolvable;
  thumbnail?: string;
  image?: string;
  fields?: { name: string; value: string; inline?: boolean }[];
  footer?: string;
  author?: { name: string; iconURL?: string };
  url?: string;
  timestamp?: boolean;
}

export function aetherEmbed(opts: AetherEmbedOptions = {}): EmbedBuilder {
  const e = new EmbedBuilder().setColor(opts.color ?? COLORS.primary);
  if (opts.title) e.setTitle(opts.title);
  if (opts.description) e.setDescription(opts.description);
  if (opts.thumbnail) e.setThumbnail(opts.thumbnail);
  if (opts.image) e.setImage(opts.image);
  if (opts.fields?.length) e.addFields(opts.fields);
  if (opts.author) e.setAuthor(opts.author);
  if (opts.url) e.setURL(opts.url);
  if (opts.timestamp) e.setTimestamp();
  e.setFooter({ text: opts.footer ?? FOOTER });
  return e;
}

export function successEmbed(message: string, title?: string) {
  return aetherEmbed({
    title: title ?? "✓ done",
    description: `> ${message}`,
    color: COLORS.success,
  });
}

export function errorEmbed(message: string, title?: string) {
  return aetherEmbed({
    title: title ?? "✕ failed",
    description: `> ${message}`,
    color: COLORS.danger,
  });
}

export function warnEmbed(message: string, title?: string) {
  return aetherEmbed({
    title: title ?? "⚠ heads up",
    description: `> ${message}`,
    color: COLORS.warning,
  });
}

export function infoEmbed(message: string, title?: string) {
  return aetherEmbed({
    title: title ?? "ℹ info",
    description: `> ${message}`,
    color: COLORS.info,
  });
}

export function loadingEmbed(message = "working...") {
  return aetherEmbed({
    title: "◐ loading",
    description: `> ${message}`,
    color: COLORS.ghost,
  });
}

export function bigHeader(text: string): string {
  return `# ${text}`;
}

export function styledList(items: string[]): string {
  return items.map((it) => `> ${it}`).join("\n");
}
