import {
  type ChatInputCommandInteraction,
  type SlashCommandBuilder,
  type SlashCommandSubcommandsOnlyBuilder,
  type SlashCommandOptionsOnlyBuilder,
  Collection,
} from "discord.js";

export interface CommandModule {
  data:
    | SlashCommandBuilder
    | SlashCommandSubcommandsOnlyBuilder
    | SlashCommandOptionsOnlyBuilder
    | Omit<SlashCommandBuilder, "addSubcommand" | "addSubcommandGroup">;
  category: string;
  execute(interaction: ChatInputCommandInteraction): Promise<void>;
}

export const commands = new Collection<string, CommandModule>();

export function register(mod: CommandModule) {
  commands.set(mod.data.name, mod);
}

export function getAllCommands(): CommandModule[] {
  return [...commands.values()];
}
