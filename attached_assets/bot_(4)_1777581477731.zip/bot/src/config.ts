export const BOT_NAME = "AETHER";
export const BOT_TAGLINE = "the all-in-one";
export const PREFIX = ",";

export const COLORS = {
  primary: 0x0a0a0a,
  accent: 0xb91c1c,
  success: 0x16a34a,
  warning: 0xf59e0b,
  danger: 0xdc2626,
  info: 0x6366f1,
  black: 0x010101,
  blood: 0x8b0000,
  ghost: 0x1a1a1a,
} as const;

export const EMOJIS = {
  dot: "•",
  arrow: "›",
  check: "✓",
  cross: "✕",
  warn: "⚠",
  star: "✦",
  diamond: "◆",
  square: "▰",
  empty: "▱",
  loader: "◐",
  fire: "✧",
  crown: "♛",
  skull: "☠",
  rune: "ᚠ",
} as const;

export const FOOTER = `${BOT_NAME} ${EMOJIS.dot} ${BOT_TAGLINE}`;

export const BRAND_THUMB =
  "https://raw.githubusercontent.com/discord/discord-api-docs/main/images/branding/icon.png";

export function ensureEnv(): {
  token: string;
  clientId: string;
  giphyKey: string;
} {
  const token = process.env.DISCORD_BOT_TOKEN;
  const clientId = process.env.DISCORD_CLIENT_ID;
  const giphyKey = process.env.GIPHY_API_KEY ?? "";
  if (!token) throw new Error("DISCORD_BOT_TOKEN is required");
  if (!clientId) throw new Error("DISCORD_CLIENT_ID is required");
  return { token, clientId, giphyKey };
}
