import sharp from "sharp";
import gifenc from "gifenc";
const { GIFEncoder, quantize, applyPalette } = gifenc as unknown as {
  GIFEncoder: typeof import("gifenc").GIFEncoder;
  quantize: typeof import("gifenc").quantize;
  applyPalette: typeof import("gifenc").applyPalette;
};
import fs from "node:fs";
import path from "node:path";

const OUT_DIR = path.resolve("assets/emojis");
fs.mkdirSync(OUT_DIR, { recursive: true });

const SIZE = 96;

interface StaticSpec {
  name: string;
  svg: string;
}

interface AnimSpec {
  name: string;
  frames: number;
  delay?: number;
  build: (t: number) => string;
}

const RED = "#dc2626";
const RED_DARK = "#7f1d1d";
const RED_BRIGHT = "#ff3b3b";
const WHITE = "#fafafa";
const GHOST = "#1a1a1a";

function wrapSvg(inner: string, glow = true): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${SIZE} ${SIZE}" width="${SIZE}" height="${SIZE}">
    ${glow ? `<defs><filter id="g"><feGaussianBlur stdDeviation="1.4" /></filter></defs>` : ""}
    ${inner}
  </svg>`;
}

const STATICS: StaticSpec[] = [
  {
    name: "aether_star",
    svg: wrapSvg(`
      <polygon points="48,8 58,38 90,38 64,56 74,86 48,68 22,86 32,56 6,38 38,38"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <polygon points="48,8 58,38 90,38 64,56 74,86 48,68 22,86 32,56 6,38 38,38"
        fill="${WHITE}" />
    `),
  },
  {
    name: "aether_arrow",
    svg: wrapSvg(`
      <polygon points="14,38 60,38 60,22 88,48 60,74 60,58 14,58"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <polygon points="14,38 60,38 60,22 88,48 60,74 60,58 14,58"
        fill="${WHITE}" />
    `),
  },
  {
    name: "aether_dot",
    svg: wrapSvg(`
      <circle cx="48" cy="48" r="22" fill="${RED_BRIGHT}" filter="url(#g)" />
      <circle cx="48" cy="48" r="14" fill="${WHITE}" />
    `),
  },
  {
    name: "aether_diamond",
    svg: wrapSvg(`
      <polygon points="48,8 88,48 48,88 8,48" fill="${RED_BRIGHT}" filter="url(#g)" />
      <polygon points="48,18 78,48 48,78 18,48" fill="${WHITE}" />
      <polygon points="48,28 68,48 48,68 28,48" fill="${RED_DARK}" />
    `),
  },
  {
    name: "aether_skull",
    svg: wrapSvg(`
      <path d="M48 10 C 22 10 12 30 12 48 C 12 62 20 70 24 74 L 24 86 L 36 86 L 36 78 L 60 78 L 60 86 L 72 86 L 72 74 C 76 70 84 62 84 48 C 84 30 74 10 48 10 Z"
        fill="${WHITE}" filter="url(#g)" />
      <circle cx="34" cy="48" r="8" fill="${RED_DARK}" />
      <circle cx="62" cy="48" r="8" fill="${RED_DARK}" />
      <rect x="44" y="60" width="8" height="10" fill="${RED_DARK}" />
    `),
  },
  {
    name: "aether_crown",
    svg: wrapSvg(`
      <polygon points="10,72 18,32 32,52 48,18 64,52 78,32 86,72"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <polygon points="10,72 18,32 32,52 48,18 64,52 78,32 86,72"
        fill="${WHITE}" />
      <rect x="10" y="72" width="76" height="10" fill="${RED}" />
      <circle cx="48" cy="14" r="4" fill="${RED_BRIGHT}" />
    `),
  },
  {
    name: "aether_heart",
    svg: wrapSvg(`
      <path d="M48 84 C 8 56 8 24 28 18 C 38 14 46 22 48 28 C 50 22 58 14 68 18 C 88 24 88 56 48 84 Z"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <path d="M48 84 C 8 56 8 24 28 18 C 38 14 46 22 48 28 C 50 22 58 14 68 18 C 88 24 88 56 48 84 Z"
        fill="${RED}" />
    `),
  },
  {
    name: "aether_fire",
    svg: wrapSvg(`
      <path d="M48 88 C 22 88 14 70 14 56 C 14 42 26 36 30 24 C 36 36 40 38 44 32 C 48 22 50 14 56 8
               C 56 22 64 28 70 38 C 78 50 82 60 82 68 C 82 80 70 88 48 88 Z"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <path d="M48 84 C 28 84 22 70 22 60 C 22 50 30 46 34 38 C 40 50 46 48 48 42
               C 52 38 56 30 60 26 C 60 36 66 42 70 50 C 74 58 76 64 76 70
               C 76 78 64 84 48 84 Z"
        fill="${WHITE}" />
    `),
  },
  {
    name: "aether_sparkle",
    svg: wrapSvg(`
      <path d="M48 8 L 54 38 L 88 48 L 54 58 L 48 88 L 42 58 L 8 48 L 42 38 Z"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <path d="M48 8 L 54 38 L 88 48 L 54 58 L 48 88 L 42 58 L 8 48 L 42 38 Z"
        fill="${WHITE}" />
      <circle cx="78" cy="20" r="4" fill="${WHITE}" />
      <circle cx="18" cy="78" r="4" fill="${WHITE}" />
    `),
  },
  {
    name: "aether_cross",
    svg: wrapSvg(`
      <rect x="40" y="8" width="16" height="80" fill="${WHITE}" filter="url(#g)" />
      <rect x="20" y="32" width="56" height="16" fill="${WHITE}" filter="url(#g)" />
      <rect x="42" y="10" width="12" height="76" fill="${RED}" />
      <rect x="22" y="34" width="52" height="12" fill="${RED}" />
    `),
  },
  {
    name: "aether_eye",
    svg: wrapSvg(`
      <ellipse cx="48" cy="48" rx="40" ry="22" fill="${WHITE}" filter="url(#g)" />
      <ellipse cx="48" cy="48" rx="40" ry="22" fill="${GHOST}" />
      <circle cx="48" cy="48" r="14" fill="${RED_BRIGHT}" />
      <circle cx="48" cy="48" r="6" fill="${GHOST}" />
      <circle cx="52" cy="44" r="2" fill="${WHITE}" />
    `),
  },
  {
    name: "aether_moon",
    svg: wrapSvg(`
      <circle cx="48" cy="48" r="36" fill="${WHITE}" filter="url(#g)" />
      <circle cx="60" cy="44" r="34" fill="${GHOST}" />
      <circle cx="34" cy="40" r="3" fill="${RED_DARK}" />
      <circle cx="42" cy="56" r="2" fill="${RED_DARK}" />
    `),
  },
  {
    name: "aether_blood",
    svg: wrapSvg(`
      <path d="M48 8 C 36 28 22 46 22 60 C 22 76 34 88 48 88 C 62 88 74 76 74 60 C 74 46 60 28 48 8 Z"
        fill="${RED_DARK}" filter="url(#g)" />
      <path d="M48 8 C 36 28 22 46 22 60 C 22 76 34 88 48 88 C 62 88 74 76 74 60 C 74 46 60 28 48 8 Z"
        fill="${RED_BRIGHT}" />
      <ellipse cx="38" cy="60" rx="8" ry="14" fill="${WHITE}" opacity="0.5" />
    `),
  },
  {
    name: "aether_ghost",
    svg: wrapSvg(`
      <path d="M16 50 C 16 28 32 12 48 12 C 64 12 80 28 80 50 L 80 84 L 70 76 L 60 84 L 50 76 L 40 84 L 30 76 L 16 84 Z"
        fill="${WHITE}" filter="url(#g)" />
      <circle cx="36" cy="44" r="6" fill="${RED_DARK}" />
      <circle cx="60" cy="44" r="6" fill="${RED_DARK}" />
      <ellipse cx="48" cy="62" rx="10" ry="6" fill="${RED_DARK}" />
    `),
  },
  {
    name: "aether_coin",
    svg: wrapSvg(`
      <circle cx="48" cy="48" r="38" fill="${RED_BRIGHT}" filter="url(#g)" />
      <circle cx="48" cy="48" r="34" fill="${RED}" />
      <circle cx="48" cy="48" r="28" fill="${RED_BRIGHT}" />
      <text x="48" y="62" text-anchor="middle"
        font-family="Impact, 'Arial Black', sans-serif"
        font-size="40" font-weight="900" fill="${WHITE}">A</text>
    `),
  },
  {
    name: "aether_owner",
    svg: wrapSvg(`
      <polygon points="10,68 18,28 32,48 48,14 64,48 78,28 86,68"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <polygon points="10,68 18,28 32,48 48,14 64,48 78,28 86,68"
        fill="${WHITE}" />
      <rect x="10" y="68" width="76" height="14" fill="${RED}" />
      <circle cx="48" cy="76" r="4" fill="${WHITE}" />
      <circle cx="48" cy="10" r="4" fill="${WHITE}" />
    `),
  },
  {
    name: "aether_voice",
    svg: wrapSvg(`
      <rect x="34" y="16" width="28" height="44" rx="14" fill="${WHITE}" filter="url(#g)" />
      <rect x="36" y="18" width="24" height="40" rx="12" fill="${RED}" />
      <path d="M22 50 C 22 64 34 72 48 72 C 62 72 74 64 74 50"
        stroke="${WHITE}" stroke-width="6" fill="none" />
      <rect x="44" y="72" width="8" height="12" fill="${WHITE}" />
      <rect x="34" y="84" width="28" height="4" fill="${WHITE}" />
    `),
  },
  {
    name: "aether_ticket",
    svg: wrapSvg(`
      <path d="M10 32 L 86 32 L 86 42 C 80 44 80 52 86 54 L 86 64 L 10 64 L 10 54 C 16 52 16 44 10 42 Z"
        fill="${RED_BRIGHT}" filter="url(#g)" />
      <path d="M10 32 L 86 32 L 86 42 C 80 44 80 52 86 54 L 86 64 L 10 64 L 10 54 C 16 52 16 44 10 42 Z"
        fill="${RED}" />
      <line x1="48" y1="36" x2="48" y2="60" stroke="${WHITE}" stroke-width="2" stroke-dasharray="4,4" />
      <text x="28" y="54" text-anchor="middle"
        font-family="Impact, 'Arial Black', sans-serif"
        font-size="18" font-weight="900" fill="${WHITE}">A</text>
      <text x="68" y="54" text-anchor="middle"
        font-family="Impact, 'Arial Black', sans-serif"
        font-size="14" font-weight="900" fill="${WHITE}">★</text>
    `),
  },
];

const ANIMS: AnimSpec[] = [
  {
    name: "aether_arrow_loop",
    frames: 8,
    delay: 80,
    build: (t) => {
      const x = -20 + 40 * t;
      const opacity = 0.4 + 0.6 * Math.sin(t * Math.PI);
      return wrapSvg(`
        <polygon points="${14 + x},38 ${60 + x},38 ${60 + x},22 ${88 + x},48 ${60 + x},74 ${60 + x},58 ${14 + x},58"
          fill="${RED_BRIGHT}" opacity="${opacity}" filter="url(#g)" />
        <polygon points="${14 + x},38 ${60 + x},38 ${60 + x},22 ${88 + x},48 ${60 + x},74 ${60 + x},58 ${14 + x},58"
          fill="${WHITE}" opacity="${opacity + 0.1}" />
      `);
    },
  },
  {
    name: "aether_divider",
    frames: 10,
    delay: 70,
    build: (t) => {
      const sweep = -20 + (SIZE + 40) * t;
      return wrapSvg(`
        <rect x="6" y="44" width="84" height="2" fill="${RED_DARK}" />
        <rect x="6" y="50" width="84" height="2" fill="${RED_DARK}" />
        <rect x="${sweep}" y="40" width="20" height="16" fill="${RED_BRIGHT}" filter="url(#g)" />
        <rect x="${sweep + 4}" y="42" width="12" height="12" fill="${WHITE}" />
      `);
    },
  },
  {
    name: "aether_heart_pulse",
    frames: 8,
    delay: 90,
    build: (t) => {
      const scale = 0.85 + 0.15 * Math.sin(t * Math.PI * 2);
      const tx = 48 - 48 * scale;
      const ty = 48 - 48 * scale;
      return wrapSvg(`
        <g transform="translate(${tx} ${ty}) scale(${scale})">
          <path d="M48 84 C 8 56 8 24 28 18 C 38 14 46 22 48 28 C 50 22 58 14 68 18 C 88 24 88 56 48 84 Z"
            fill="${RED_BRIGHT}" filter="url(#g)" />
          <path d="M48 84 C 8 56 8 24 28 18 C 38 14 46 22 48 28 C 50 22 58 14 68 18 C 88 24 88 56 48 84 Z"
            fill="${RED}" />
        </g>
      `);
    },
  },
  {
    name: "aether_sparkle_spin",
    frames: 8,
    delay: 80,
    build: (t) => {
      const rot = t * 360;
      return wrapSvg(`
        <g transform="rotate(${rot} 48 48)">
          <path d="M48 8 L 54 38 L 88 48 L 54 58 L 48 88 L 42 58 L 8 48 L 42 38 Z"
            fill="${RED_BRIGHT}" filter="url(#g)" />
          <path d="M48 8 L 54 38 L 88 48 L 54 58 L 48 88 L 42 58 L 8 48 L 42 38 Z"
            fill="${WHITE}" />
        </g>
      `);
    },
  },
];

async function svgToPng(svg: string, out: string) {
  const buf = await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toBuffer();
  fs.writeFileSync(out, buf);
}

async function frameRaw(svg: string): Promise<Uint8Array> {
  const { data } = await sharp(Buffer.from(svg))
    .resize(SIZE, SIZE)
    .raw()
    .ensureAlpha()
    .toBuffer({ resolveWithObject: true });
  return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
}

async function makeGif(spec: AnimSpec, out: string) {
  const enc = GIFEncoder();
  for (let i = 0; i < spec.frames; i++) {
    const t = i / spec.frames;
    const svg = spec.build(t);
    const rgba = await frameRaw(svg);
    const palette = quantize(rgba, 32);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, SIZE, SIZE, { palette, delay: spec.delay ?? 80 });
  }
  enc.finish();
  fs.writeFileSync(out, Buffer.from(enc.bytes()));
}

async function main() {
  let count = 0;
  for (const s of STATICS) {
    const out = path.join(OUT_DIR, `${s.name}.png`);
    if (fs.existsSync(out)) {
      console.log(`◇ skip  ${s.name}`);
      continue;
    }
    await svgToPng(s.svg, out);
    console.log(`✓ png   ${s.name}`);
    count++;
  }
  for (const a of ANIMS) {
    const out = path.join(OUT_DIR, `${a.name}.gif`);
    if (fs.existsSync(out)) {
      console.log(`◇ skip  ${a.name}`);
      continue;
    }
    await makeGif(a, out);
    const size = fs.statSync(out).size;
    console.log(`✓ gif   ${a.name}  (${(size / 1024).toFixed(1)}kb)`);
    count++;
  }
  console.log(`\n${count} new emoji asset(s) written to ${OUT_DIR}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
