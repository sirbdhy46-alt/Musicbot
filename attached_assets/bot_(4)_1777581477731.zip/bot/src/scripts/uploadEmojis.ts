import "dotenv/config";
import { Client, GatewayIntentBits } from "discord.js";
import sharp from "sharp";
import { ensureEnv } from "../config.ts";
import { discoverEmojiAssets, readEmojiAsset } from "../services/emojis.ts";

const env = ensureEnv();

// Discord application emoji limits: 256KB per file, max 256x256.
const MAX_BYTES = 256 * 1024;
const MAX_DIM = 128; // safe dimension that keeps PNGs under 256KB

async function fitImage(file: { path: string; animated: boolean }): Promise<Buffer> {
  const raw = readEmojiAsset(file.path);
  if (file.animated) {
    // Don't re-encode animated GIFs (sharp loses frames). Trust the file is small.
    if (raw.length > MAX_BYTES) {
      throw new Error(
        `${file.path} is ${raw.length} bytes — animated emojis must stay under 256KB.`,
      );
    }
    return raw;
  }
  // PNG: resize down until it fits
  let dim = MAX_DIM;
  let out = await sharp(raw).resize(dim, dim, { fit: "cover" }).png({ compressionLevel: 9 }).toBuffer();
  while (out.length > MAX_BYTES && dim > 32) {
    dim = Math.floor(dim * 0.8);
    out = await sharp(raw).resize(dim, dim, { fit: "cover" }).png({ compressionLevel: 9 }).toBuffer();
  }
  if (out.length > MAX_BYTES) {
    throw new Error(`${file.path} could not be reduced below 256KB`);
  }
  return out;
}

function toDataUri(buf: Buffer, animated: boolean): string {
  const mime = animated ? "image/gif" : "image/png";
  return `data:${mime};base64,${buf.toString("base64")}`;
}

async function main() {
  const client = new Client({ intents: [GatewayIntentBits.Guilds] });
  await client.login(env.token);
  await new Promise<void>((resolve) => client.once("clientReady", () => resolve()));
  if (!client.application) throw new Error("application not available");

  await client.application.fetch();
  const existing = await client.application.emojis.fetch();
  const haveByName = new Map<string, string>();
  for (const e of existing.values()) {
    if (e.name) haveByName.set(e.name, e.id);
  }

  const assets = discoverEmojiAssets();
  console.log(`✦ found ${assets.length} emoji files in artifacts/bot/assets/emojis`);

  let created = 0;
  let skipped = 0;
  let failed = 0;

  for (const asset of assets) {
    if (haveByName.has(asset.name)) {
      console.log(`◇ skip  ${asset.name.padEnd(24)} already uploaded`);
      skipped++;
      continue;
    }
    try {
      const buf = await fitImage(asset);
      const dataUri = toDataUri(buf, asset.animated);
      const made = await client.application.emojis.create({
        name: asset.name,
        attachment: dataUri,
      });
      console.log(`✓ done  ${asset.name.padEnd(24)} → ${made.toString()}`);
      created++;
    } catch (err) {
      console.log(
        `✕ fail  ${asset.name.padEnd(24)} ${err instanceof Error ? err.message : String(err)}`,
      );
      failed++;
    }
  }

  console.log(`\n${created} created · ${skipped} already present · ${failed} failed`);
  await client.destroy();
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
