import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

const DB_PATH = process.env.AETHER_DB ?? "artifacts/bot/data/aether.db";
mkdirSync(dirname(DB_PATH), { recursive: true });

export const db = new DatabaseSync(DB_PATH);
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS guild_config (
  guild_id TEXT PRIMARY KEY,
  prefix TEXT DEFAULT ',',
  welcome_channel TEXT,
  welcome_message TEXT,
  welcome_gif_query TEXT DEFAULT 'welcome',
  welcome_enabled INTEGER DEFAULT 0,
  leave_channel TEXT,
  leave_message TEXT,
  leave_enabled INTEGER DEFAULT 0,
  leveling_enabled INTEGER DEFAULT 1,
  leveling_channel TEXT,
  leveling_announce INTEGER DEFAULT 1,
  leveling_stack INTEGER DEFAULT 0,
  jail_role TEXT,
  jail_channel TEXT,
  jail_log_channel TEXT,
  mod_log_channel TEXT,
  vanity_url TEXT,
  vanity_role TEXT,
  vm_category TEXT,
  vm_join_channel TEXT,
  antinuke_enabled INTEGER DEFAULT 0,
  antinuke_punishment TEXT DEFAULT 'ban',
  antiraid_min_age INTEGER DEFAULT 0,
  antiraid_no_avatar INTEGER DEFAULT 0,
  antiraid_action TEXT DEFAULT 'kick',
  theme_name TEXT,
  selfrole_message TEXT,
  starboard_channel TEXT,
  starboard_threshold INTEGER DEFAULT 3
);

CREATE TABLE IF NOT EXISTS user_levels (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  xp INTEGER DEFAULT 0,
  level INTEGER DEFAULT 0,
  last_msg INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS level_rewards (
  guild_id TEXT NOT NULL,
  level INTEGER NOT NULL,
  role_id TEXT NOT NULL,
  PRIMARY KEY (guild_id, level)
);

CREATE TABLE IF NOT EXISTS afk (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  reason TEXT,
  since INTEGER NOT NULL,
  mentions INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS warnings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mod_id TEXT NOT NULL,
  reason TEXT,
  ts INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS mod_cases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mod_id TEXT NOT NULL,
  type TEXT NOT NULL,
  reason TEXT,
  ts INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS antinuke_whitelist (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS antinuke_modules (
  guild_id TEXT NOT NULL,
  module TEXT NOT NULL,
  threshold INTEGER DEFAULT 3,
  enabled INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, module)
);

CREATE TABLE IF NOT EXISTS reaction_roles (
  guild_id TEXT NOT NULL,
  message_id TEXT NOT NULL,
  emoji TEXT NOT NULL,
  role_id TEXT NOT NULL,
  PRIMARY KEY (message_id, emoji)
);

CREATE TABLE IF NOT EXISTS self_roles (
  guild_id TEXT NOT NULL,
  panel TEXT NOT NULL,
  role_id TEXT NOT NULL,
  label TEXT NOT NULL,
  emoji TEXT,
  PRIMARY KEY (guild_id, panel, role_id)
);

CREATE TABLE IF NOT EXISTS giveaways (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  message_id TEXT NOT NULL,
  prize TEXT NOT NULL,
  winners INTEGER DEFAULT 1,
  ends_at INTEGER NOT NULL,
  ended INTEGER DEFAULT 0,
  host_id TEXT NOT NULL,
  entries TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS voice_owners (
  channel_id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL,
  guild_id TEXT NOT NULL,
  ts INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS auto_responders (
  guild_id TEXT NOT NULL,
  trigger TEXT NOT NULL,
  response TEXT NOT NULL,
  PRIMARY KEY (guild_id, trigger)
);

CREATE TABLE IF NOT EXISTS couples (
  guild_id TEXT PRIMARY KEY,
  user_a TEXT NOT NULL,
  user_b TEXT NOT NULL,
  votes INTEGER DEFAULT 0,
  set_ts INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS economy (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  coins INTEGER DEFAULT 0,
  bank INTEGER DEFAULT 0,
  last_daily INTEGER DEFAULT 0,
  last_work INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS embeds (
  guild_id TEXT NOT NULL,
  name TEXT NOT NULL,
  json TEXT NOT NULL,
  author_id TEXT NOT NULL,
  PRIMARY KEY (guild_id, name)
);

CREATE TABLE IF NOT EXISTS stickies (
  channel_id TEXT PRIMARY KEY,
  guild_id TEXT NOT NULL,
  content TEXT NOT NULL,
  last_message_id TEXT,
  msg_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS autoroles (
  guild_id TEXT NOT NULL,
  role_id TEXT NOT NULL,
  bots_only INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, role_id)
);

CREATE TABLE IF NOT EXISTS counters (
  guild_id TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  type TEXT NOT NULL,
  template TEXT NOT NULL,
  PRIMARY KEY (guild_id, channel_id)
);

CREATE TABLE IF NOT EXISTS ticket_config (
  guild_id TEXT PRIMARY KEY,
  panel_channel TEXT,
  category TEXT,
  staff_role TEXT,
  log_channel TEXT,
  prompt TEXT
);

CREATE TABLE IF NOT EXISTS tickets (
  channel_id TEXT PRIMARY KEY,
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  opened_at INTEGER NOT NULL,
  claimed_by TEXT
);

CREATE TABLE IF NOT EXISTS log_config (
  guild_id TEXT PRIMARY KEY,
  channel_id TEXT,
  events TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS polls (
  message_id TEXT PRIMARY KEY,
  guild_id TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  question TEXT NOT NULL,
  options TEXT NOT NULL,
  ends_at INTEGER NOT NULL,
  ended INTEGER DEFAULT 0,
  votes TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  guild_id TEXT,
  message TEXT NOT NULL,
  remind_at INTEGER NOT NULL,
  fired INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bump_config (
  guild_id TEXT PRIMARY KEY,
  channel_id TEXT,
  role_id TEXT,
  next_bump INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS highlights (
  user_id TEXT NOT NULL,
  guild_id TEXT NOT NULL,
  word TEXT NOT NULL,
  PRIMARY KEY (user_id, guild_id, word)
);

CREATE TABLE IF NOT EXISTS invite_cache (
  guild_id TEXT NOT NULL,
  code TEXT NOT NULL,
  inviter_id TEXT,
  uses INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, code)
);

CREATE TABLE IF NOT EXISTS invite_tracking (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  inviter_id TEXT,
  joined_at INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS invite_counts (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  total INTEGER DEFAULT 0,
  left INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS custom_roles (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  role_id TEXT NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS customrole_config (
  guild_id TEXT PRIMARY KEY,
  base_role TEXT,
  required_role TEXT
);

CREATE TABLE IF NOT EXISTS hardban_list (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS forcenicks (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  nick TEXT NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS disabled_commands (
  guild_id TEXT NOT NULL,
  command TEXT NOT NULL,
  PRIMARY KEY (guild_id, command)
);

CREATE TABLE IF NOT EXISTS aliases (
  guild_id TEXT NOT NULL,
  alias TEXT NOT NULL,
  command TEXT NOT NULL,
  PRIMARY KEY (guild_id, alias)
);
`);

export function getGuildConfig(guildId: string) {
  let row = db
    .prepare("SELECT * FROM guild_config WHERE guild_id = ?")
    .get(guildId) as Record<string, unknown> | undefined;
  if (!row) {
    db.prepare("INSERT INTO guild_config (guild_id) VALUES (?)").run(guildId);
    row = db
      .prepare("SELECT * FROM guild_config WHERE guild_id = ?")
      .get(guildId) as Record<string, unknown>;
  }
  return row;
}

export function setGuildConfig(guildId: string, key: string, value: unknown) {
  getGuildConfig(guildId);
  const stmt = db.prepare(
    `UPDATE guild_config SET ${key} = ? WHERE guild_id = ?`,
  );
  stmt.run(value as never, guildId);
}
