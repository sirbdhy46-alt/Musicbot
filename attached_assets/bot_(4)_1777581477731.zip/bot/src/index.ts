import "dotenv/config";
import {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
  REST,
  Routes,
} from "discord.js";
import { ensureEnv } from "./config.ts";
import { commands, getAllCommands } from "./commandRegistry.ts";

// load all command modules (side-effect register())
import "./commands/utility.ts";
import "./commands/moderation.ts";
import "./commands/jail.ts";
import "./commands/antinuke.ts";
import "./commands/welcome.ts";
import "./commands/leveling.ts";
import "./commands/afk.ts";
import "./commands/templates.ts";
import "./commands/autosetup.ts";
import "./commands/theme.ts";
import "./commands/embed.ts";
import "./commands/selfroles.ts";
import "./commands/reactionroles.ts";
import "./commands/voicemaster.ts";
import "./commands/giveaway.ts";
import "./commands/snipe.ts";
import "./commands/fun.ts";
import "./commands/autoresponder.ts";
import "./commands/starboard.ts";
import "./commands/economy.ts";
import "./commands/prefix.ts";
import "./commands/sticky.ts";
import "./commands/autorole.ts";
import "./commands/counter.ts";
import "./commands/tickets.ts";
import "./commands/ticketsetup.ts";
import "./commands/uploademojis.ts";
import "./commands/logging.ts";
import "./commands/poll.ts";
import "./commands/remind.ts";
import "./commands/bump.ts";
import "./commands/highlight.ts";
import "./commands/invites.ts";
import "./commands/customrole.ts";
import "./commands/extramod.ts";
import "./commands/extrainfo.ts";

import { registerReady } from "./events/ready.ts";
import { registerInteraction } from "./events/interactionCreate.ts";
import { registerMessageCreate } from "./events/messageCreate.ts";
import { registerGuildMember } from "./events/guildMember.ts";
import { registerAuditLog } from "./events/auditLog.ts";
import { registerVoice } from "./events/voice.ts";
import { registerMessageEdits } from "./events/messageEdits.ts";
import { registerReactions } from "./events/reactions.ts";
import { registerPresence } from "./events/presence.ts";

const env = ensureEnv();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildWebhooks,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User, Partials.GuildMember],
});

registerReady(client);
registerInteraction(client);
registerMessageCreate(client);
registerGuildMember(client);
registerAuditLog(client);
registerVoice(client);
registerMessageEdits(client);
registerReactions(client);
registerPresence(client);

client.on("error", (e) => console.error("client error", e));
process.on("unhandledRejection", (e) => console.error("unhandled rejection", e));

async function deployCommands() {
  const rest = new REST({ version: "10" }).setToken(env.token);
  const body = getAllCommands().map((c) => c.data.toJSON());
  console.log(`◐ deploying ${body.length} application commands globally...`);
  try {
    await rest.put(Routes.applicationCommands(env.clientId), { body });
    console.log(`✓ deployed ${body.length} commands`);
  } catch (e) {
    console.error("failed to deploy commands", e);
  }
}

(async () => {
  await deployCommands();
  await client.login(env.token);
})();
