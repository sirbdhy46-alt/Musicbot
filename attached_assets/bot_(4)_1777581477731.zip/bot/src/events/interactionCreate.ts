import type { Client, Interaction, GuildTextBasedChannel } from "discord.js";
import { ChannelType, PermissionFlagsBits } from "discord.js";
import { commands } from "../commandRegistry.ts";
import { TEMPLATES } from "../data/templates.ts";
import { db } from "../db.ts";
import { errorEmbed, aetherEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { addEntry } from "../services/giveaway.ts";
import { emoji } from "../services/emojis.ts";

export function registerInteraction(client: Client) {
  client.on("interactionCreate", async (interaction: Interaction) => {
    try {
      // autocomplete
      if (interaction.isAutocomplete()) {
        const focused = interaction.options.getFocused(true);
        const value = (focused.value as string).toLowerCase();
        if (focused.name === "id" || focused.name === "name") {
          const cmdName = interaction.commandName;
          if (cmdName === "template" || cmdName === "theme") {
            await interaction.respond(
              TEMPLATES.filter((t) => t.id.includes(value) || t.vibe.includes(value))
                .slice(0, 25)
                .map((t) => ({ name: `${t.id} — ${t.vibe}`, value: t.id })),
            );
            return;
          }
          if (cmdName === "embed") {
            const guildId = interaction.guildId ?? "";
            const rows = db
              .prepare("SELECT name FROM embeds WHERE guild_id = ? AND name LIKE ? LIMIT 25")
              .all(guildId, `%${value}%`) as { name: string }[];
            await interaction.respond(rows.map((r) => ({ name: r.name, value: r.name })));
            return;
          }
        }
        await interaction.respond([]);
        return;
      }

      if (interaction.isChatInputCommand()) {
        // disabled commands check
        if (interaction.guildId) {
          const dis = db
            .prepare("SELECT 1 FROM disabled_commands WHERE guild_id = ? AND command = ?")
            .get(interaction.guildId, interaction.commandName);
          if (dis) {
            await interaction.reply({
              embeds: [errorEmbed("this command is disabled here")],
              ephemeral: true,
            });
            return;
          }
        }
        const cmd = commands.get(interaction.commandName);
        if (!cmd) return;
        await cmd.execute(interaction);
        return;
      }

      // buttons
      if (interaction.isButton()) {
        const id = interaction.customId;

        if (id.startsWith("crole:")) {
          if (!interaction.guild) return;
          const member = await interaction.guild.members.fetch(interaction.user.id);
          // remove any existing color role first (only one at a time)
          const existing = member.roles.cache.filter((r) => r.name.startsWith("✦ ") && /^✦ [a-z]+$/.test(r.name));
          const colorNames = new Set([
            "✦ crimson","✦ scarlet","✦ ember","✦ amber","✦ gold","✦ lime","✦ emerald",
            "✦ teal","✦ cyan","✦ sky","✦ sapphire","✦ indigo","✦ violet","✦ magenta",
            "✦ pink","✦ rose","✦ pearl","✦ slate",
          ]);
          for (const r of existing.values()) {
            if (colorNames.has(r.name)) await member.roles.remove(r.id, "color swap").catch(() => null);
          }
          if (id === "crole:clear") {
            await interaction.reply({ embeds: [successEmbed("color removed")], ephemeral: true });
            return;
          }
          const roleId = id.slice("crole:".length);
          try {
            await member.roles.add(roleId, "color picker");
            await interaction.reply({ embeds: [successEmbed(`color set to <@&${roleId}>`)], ephemeral: true });
          } catch {
            await interaction.reply({
              embeds: [errorEmbed("can't apply that color (role above me?)")],
              ephemeral: true,
            });
          }
          return;
        }

        if (id.startsWith("srole:")) {
          const roleId = id.slice("srole:".length);
          if (!interaction.guild) return;
          const member = await interaction.guild.members.fetch(interaction.user.id);
          const has = member.roles.cache.has(roleId);
          try {
            if (has) {
              await member.roles.remove(roleId, "selfrole");
              await interaction.reply({ embeds: [successEmbed(`removed <@&${roleId}>`)], ephemeral: true });
            } else {
              await member.roles.add(roleId, "selfrole");
              await interaction.reply({ embeds: [successEmbed(`gave you <@&${roleId}>`)], ephemeral: true });
            }
          } catch {
            await interaction.reply({
              embeds: [errorEmbed("can't manage that role (above me?)")],
              ephemeral: true,
            });
          }
          return;
        }

        if (id === "gw-enter") {
          const ok = addEntry(interaction.message.id, interaction.user.id);
          await interaction.reply({
            embeds: [
              ok
                ? aetherEmbed({ description: "> ✓ entered the giveaway" })
                : aetherEmbed({ description: "> you're already entered" }),
            ],
            ephemeral: true,
          });
          return;
        }

        if (id === "ticket-open") {
          if (!interaction.guild) return;
          const cfg = db
            .prepare("SELECT category, staff_role FROM ticket_config WHERE guild_id = ?")
            .get(interaction.guild.id) as { category: string; staff_role: string } | undefined;
          if (!cfg) {
            await interaction.reply({ embeds: [errorEmbed("tickets not set up")], ephemeral: true });
            return;
          }
          const existing = db
            .prepare("SELECT channel_id FROM tickets WHERE guild_id = ? AND user_id = ?")
            .get(interaction.guild.id, interaction.user.id) as { channel_id: string } | undefined;
          if (existing) {
            await interaction.reply({
              embeds: [errorEmbed(`you already have a ticket: <#${existing.channel_id}>`)],
              ephemeral: true,
            });
            return;
          }
          await interaction.deferReply({ ephemeral: true });
          try {
            const ch = await interaction.guild.channels.create({
              name: `ticket-${interaction.user.username}`.slice(0, 32),
              type: ChannelType.GuildText,
              parent: cfg.category,
              permissionOverwrites: [
                { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                {
                  id: interaction.user.id,
                  allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles],
                },
                { id: cfg.staff_role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
              ],
            });
            db.prepare(
              "INSERT INTO tickets (channel_id, guild_id, user_id, opened_at, claimed_by) VALUES (?, ?, ?, ?, NULL)",
            ).run(ch.id, interaction.guild.id, interaction.user.id, Date.now());
            await ch.send({
              content: `<@${interaction.user.id}> · <@&${cfg.staff_role}>`,
              embeds: [
                aetherEmbed({
                  description: `# ${emoji("aether_ticket")} ticket opened\n> staff will be with you shortly\n> use \`/tickets close\` to close`,
                  color: COLORS.accent,
                }),
              ],
            });
            await interaction.editReply({
              embeds: [successEmbed(`ticket opened → <#${ch.id}>`)],
            });
          } catch (err) {
            await interaction.editReply({ embeds: [errorEmbed((err as Error).message)] });
          }
          return;
        }
      }
    } catch (err) {
      console.error("interaction error", err);
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction
          .reply({
            embeds: [errorEmbed((err as Error).message ?? "something broke")],
            ephemeral: true,
          })
          .catch(() => null);
      }
    }
  });
}

// keep referenced types from being tree-shaken
export type _T = GuildTextBasedChannel;
