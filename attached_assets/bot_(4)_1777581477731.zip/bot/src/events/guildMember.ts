import type { Client, GuildMember, Invite, Collection } from "discord.js";
import { handleJoin, handleLeave } from "../services/welcome.ts";
import { db } from "../db.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { logEvent } from "../services/logger.ts";

const inviteCache = new Map<string, Map<string, { uses: number; inviterId: string | null }>>();

export async function refreshInviteCache(guildId: string, invites: Collection<string, Invite>) {
  const m = new Map<string, { uses: number; inviterId: string | null }>();
  for (const inv of invites.values()) {
    m.set(inv.code, { uses: inv.uses ?? 0, inviterId: inv.inviter?.id ?? null });
  }
  inviteCache.set(guildId, m);
}

export function registerGuildMember(client: Client) {
  client.on("guildMemberAdd", async (member: GuildMember) => {
    try {
      // hardban auto-rejoin block
      const blocked = db
        .prepare("SELECT 1 FROM hardban_list WHERE guild_id = ? AND user_id = ?")
        .get(member.guild.id, member.id);
      if (blocked) {
        await member.ban({ reason: "hardban: auto-rejoin block" }).catch(() => null);
        return;
      }

      // anti-raid filter
      const cfg = db
        .prepare("SELECT antiraid_min_age, antiraid_no_avatar, antiraid_action FROM guild_config WHERE guild_id = ?")
        .get(member.guild.id) as
        | { antiraid_min_age: number; antiraid_no_avatar: number; antiraid_action: string }
        | undefined;
      if (cfg) {
        const ageDays = (Date.now() - member.user.createdTimestamp) / 86_400_000;
        const fail =
          (cfg.antiraid_min_age > 0 && ageDays < cfg.antiraid_min_age) ||
          (cfg.antiraid_no_avatar && !member.user.avatar);
        if (fail) {
          if (cfg.antiraid_action === "ban") {
            await member.ban({ reason: "anti-raid" }).catch(() => null);
            return;
          } else if (cfg.antiraid_action === "kick") {
            await member.kick("anti-raid").catch(() => null);
            return;
          }
        }
      }

      // autoroles
      const roles = db
        .prepare("SELECT role_id, bots_only FROM autoroles WHERE guild_id = ?")
        .all(member.guild.id) as { role_id: string; bots_only: number }[];
      for (const r of roles) {
        if (r.bots_only && !member.user.bot) continue;
        if (!r.bots_only && member.user.bot) continue;
        await member.roles.add(r.role_id, "autorole").catch(() => null);
      }
      // also assign non-bot autoroles to humans
      for (const r of roles) {
        if (!r.bots_only && !member.user.bot) {
          await member.roles.add(r.role_id, "autorole").catch(() => null);
        }
      }

      // invite tracker
      try {
        const fresh = await member.guild.invites.fetch();
        const cached = inviteCache.get(member.guild.id);
        let inviter: string | null = null;
        if (cached) {
          for (const inv of fresh.values()) {
            const prev = cached.get(inv.code);
            if (prev && (inv.uses ?? 0) > prev.uses) {
              inviter = prev.inviterId;
              break;
            }
            if (!prev && (inv.uses ?? 0) > 0) {
              inviter = inv.inviter?.id ?? null;
              break;
            }
          }
        }
        await refreshInviteCache(member.guild.id, fresh);
        db.prepare(
          "INSERT OR REPLACE INTO invite_tracking (guild_id, user_id, inviter_id, joined_at) VALUES (?, ?, ?, ?)",
        ).run(member.guild.id, member.id, inviter, Date.now());
        if (inviter) {
          db.prepare(
            "INSERT INTO invite_counts (guild_id, user_id, total, left) VALUES (?, ?, 1, 0) ON CONFLICT DO UPDATE SET total = total + 1",
          ).run(member.guild.id, inviter);
        }
      } catch {
        /* ignore */
      }

      logEvent(member.guild, "memberJoin", {
        description: `> ${member.user} joined\n> account created <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`,
        color: COLORS.success,
      });
    } catch {
      /* ignore */
    }
    await handleJoin(member).catch(() => null);
  });

  client.on("guildMemberRemove", async (member) => {
    if (!("guild" in member)) return;
    const m = member as GuildMember;
    const tracking = db
      .prepare("SELECT inviter_id FROM invite_tracking WHERE guild_id = ? AND user_id = ?")
      .get(m.guild.id, m.id) as { inviter_id: string | null } | undefined;
    if (tracking?.inviter_id) {
      db.prepare(
        "INSERT INTO invite_counts (guild_id, user_id, total, left) VALUES (?, ?, 0, 1) ON CONFLICT DO UPDATE SET left = left + 1",
      ).run(m.guild.id, tracking.inviter_id);
    }
    logEvent(m.guild, "memberLeave", {
      description: `> ${m.user.tag ?? m.id} left`,
      color: COLORS.danger,
    });
    await handleLeave(m).catch(() => null);
  });

  client.on("guildMemberUpdate", async (oldM, newM) => {
    // re-apply force-nick
    const fn = db
      .prepare("SELECT nick FROM forcenicks WHERE guild_id = ? AND user_id = ?")
      .get(newM.guild.id, newM.id) as { nick: string } | undefined;
    if (fn && newM.nickname !== fn.nick) {
      await newM.setNickname(fn.nick, "force-nick re-apply").catch(() => null);
    }
  });

  client.on("inviteCreate", async (invite) => {
    if (!invite.guild) return;
    const guild = client.guilds.cache.get(invite.guild.id);
    if (!guild) return;
    const fresh = await guild.invites.fetch().catch(() => null);
    if (fresh) await refreshInviteCache(guild.id, fresh);
  });
  client.on("inviteDelete", async (invite) => {
    if (!invite.guild) return;
    const guild = client.guilds.cache.get(invite.guild.id);
    if (!guild) return;
    const fresh = await guild.invites.fetch().catch(() => null);
    if (fresh) await refreshInviteCache(guild.id, fresh);
  });
}
