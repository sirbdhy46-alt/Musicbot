import type { Client, Message } from "discord.js";
import { ChannelType } from "discord.js";
import { db } from "../db.ts";
import { handleMessageXp, applyLevelRewards } from "../services/leveling.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { getAfk, bumpAfkMentions } from "../services/afk.ts";
import { clearAndRewardAfk, buildReturnEmbed } from "../commands/afk.ts";
import { formatDuration } from "../util.ts";
import { dispatchPrefix } from "../services/prefix.ts";
import { emoji } from "../services/emojis.ts";

const STICKY_REPOST_AFTER = 5;

export function registerMessageCreate(client: Client) {
  client.on("messageCreate", async (message: Message) => {
    if (!message.guild) return;

    // disboard bump detection
    if (message.author.id === "302050872383242240" && message.embeds[0]?.description?.toLowerCase().includes("bump done")) {
      const next = Date.now() + 2 * 60 * 60 * 1000;
      db.prepare(
        "INSERT INTO bump_config (guild_id, channel_id, role_id, next_bump) VALUES (?, NULL, NULL, ?) ON CONFLICT(guild_id) DO UPDATE SET next_bump = excluded.next_bump",
      ).run(message.guild.id, next);
    }

    if (message.author.bot) return;

    // sticky messages
    const sticky = db
      .prepare("SELECT content, last_message_id, msg_count FROM stickies WHERE channel_id = ?")
      .get(message.channel.id) as { content: string; last_message_id: string | null; msg_count: number } | undefined;
    if (sticky && message.channel.type === ChannelType.GuildText) {
      const newCount = sticky.msg_count + 1;
      if (newCount >= STICKY_REPOST_AFTER) {
        if (sticky.last_message_id) {
          await message.channel.messages.delete(sticky.last_message_id).catch(() => null);
        }
        const reposted = await message.channel.send({
          embeds: [aetherEmbed({ description: sticky.content, color: COLORS.ghost, footer: "📌 sticky" })],
        });
        db.prepare("UPDATE stickies SET last_message_id = ?, msg_count = 0 WHERE channel_id = ?").run(
          reposted.id,
          message.channel.id,
        );
      } else {
        db.prepare("UPDATE stickies SET msg_count = ? WHERE channel_id = ?").run(newCount, message.channel.id);
      }
    }

    // afk return
    const cleared = clearAndRewardAfk(message.guild.id, message.author.id);
    if (cleared) {
      const reply = await message.reply({ embeds: [buildReturnEmbed(cleared)] }).catch(() => null);
      if (reply) setTimeout(() => reply.delete().catch(() => null), 8000);
    }

    // afk mentions
    for (const u of message.mentions.users.values()) {
      const a = getAfk(message.guild.id, u.id);
      if (a) {
        bumpAfkMentions(message.guild.id, u.id);
        await message
          .reply({
            embeds: [
              aetherEmbed({
                description: `> **${u.username}** is afk: *${a.reason}*\n> away for **${formatDuration(Date.now() - a.since)}**`,
                color: COLORS.warning,
              }),
            ],
            allowedMentions: { repliedUser: false },
          })
          .catch(() => null);
      }
    }

    // highlights
    const lower = message.content.toLowerCase();
    if (lower.length > 0) {
      const hits = db
        .prepare("SELECT DISTINCT user_id, word FROM highlights WHERE guild_id = ?")
        .all(message.guild.id) as { user_id: string; word: string }[];
      const notified = new Set<string>();
      for (const h of hits) {
        if (h.user_id === message.author.id) continue;
        if (notified.has(h.user_id)) continue;
        if (!new RegExp(`\\b${escapeRegex(h.word)}\\b`, "i").test(lower)) continue;
        const member = await message.guild.members.fetch(h.user_id).catch(() => null);
        if (!member) continue;
        if ("permissionsFor" in message.channel && !message.channel.permissionsFor(member)?.has("ViewChannel")) continue;
        await member
          .send({
            embeds: [
              aetherEmbed({
                description: `# ${emoji("aether_eye")} highlight: \`${h.word}\`\n> in ${message.channel} of **${message.guild.name}**\n> by ${message.author}\n> *${message.content.slice(0, 500)}*\n> [jump →](${message.url})`,
                color: COLORS.info,
              }),
            ],
          })
          .catch(() => null);
        notified.add(h.user_id);
      }
    }

    // leveling
    const cfg = db
      .prepare(
        "SELECT leveling_enabled, leveling_announce, leveling_channel, leveling_stack FROM guild_config WHERE guild_id = ?",
      )
      .get(message.guild.id) as
      | {
          leveling_enabled: number;
          leveling_announce: number;
          leveling_channel: string | null;
          leveling_stack: number;
        }
      | undefined;
    if (cfg?.leveling_enabled !== 0) {
      const result = await handleMessageXp(message);
      if (result?.leveledUp) {
        const member = await message.guild.members.fetch(message.author.id).catch(() => null);
        if (member) {
          await applyLevelRewards(member, result.level, Boolean(cfg?.leveling_stack));
        }
        if (cfg?.leveling_announce !== 0) {
          const channel = cfg?.leveling_channel
            ? await message.guild.channels.fetch(cfg.leveling_channel).catch(() => null)
            : message.channel;
          if (channel?.isTextBased() && "send" in channel) {
            await channel
              .send({
                embeds: [
                  aetherEmbed({
                    description: `# ${message.author} hit level **${result.level}**\n> the climb continues`,
                    color: COLORS.accent,
                  }),
                ],
              })
              .catch(() => null);
          }
        }
      }
    }

    // autoresponders
    const triggers = db
      .prepare("SELECT trigger, response FROM auto_responders WHERE guild_id = ?")
      .all(message.guild.id) as { trigger: string; response: string }[];
    for (const t of triggers) {
      if (lower.includes(t.trigger)) {
        await message.reply({ content: t.response, allowedMentions: { repliedUser: false } }).catch(() => null);
        break;
      }
    }

    // prefix dispatcher (last)
    await dispatchPrefix(message);
  });
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
