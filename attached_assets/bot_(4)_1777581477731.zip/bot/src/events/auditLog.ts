import type { Client } from "discord.js";
import { handleAuditLog } from "../services/antinuke.ts";

export function registerAuditLog(client: Client) {
  client.on("guildAuditLogEntryCreate", async (entry, guild) => {
    await handleAuditLog(guild, entry).catch(() => null);
  });
}
