import { Events, type Client } from "discord.js";
import { handleVoiceUpdate } from "../services/voicemaster.ts";

export function registerVoice(client: Client) {
  client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
    try {
      await handleVoiceUpdate(oldState, newState);
    } catch {
      /* ignore */
    }
  });
}
