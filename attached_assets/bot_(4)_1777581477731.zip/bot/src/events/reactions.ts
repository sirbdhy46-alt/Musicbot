import type { Client, Message, MessageReaction, PartialMessageReaction } from "discord.js";
import { db } from "../db.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

const starboardPosted = new Map<string, string>();

export function registerReactions(client: Client) {
  client.on("messageReactionAdd", async (reaction, user) => {
    if (user.bot) return;
    const r = reaction.partial ? await reaction.fetch().catch(() => null) : reaction;
    if (!r || !r.message.guildId) return;
    const emoji = r.emoji.id ?? r.emoji.name ?? "";

    // reaction roles
    const rr = db
      .prepare("SELECT role_id FROM reaction_roles WHERE message_id = ? AND emoji = ?")
      .get(r.message.id, emoji) as { role_id: string } | undefined;
    if (rr) {
      const guild = await client.guilds.fetch(r.message.guildId);
      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member) await member.roles.add(rr.role_id, "reaction role").catch(() => null);
    }

    // starboard
    if (r.emoji.name === "⭐") {
      await handleStarboard(client, r);
    }
  });

  client.on("messageReactionRemove", async (reaction, user) => {
    if (user.bot) return;
    const r = reaction.partial ? await reaction.fetch().catch(() => null) : reaction;
    if (!r || !r.message.guildId) return;
    const emoji = r.emoji.id ?? r.emoji.name ?? "";
    const rr = db
      .prepare("SELECT role_id FROM reaction_roles WHERE message_id = ? AND emoji = ?")
      .get(r.message.id, emoji) as { role_id: string } | undefined;
    if (rr) {
      const guild = await client.guilds.fetch(r.message.guildId);
      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member) await member.roles.remove(rr.role_id, "reaction role").catch(() => null);
    }
  });
}

async function handleStarboard(client: Client, r: MessageReaction | PartialMessageReaction) {
  const cfg = db
    .prepare("SELECT starboard_channel, starboard_threshold FROM guild_config WHERE guild_id = ?")
    .get(r.message.guildId) as { starboard_channel: string | null; starboard_threshold: number } | undefined;
  if (!cfg?.starboard_channel) return;
  if ((r.count ?? 0) < (cfg.starboard_threshold ?? 3)) return;
  const msg = r.message.partial ? ((await r.message.fetch().catch(() => null)) as Message | null) : (r.message as Message);
  if (!msg) return;
  if (starboardPosted.has(msg.id)) return;
  const ch = await client.channels.fetch(cfg.starboard_channel).catch(() => null);
  if (!ch?.isTextBased() || !("send" in ch)) return;
  const post = await ch.send({
    embeds: [
      aetherEmbed({
        author: { name: msg.author.tag, iconURL: msg.author.displayAvatarURL() },
        description: `${msg.content || ""}\n\n[jump →](${msg.url})`,
        image: msg.attachments.first()?.url,
        color: COLORS.warning,
        footer: `⭐ ${r.count ?? 0} · #${"name" in msg.channel ? msg.channel.name : "channel"}`,
      }),
    ],
  });
  starboardPosted.set(msg.id, post.id);
}
