import type { Client } from "discord.js";
import { ActivityType } from "discord.js";
import { BOT_NAME } from "../config.ts";
import { tickGiveaways } from "../services/giveaway.ts";
import { cleanupOrphanedVoices } from "../services/voicemaster.ts";
import { loadAppEmojis } from "../services/emojis.ts";
import { startTickers } from "../services/tickers.ts";

export function registerReady(client: Client) {
  client.once("clientReady", async () => {
    if (!client.user) return;
    console.log(`✦ ${BOT_NAME} online as ${client.user.tag} — ${client.guilds.cache.size} guild(s)`);
    client.user.setPresence({
      activities: [{ name: "the void · /help", type: ActivityType.Watching }],
      status: "online",
    });

    await loadAppEmojis(client);

    startTickers(client);

    setInterval(() => tickGiveaways(client), 30_000);
    setInterval(async () => {
      for (const g of client.guilds.cache.values()) {
        await cleanupOrphanedVoices(g).catch(() => null);
      }
    }, 5 * 60_000);
  });
}
