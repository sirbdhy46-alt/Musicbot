import type { Client } from "discord.js";
import { recordDelete, recordEdit } from "../services/snipe.ts";
import { logEvent } from "../services/logger.ts";
import { COLORS } from "../config.ts";

export function registerMessageEdits(client: Client) {
  client.on("messageDelete", (msg) => {
    if (!msg.author?.bot && msg.guild) {
      recordDelete(msg);
      logEvent(msg.guild, "messageDelete", {
        description: `> in ${msg.channel} by ${msg.author ?? "unknown"}\n> *${(msg.content ?? "").slice(0, 1500) || "_no content_"}*`,
        color: COLORS.danger,
      });
    }
  });
  client.on("messageUpdate", (oldMsg, newMsg) => {
    if (newMsg.partial) return;
    if (oldMsg.content === newMsg.content) return;
    recordEdit(oldMsg, newMsg);
    if (newMsg.guild && !newMsg.author?.bot) {
      logEvent(newMsg.guild, "messageEdit", {
        description: `> by ${newMsg.author} in ${newMsg.channel}\n**before:** ${(oldMsg.content ?? "").slice(0, 800)}\n**after:** ${newMsg.content.slice(0, 800)}\n> [jump →](${newMsg.url})`,
        color: COLORS.warning,
      });
    }
  });
}
