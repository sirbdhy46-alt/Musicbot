import type { Client } from "discord.js";
import { db } from "../db.ts";

export function registerPresence(client: Client) {
  client.on("presenceUpdate", async (oldP, newP) => {
    if (!newP?.guild || !newP.userId) return;
    const cfg = db
      .prepare("SELECT vanity_url, vanity_role FROM guild_config WHERE guild_id = ?")
      .get(newP.guild.id) as { vanity_url: string | null; vanity_role: string | null } | undefined;
    if (!cfg?.vanity_url || !cfg.vanity_role) return;
    const customStatus =
      newP.activities.find((a) => a.type === 4)?.state?.toLowerCase() ?? "";
    const member = await newP.guild.members.fetch(newP.userId).catch(() => null);
    if (!member) return;
    const has = member.roles.cache.has(cfg.vanity_role);
    const hasVanity = customStatus.includes(`/${cfg.vanity_url.toLowerCase()}`) || customStatus.includes(`.gg/${cfg.vanity_url.toLowerCase()}`);
    if (hasVanity && !has) {
      await member.roles.add(cfg.vanity_role, "vanity reward").catch(() => null);
    } else if (!hasVanity && has) {
      await member.roles.remove(cfg.vanity_role, "vanity removed").catch(() => null);
    }
  });
}
