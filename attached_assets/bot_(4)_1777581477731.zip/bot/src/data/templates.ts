// 50+ aesthetic server templates
// Each template defines a category structure (channel layout) + a theme palette.
// `apply` is a separate command that builds these in a target guild.

export interface TemplateChannel {
  name: string;
  type: "text" | "voice" | "stage" | "forum";
  topic?: string;
  position?: number;
}

export interface TemplateCategory {
  name: string;
  channels: TemplateChannel[];
}

export interface TemplateRole {
  name: string;
  color: number;
  hoist?: boolean;
  mentionable?: boolean;
}

export interface ServerTemplate {
  id: string;
  name: string;
  vibe: string;
  palette: number[];
  roles: TemplateRole[];
  categories: TemplateCategory[];
}

const VIBES = {
  community: "warm everyday community vibes",
  gaming: "competitive late-night gamer energy",
  aesthetic: "soft pastel girly aesthetic",
  dark: "obsidian gothic underground",
  anime: "anime fan club energy",
  music: "music listening lounge",
  study: "focused study together",
  art: "art collective gallery",
  esports: "professional esports org",
  streamer: "streamer fan family",
  crypto: "crypto trading floor",
  fashion: "high-fashion editorial",
  fitness: "gym & wellness",
  cafe: "cozy cafe corner",
  nature: "forest cottagecore",
  cyberpunk: "neon cyberpunk night",
  minimal: "minimalist productivity",
  trading: "trader's command center",
  developer: "open source dev",
  writers: "writers' atelier",
  photographer: "film photography",
  cinema: "film discussion club",
  nft: "nft collector lounge",
  startup: "startup war room",
  vibey: "lo-fi vibey",
  spiritual: "spiritual & wellness",
  crypto_dark: "dark web 3 trader",
  egirl: "egirl emo aesthetic",
  yfanclub: "y2k fan club",
  hyperpop: "hyperpop chaos",
  drill: "uk drill underground",
  kpop: "kpop stan central",
  vtuber: "vtuber fan family",
  cosplay: "cosplay community",
  retro: "retro gaming arcade",
  speedrun: "speedrun community",
  mma: "fight night arena",
  car: "automotive culture",
  travel: "wanderlust traveler",
  food: "foodie tasting room",
  reading: "reading club library",
  philosophy: "philosophy salon",
  finance: "personal finance planning",
  poker: "poker night",
  mafia: "mafia rp underground",
  fantasy: "high fantasy guild",
  scifi: "sci-fi mission deck",
  horror: "horror movie crypt",
  zen: "zen meditation garden",
  punk: "punk rock basement",
};

function pal(...c: number[]) {
  return c;
}

const baseRoles = (accent: number): TemplateRole[] => [
  { name: "owner", color: accent, hoist: true, mentionable: false },
  { name: "co-owner", color: 0xb91c1c, hoist: true, mentionable: false },
  { name: "head admin", color: 0x9333ea, hoist: true, mentionable: false },
  { name: "admin", color: 0x6366f1, hoist: true, mentionable: false },
  { name: "head mod", color: 0x0ea5e9, hoist: true, mentionable: false },
  { name: "mod", color: 0x10b981, hoist: true, mentionable: false },
  { name: "trial mod", color: 0x14b8a6, hoist: true, mentionable: false },
  { name: "vip", color: 0xf59e0b, hoist: true, mentionable: true },
  { name: "booster", color: 0xec4899, hoist: true, mentionable: true },
  { name: "member", color: 0x9ca3af, hoist: false, mentionable: false },
];

const baseCategories: TemplateCategory[] = [
  {
    name: "📌 information",
    channels: [
      { name: "welcome", type: "text", topic: "welcome to the server" },
      { name: "rules", type: "text", topic: "read these or get jailed" },
      { name: "announcements", type: "text" },
      { name: "self-roles", type: "text" },
    ],
  },
  {
    name: "💬 community",
    channels: [
      { name: "general", type: "text" },
      { name: "media", type: "text" },
      { name: "memes", type: "text" },
      { name: "vent", type: "text" },
      { name: "selfies", type: "text" },
    ],
  },
  {
    name: "🎮 fun",
    channels: [
      { name: "bot-spam", type: "text" },
      { name: "counting", type: "text" },
      { name: "qotd", type: "text" },
    ],
  },
  {
    name: "🔊 voice",
    channels: [
      { name: "general vc", type: "voice" },
      { name: "music vc", type: "voice" },
      { name: "afk", type: "voice" },
      { name: "▶ join to create", type: "voice" },
    ],
  },
  {
    name: "🛡 staff",
    channels: [
      { name: "staff-chat", type: "text" },
      { name: "mod-logs", type: "text" },
      { name: "anti-nuke-logs", type: "text" },
    ],
  },
];

function tpl(
  id: string,
  name: string,
  vibe: string,
  palette: number[],
  overrides: Partial<ServerTemplate> = {},
): ServerTemplate {
  return {
    id,
    name,
    vibe,
    palette,
    roles: overrides.roles ?? baseRoles(palette[0]),
    categories: overrides.categories ?? baseCategories,
  };
}

export const TEMPLATES: ServerTemplate[] = [
  tpl("noir", "noir", "dark gothic underground", pal(0x111111, 0xb91c1c, 0x6b7280)),
  tpl("blood", "blood moon", "occult crimson", pal(0x8b0000, 0x1a1a1a, 0xb91c1c)),
  tpl("aether", "aether", "all-in-one signature", pal(0xb91c1c, 0x0a0a0a, 0xfafafa)),
  tpl("noir-ivory", "noir ivory", "minimal monochrome", pal(0xfafafa, 0x111111, 0x9ca3af)),
  tpl("rosegold", "rosegold", "soft luxury", pal(0xb76e79, 0xfff1f2, 0x9f1239)),
  tpl("y2k", "y2k", "bubblegum y2k", pal(0xff66c4, 0xc8a2ff, 0xfff66e)),
  tpl("egirl", "egirl", "egirl emo", pal(0xff5fa2, 0x111111, 0x9333ea)),
  tpl("kawaii", "kawaii", "pastel anime", pal(0xfecdd3, 0xfde68a, 0xa7f3d0)),
  tpl("hyperpop", "hyperpop", "neon overload", pal(0x39ff14, 0xff10f0, 0x00d1ff)),
  tpl("cyberpunk", "cyberpunk", "neon night city", pal(0xff10f0, 0x00ffff, 0x111111)),
  tpl("vaporwave", "vaporwave", "vhs synth dream", pal(0xff77e9, 0x80f5ff, 0x6b21a8)),
  tpl("cottagecore", "cottagecore", "forest tea garden", pal(0x86592d, 0xa3b18a, 0xeae0c8)),
  tpl("cafe", "cafe", "cozy coffee shop", pal(0x6b3e26, 0xc8a27a, 0xfaf3e0)),
  tpl("dark-academia", "dark academia", "old library", pal(0x3e2723, 0x8d6e63, 0xefebe9)),
  tpl("light-academia", "light academia", "ivory campus", pal(0xf5e6c4, 0x6b4f3a, 0xb29467)),
  tpl("retro-arcade", "retro arcade", "arcade neon", pal(0xfacc15, 0xef4444, 0x3b82f6)),
  tpl("synthwave", "synthwave", "outrun sunset", pal(0xff2a6d, 0x05d9e8, 0x005678)),
  tpl("monaco", "monaco", "luxury yacht life", pal(0xc8a951, 0x0c1a3a, 0xeae0c8)),
  tpl("lana", "lana", "americana melancholy", pal(0xb91c1c, 0xf5e6c4, 0x111111)),
  tpl("billie", "billie", "dark muted green", pal(0x10b981, 0x111111, 0x9ca3af)),
  tpl("kpop", "kpop stan", "kpop hyper fan", pal(0xff85a2, 0x9c27b0, 0x111111)),
  tpl("anime", "anime", "shonen energy", pal(0xff7a00, 0x1d4ed8, 0xfafafa)),
  tpl("studio-ghibli", "studio ghibli", "warm whimsical", pal(0x8aab63, 0xa86e54, 0xf3e8d2)),
  tpl("vtuber", "vtuber", "vtuber fan club", pal(0xa78bfa, 0xf472b6, 0xfafafa)),
  tpl("cosplay", "cosplay", "cosplay community", pal(0xe11d48, 0xa855f7, 0x0ea5e9)),
  tpl("gym", "gym", "lift heavy", pal(0xf59e0b, 0x111111, 0xdc2626)),
  tpl("yoga", "yoga", "calm zen", pal(0xa7f3d0, 0xfde68a, 0xfafafa)),
  tpl("trading", "trading floor", "high finance", pal(0x059669, 0x111111, 0xdc2626)),
  tpl("crypto", "crypto", "web3 trader", pal(0xfacc15, 0x6366f1, 0x111111)),
  tpl("nft", "nft lounge", "nft collector", pal(0x8b5cf6, 0x111111, 0x06b6d4)),
  tpl("startup", "startup", "fast moving team", pal(0x6366f1, 0xfafafa, 0x10b981)),
  tpl("dev", "developer", "open source", pal(0x10b981, 0x111111, 0x6366f1)),
  tpl("hack", "hacker", "terminal underground", pal(0x10b981, 0x000000, 0x39ff14)),
  tpl("design", "design studio", "design crit", pal(0x111111, 0xfafafa, 0xff5252)),
  tpl("photography", "photography", "film & grain", pal(0xfafafa, 0x111111, 0xb45309)),
  tpl("cinema", "cinema", "film club", pal(0x7f1d1d, 0xfafafa, 0x111111)),
  tpl("writers", "writers", "writer's atelier", pal(0x6b3e26, 0xeae0c8, 0x111111)),
  tpl("philosophy", "philosophy", "salon", pal(0x6b21a8, 0xfafafa, 0x111111)),
  tpl("travel", "travel", "wanderlust", pal(0x0ea5e9, 0xfacc15, 0xfafafa)),
  tpl("foodie", "foodie", "tasting menu", pal(0xb45309, 0xfde68a, 0xfafafa)),
  tpl("car", "car culture", "automotive", pal(0xdc2626, 0x111111, 0x9ca3af)),
  tpl("racing", "racing", "f1 paddock", pal(0xdc2626, 0xfafafa, 0x111111)),
  tpl("speedrun", "speedrun", "any% community", pal(0x10b981, 0x6366f1, 0xfafafa)),
  tpl("mma", "fight night", "combat sports", pal(0xdc2626, 0x111111, 0xfacc15)),
  tpl("poker", "poker night", "felt & cards", pal(0x065f46, 0xfafafa, 0x111111)),
  tpl("mafia", "mafia rp", "underground rp", pal(0x111111, 0xb91c1c, 0xfafafa)),
  tpl("fantasy", "high fantasy", "guild hall", pal(0x6b21a8, 0xfacc15, 0x111111)),
  tpl("scifi", "scifi", "mission deck", pal(0x06b6d4, 0x111111, 0xfafafa)),
  tpl("horror", "horror", "horror crypt", pal(0x111111, 0xb91c1c, 0xfafafa)),
  tpl("zen", "zen", "meditation garden", pal(0xa7f3d0, 0xfafafa, 0x6b3e26)),
  tpl("punk", "punk", "basement show", pal(0xfacc15, 0x111111, 0xff10f0)),
  tpl("drill", "drill", "uk drill underground", pal(0x111111, 0xb91c1c, 0xfafafa)),
  tpl("indie", "indie", "indie band", pal(0xb45309, 0xfafafa, 0x6366f1)),
  tpl("clubland", "clubland", "edm festival", pal(0xff10f0, 0x00ffff, 0xfacc15)),
];

export function findTemplate(id: string): ServerTemplate | undefined {
  return TEMPLATES.find((t) => t.id === id.toLowerCase());
}

export function listTemplateNames(): string[] {
  return TEMPLATES.map((t) => `${t.id} — ${t.vibe}`);
}

export const VIBE_INDEX = VIBES;
