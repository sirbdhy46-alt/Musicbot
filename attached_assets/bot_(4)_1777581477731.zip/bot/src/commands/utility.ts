import {
  SlashCommandBuilder,
  type ChatInputCommandInteraction,
  EmbedBuilder,
  ChannelType,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { aetherEmbed, errorEmbed } from "../embeds.ts";
import { COLORS, BOT_NAME } from "../config.ts";
import { searchGif, randomGif, trendingGifs } from "../services/giphy.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("show bot latency"),
  async execute(i) {
    const sent = Date.now();
    await i.reply({ embeds: [aetherEmbed({ description: "◐ pinging" })] });
    const reply = await i.fetchReply();
    const rtt = reply.createdTimestamp - sent;
    await i.editReply({
      embeds: [
        aetherEmbed({
          title: "◆ pong",
          description: `> **rtt**: \`${rtt}ms\`\n> **ws**: \`${i.client.ws.ping}ms\``,
        }),
      ],
    });
  },
});

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("avatar")
    .setDescription("show a user's avatar")
    .addUserOption((o) =>
      o.setName("user").setDescription("the user").setRequired(false),
    ),
  async execute(i) {
    const user = i.options.getUser("user") ?? i.user;
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `◆ ${user.tag}'s avatar`,
          image: user.displayAvatarURL({ size: 1024 }),
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("banner")
    .setDescription("show a user's banner")
    .addUserOption((o) => o.setName("user").setDescription("the user")),
  async execute(i) {
    const target = i.options.getUser("user") ?? i.user;
    const u = await i.client.users.fetch(target.id, { force: true });
    const banner = u.bannerURL({ size: 1024 });
    if (!banner) {
      await i.reply({
        embeds: [errorEmbed(`${u.tag} has no banner`)],
        ephemeral: true,
      });
      return;
    }
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `◆ ${u.tag}'s banner`,
          image: banner,
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("serverinfo")
    .setDescription("information about this server"),
  async execute(i) {
    if (!i.guild) return;
    const g = await i.guild.fetch();
    const owner = await g.fetchOwner();
    const totalChannels = g.channels.cache.size;
    const text = g.channels.cache.filter((c) => c.type === ChannelType.GuildText).size;
    const voice = g.channels.cache.filter((c) => c.type === ChannelType.GuildVoice).size;
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# ${g.name}`,
          thumbnail: g.iconURL({ size: 256 }) ?? undefined,
          image: g.bannerURL({ size: 1024 }) ?? undefined,
          color: COLORS.accent,
          fields: [
            { name: "owner", value: `<@${owner.id}>`, inline: true },
            { name: "members", value: `${g.memberCount}`, inline: true },
            { name: "boosts", value: `${g.premiumSubscriptionCount ?? 0}`, inline: true },
            { name: "roles", value: `${g.roles.cache.size}`, inline: true },
            { name: "channels", value: `${totalChannels} (${text}t / ${voice}v)`, inline: true },
            { name: "created", value: `<t:${Math.floor(g.createdTimestamp / 1000)}:R>`, inline: true },
            { name: "vanity", value: g.vanityURLCode ? `/${g.vanityURLCode}` : "none", inline: true },
            { name: "verification", value: `\`${g.verificationLevel}\``, inline: true },
            { name: "boost tier", value: `tier ${g.premiumTier}`, inline: true },
          ],
        }),
      ],
    });
  },
});

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("information about a user")
    .addUserOption((o) => o.setName("user").setDescription("the user")),
  async execute(i) {
    const u = i.options.getUser("user") ?? i.user;
    const member = i.guild ? await i.guild.members.fetch(u.id).catch(() => null) : null;
    const roles = member
      ? member.roles.cache
          .filter((r) => r.id !== i.guild!.id)
          .sort((a, b) => b.position - a.position)
          .map((r) => `<@&${r.id}>`)
          .slice(0, 12)
          .join(" ") || "none"
      : "—";
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# ${u.tag}`,
          thumbnail: u.displayAvatarURL({ size: 256 }),
          color: COLORS.accent,
          fields: [
            { name: "id", value: `\`${u.id}\``, inline: true },
            { name: "created", value: `<t:${Math.floor(u.createdTimestamp / 1000)}:R>`, inline: true },
            ...(member && member.joinedTimestamp
              ? [{ name: "joined", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true }]
              : []),
            ...(member ? [{ name: `roles [${member.roles.cache.size - 1}]`, value: roles }] : []),
          ],
        }),
      ],
    });
  },
});

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("gif")
    .setDescription("search a gif")
    .addStringOption((o) => o.setName("query").setDescription("what to search").setRequired(true)),
  async execute(i) {
    await i.deferReply();
    const url = await searchGif(i.options.getString("query", true));
    if (!url) {
      await i.editReply({ embeds: [errorEmbed("no gif found")] });
      return;
    }
    await i.editReply({
      embeds: [aetherEmbed({ image: url, color: COLORS.accent })],
    });
  },
});

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("trending")
    .setDescription("show 5 trending gifs"),
  async execute(i) {
    await i.deferReply();
    const gifs = await trendingGifs(5);
    if (!gifs.length) {
      await i.editReply({ embeds: [errorEmbed("couldn't fetch trending")] });
      return;
    }
    const embeds = gifs.slice(0, 4).map((url, idx) =>
      aetherEmbed({
        title: idx === 0 ? "✦ trending" : undefined,
        image: url,
        color: COLORS.accent,
      }),
    );
    await i.editReply({ embeds });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("invite")
    .setDescription("invite the bot to your server"),
  async execute(i) {
    const id = i.client.user!.id;
    const url = `https://discord.com/oauth2/authorize?client_id=${id}&permissions=8&scope=bot+applications.commands`;
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# bring ${BOT_NAME} home`,
          description: `> [click here to invite](${url})`,
          color: COLORS.accent,
        }),
      ],
      ephemeral: true,
    });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("about")
    .setDescription(`about ${BOT_NAME}`),
  async execute(i) {
    const e = new EmbedBuilder()
      .setColor(COLORS.accent)
      .setTitle(`# ${BOT_NAME}`)
      .setDescription(
        [
          `> **the all-in-one discord bot**`,
          `> moderation • anti-nuke • anti-raid`,
          `> welcome • leveling • afk • voicemaster`,
          `> giveaways • snipe • reaction roles • self-roles`,
          `> 50+ aesthetic templates • theme builder`,
          `> embed builder • starboard • autoresponders`,
          `> fun games • pfp battle • couple of the week`,
          `> giphy gif suite • full custom embeds`,
        ].join("\n"),
      )
      .addFields(
        { name: "guilds", value: `${i.client.guilds.cache.size}`, inline: true },
        {
          name: "users",
          value: `${i.client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0)}`,
          inline: true,
        },
        { name: "uptime", value: `<t:${Math.floor((Date.now() - (i.client.uptime ?? 0)) / 1000)}:R>`, inline: true },
      );
    await i.reply({ embeds: [e] });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("explore all features"),
  async execute(i) {
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# ${BOT_NAME} ${"" /* big bold */}`,
          description: [
            "> **moderation** ` /ban /kick /mute /unmute /warn /clear /jail /unjail /case /history `",
            "> **anti-nuke** ` /antinuke module /antinuke whitelist /antinuke punishment /antinuke status `",
            "> **anti-raid** ` /antiraid age /antiraid avatar /antiraid action `",
            "> **welcome** ` /welcome enable /welcome channel /welcome message /welcome gif /welcome test `",
            "> **leveling** ` /rank /leaderboard /levels reward /levels stack /setxp `",
            "> **afk** ` /afk /afk clear `",
            "> **selfroles** ` /selfroles panel /selfroles add /selfroles send `",
            "> **reactionroles** ` /reactionrole add /reactionrole remove `",
            "> **vanity** ` /vanity set /vanity role `",
            "> **voicemaster** ` /vm setup /vm name /vm limit /vm lock /vm unlock /vm claim /vm hide `",
            "> **giveaway** ` /giveaway start /giveaway end /giveaway reroll `",
            "> **snipe** ` /snipe /esnipe `",
            "> **embeds** ` /embed create /embed edit /embed send /embed list `",
            "> **templates** ` /template list /template apply /template wipe-apply `",
            "> **theme** ` /theme search /theme apply /theme list `",
            "> **fun** ` /pfpbattle /couple set /couple show /trivia /8ball /rps /coinflip /roast /ship `",
            "> **utility** ` /avatar /banner /serverinfo /userinfo /ping /gif /trending `",
            "> **starboard** ` /starboard channel /starboard threshold `",
            "> **autoresponder** ` /ar add /ar remove /ar list `",
          ].join("\n"),
          color: COLORS.accent,
        }),
      ],
    });
  },
});
