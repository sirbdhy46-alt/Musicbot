import {
  SlashCommandBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { successEmbed, aetherEmbed, errorEmbed } from "../embeds.ts";
import {
  setModule,
  listModules,
  whitelistAdd,
  whitelistRemove,
  whitelistList,
} from "../services/antinuke.ts";
import { COLORS } from "../config.ts";

register({
  category: "antinuke",
  data: new SlashCommandBuilder()
    .setName("antinuke")
    .setDescription("anti-nuke configuration")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName("enable")
        .setDescription("turn the entire anti-nuke system on or off")
        .addBooleanOption((o) => o.setName("on").setDescription("enabled?").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("module")
        .setDescription("toggle a specific protection module")
        .addStringOption((o) =>
          o
            .setName("name")
            .setDescription("module")
            .setRequired(true)
            .addChoices(
              { name: "channel — mass channel create/delete", value: "channel" },
              { name: "role — mass role create/delete", value: "role" },
              { name: "ban — mass member ban", value: "ban" },
              { name: "kick — mass member kick", value: "kick" },
              { name: "webhook — webhook spam", value: "webhook" },
              { name: "emoji — mass emoji create/delete", value: "emoji" },
              { name: "botadd — unauthorized bot adds", value: "botadd" },
            ),
        )
        .addBooleanOption((o) => o.setName("on").setDescription("enabled?").setRequired(true))
        .addIntegerOption((o) =>
          o.setName("threshold").setDescription("trigger after N actions in 30s").setMinValue(1).setMaxValue(20),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("punishment")
        .setDescription("what happens to triggers")
        .addStringOption((o) =>
          o
            .setName("type")
            .setDescription("punishment")
            .setRequired(true)
            .addChoices(
              { name: "ban", value: "ban" },
              { name: "kick", value: "kick" },
              { name: "strip roles", value: "strip" },
            ),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("whitelist-add")
        .setDescription("whitelist a user from anti-nuke")
        .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("whitelist-remove")
        .setDescription("remove from whitelist")
        .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("status").setDescription("show current anti-nuke setup"))
    .addSubcommand((s) =>
      s
        .setName("logs")
        .setDescription("set the channel that receives anti-nuke triggers")
        .addChannelOption((o) => o.setName("channel").setDescription("channel").setRequired(true)),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "enable") {
      const on = i.options.getBoolean("on", true);
      db.prepare("UPDATE guild_config SET antinuke_enabled = ? WHERE guild_id = ?").run(
        on ? 1 : 0,
        i.guild.id,
      );
      await i.reply({
        embeds: [successEmbed(`anti-nuke ${on ? "**ENABLED**" : "**disabled**"}`)],
      });
    } else if (sub === "module") {
      const name = i.options.getString("name", true);
      const on = i.options.getBoolean("on", true);
      const threshold = i.options.getInteger("threshold") ?? 3;
      setModule(i.guild.id, name, on, threshold);
      await i.reply({
        embeds: [successEmbed(`module **${name}** = ${on ? "on" : "off"} (threshold ${threshold})`)],
      });
    } else if (sub === "punishment") {
      const type = i.options.getString("type", true);
      db.prepare("UPDATE guild_config SET antinuke_punishment = ? WHERE guild_id = ?").run(
        type,
        i.guild.id,
      );
      await i.reply({ embeds: [successEmbed(`punishment set to **${type}**`)] });
    } else if (sub === "whitelist-add") {
      const u = i.options.getUser("user", true);
      whitelistAdd(i.guild.id, u.id);
      await i.reply({ embeds: [successEmbed(`whitelisted ${u}`)] });
    } else if (sub === "whitelist-remove") {
      const u = i.options.getUser("user", true);
      whitelistRemove(i.guild.id, u.id);
      await i.reply({ embeds: [successEmbed(`removed ${u} from whitelist`)] });
    } else if (sub === "status") {
      const cfg = db
        .prepare("SELECT antinuke_enabled, antinuke_punishment, mod_log_channel FROM guild_config WHERE guild_id = ?")
        .get(i.guild.id) as
        | { antinuke_enabled: number; antinuke_punishment: string; mod_log_channel: string | null }
        | undefined;
      const mods = listModules(i.guild.id);
      const wl = whitelistList(i.guild.id);
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# anti-nuke status",
            description: [
              `> **system**: ${cfg?.antinuke_enabled ? "**enabled**" : "disabled"}`,
              `> **punishment**: \`${cfg?.antinuke_punishment ?? "ban"}\``,
              `> **logs**: ${cfg?.mod_log_channel ? `<#${cfg.mod_log_channel}>` : "_none_"}`,
              `> **whitelist**: ${wl.length ? wl.map((u) => `<@${u}>`).join(" ") : "_empty_"}`,
              ``,
              mods.length
                ? mods
                    .map(
                      (m) =>
                        `\`${m.module.padEnd(8)}\` ${m.enabled ? "✓ enabled" : "✕ off"} (threshold ${m.threshold})`,
                    )
                    .join("\n")
                : "> _no modules configured_",
            ].join("\n"),
            color: cfg?.antinuke_enabled ? COLORS.accent : COLORS.ghost,
          }),
        ],
      });
    } else if (sub === "logs") {
      const ch = i.options.getChannel("channel", true);
      db.prepare("UPDATE guild_config SET mod_log_channel = ? WHERE guild_id = ?").run(
        ch.id,
        i.guild.id,
      );
      await i.reply({ embeds: [successEmbed(`anti-nuke logs → <#${ch.id}>`)] });
    }
  },
});

register({
  category: "antinuke",
  data: new SlashCommandBuilder()
    .setName("antiraid")
    .setDescription("anti-raid join filters")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName("age")
        .setDescription("require minimum account age (days)")
        .addIntegerOption((o) =>
          o.setName("days").setDescription("0 to disable").setRequired(true).setMinValue(0).setMaxValue(365),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("avatar")
        .setDescription("require a custom avatar")
        .addBooleanOption((o) => o.setName("on").setDescription("enabled?").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("action")
        .setDescription("what to do to filtered joins")
        .addStringOption((o) =>
          o
            .setName("type")
            .setDescription("action")
            .setRequired(true)
            .addChoices(
              { name: "kick", value: "kick" },
              { name: "ban", value: "ban" },
              { name: "log only", value: "log" },
            ),
        ),
    )
    .addSubcommand((s) => s.setName("status").setDescription("show anti-raid setup")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "age") {
      const d = i.options.getInteger("days", true);
      db.prepare("UPDATE guild_config SET antiraid_min_age = ? WHERE guild_id = ?").run(d, i.guild.id);
      await i.reply({ embeds: [successEmbed(`min account age = **${d} days**`)] });
    } else if (sub === "avatar") {
      const on = i.options.getBoolean("on", true);
      db.prepare("UPDATE guild_config SET antiraid_no_avatar = ? WHERE guild_id = ?").run(on ? 1 : 0, i.guild.id);
      await i.reply({ embeds: [successEmbed(`require avatar = ${on ? "on" : "off"}`)] });
    } else if (sub === "action") {
      const t = i.options.getString("type", true);
      db.prepare("UPDATE guild_config SET antiraid_action = ? WHERE guild_id = ?").run(t, i.guild.id);
      await i.reply({ embeds: [successEmbed(`anti-raid action = **${t}**`)] });
    } else if (sub === "status") {
      const cfg = db
        .prepare("SELECT antiraid_min_age, antiraid_no_avatar, antiraid_action FROM guild_config WHERE guild_id = ?")
        .get(i.guild.id) as
        | { antiraid_min_age: number; antiraid_no_avatar: number; antiraid_action: string }
        | undefined;
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# anti-raid status",
            description: [
              `> **min account age**: ${cfg?.antiraid_min_age ?? 0} days`,
              `> **require avatar**: ${cfg?.antiraid_no_avatar ? "yes" : "no"}`,
              `> **action**: \`${cfg?.antiraid_action ?? "kick"}\``,
            ].join("\n"),
            color: COLORS.accent,
          }),
        ],
      });
    }
  },
});

register({
  category: "antinuke",
  data: new SlashCommandBuilder()
    .setName("vanity")
    .setDescription("vanity url protection + reward role")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName("set")
        .setDescription("lock the official vanity")
        .addStringOption((o) =>
          o.setName("code").setDescription("vanity code (without /)").setRequired(true),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("role")
        .setDescription("role given to anyone displaying the vanity in their status")
        .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("status").setDescription("show vanity config")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "set") {
      const code = i.options.getString("code", true);
      db.prepare("UPDATE guild_config SET vanity_url = ? WHERE guild_id = ?").run(code, i.guild.id);
      await i.reply({ embeds: [successEmbed(`vanity locked to \`/${code}\``)] });
    } else if (sub === "role") {
      const role = i.options.getRole("role", true);
      db.prepare("UPDATE guild_config SET vanity_role = ? WHERE guild_id = ?").run(role.id, i.guild.id);
      await i.reply({ embeds: [successEmbed(`vanity role = <@&${role.id}>`)] });
    } else if (sub === "status") {
      const cfg = db
        .prepare("SELECT vanity_url, vanity_role FROM guild_config WHERE guild_id = ?")
        .get(i.guild.id) as { vanity_url: string | null; vanity_role: string | null } | undefined;
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# vanity status",
            description: `> **locked**: ${cfg?.vanity_url ? `\`/${cfg.vanity_url}\`` : "_none_"}\n> **reward role**: ${cfg?.vanity_role ? `<@&${cfg.vanity_role}>` : "_none_"}`,
          }),
        ],
      });
    }
  },
});
