import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type GuildTextBasedChannel,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, errorEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { makeSelfrolePanelImage } from "../services/setupImages.ts";

register({
  category: "selfroles",
  data: new SlashCommandBuilder()
    .setName("selfrole")
    .setDescription("self-assignable role panels")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("add a role to a panel")
        .addStringOption((o) => o.setName("panel").setDescription("panel name").setRequired(true))
        .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true))
        .addStringOption((o) => o.setName("label").setDescription("button label").setRequired(true))
        .addStringOption((o) => o.setName("emoji").setDescription("emoji (optional)")),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("remove a role from a panel")
        .addStringOption((o) => o.setName("panel").setDescription("panel name").setRequired(true))
        .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("send")
        .setDescription("send the panel as buttons")
        .addStringOption((o) => o.setName("panel").setDescription("panel name").setRequired(true))
        .addChannelOption((o) =>
          o.setName("channel").setDescription("channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        )
        .addStringOption((o) => o.setName("title").setDescription("title"))
        .addStringOption((o) => o.setName("description").setDescription("description (use \\n)")),
    )
    .addSubcommand((s) =>
      s
        .setName("list")
        .setDescription("list panels and their roles"),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "add") {
      const panel = i.options.getString("panel", true);
      const role = i.options.getRole("role", true);
      const label = i.options.getString("label", true);
      const emoji = i.options.getString("emoji");
      db.prepare(
        `INSERT INTO self_roles (guild_id, panel, role_id, label, emoji)
         VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(guild_id, panel, role_id) DO UPDATE SET label = excluded.label, emoji = excluded.emoji`,
      ).run(i.guild.id, panel, role.id, label, emoji);
      await i.reply({ embeds: [successEmbed(`added <@&${role.id}> to **${panel}**`)] });
    } else if (sub === "remove") {
      const panel = i.options.getString("panel", true);
      const role = i.options.getRole("role", true);
      db.prepare("DELETE FROM self_roles WHERE guild_id = ? AND panel = ? AND role_id = ?").run(
        i.guild.id,
        panel,
        role.id,
      );
      await i.reply({ embeds: [successEmbed(`removed`)] });
    } else if (sub === "send") {
      const panel = i.options.getString("panel", true);
      const ch = i.options.getChannel("channel", true);
      const rows = db
        .prepare("SELECT role_id, label, emoji FROM self_roles WHERE guild_id = ? AND panel = ?")
        .all(i.guild.id, panel) as { role_id: string; label: string; emoji: string | null }[];
      if (!rows.length) {
        await i.reply({ embeds: [errorEmbed(`panel \`${panel}\` is empty`)], ephemeral: true });
        return;
      }
      const buttons = rows.slice(0, 25).map((r) => {
        const b = new ButtonBuilder()
          .setCustomId(`srole:${r.role_id}`)
          .setLabel(r.label)
          .setStyle(ButtonStyle.Secondary);
        if (r.emoji) {
          try {
            b.setEmoji(r.emoji);
          } catch {
            /* ignore */
          }
        }
        return b;
      });
      const components: ActionRowBuilder<ButtonBuilder>[] = [];
      for (let i2 = 0; i2 < buttons.length; i2 += 5) {
        components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(buttons.slice(i2, i2 + 5)));
      }
      const channel = (await i.guild.channels.fetch(ch.id)) as GuildTextBasedChannel;
      const panelImg = await makeSelfrolePanelImage(panel).catch(() => null);
      await channel.send({
        embeds: [
          aetherEmbed({
            title: i.options.getString("title") ?? `# ${panel}`,
            description:
              (i.options.getString("description")?.replaceAll("\\n", "\n") ?? "> click a button to claim a role"),
            image: panelImg ? "attachment://selfrole-panel.png" : undefined,
            color: COLORS.accent,
          }),
        ],
        files: panelImg ? [panelImg] : [],
        components,
      });
      await i.reply({ embeds: [successEmbed("panel sent")], ephemeral: true });
    } else if (sub === "list") {
      const rows = db
        .prepare("SELECT panel, role_id, label FROM self_roles WHERE guild_id = ? ORDER BY panel")
        .all(i.guild.id) as { panel: string; role_id: string; label: string }[];
      if (!rows.length) {
        await i.reply({ embeds: [aetherEmbed({ description: "> no panels yet" })] });
        return;
      }
      const grouped: Record<string, string[]> = {};
      for (const r of rows) {
        (grouped[r.panel] ??= []).push(`> \`${r.label}\` <@&${r.role_id}>`);
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# self-role panels",
            description: Object.entries(grouped)
              .map(([p, list]) => `**${p}**\n${list.join("\n")}`)
              .join("\n\n"),
          }),
        ],
      });
    }
  },
});
