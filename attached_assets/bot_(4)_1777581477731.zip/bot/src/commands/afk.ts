import { SlashCommandBuilder } from "discord.js";
import { register } from "../commandRegistry.ts";
import { setAfk, clearAfk } from "../services/afk.ts";
import { successEmbed, aetherEmbed } from "../embeds.ts";
import { addXp } from "../services/leveling.ts";
import { COLORS } from "../config.ts";
import { formatDuration } from "../util.ts";

register({
  category: "afk",
  data: new SlashCommandBuilder()
    .setName("afk")
    .setDescription("mark yourself as away — earn 100 xp on return + see who pinged you")
    .addStringOption((o) => o.setName("reason").setDescription("why are you away?")),
  async execute(i) {
    if (!i.guild) return;
    const reason = i.options.getString("reason") ?? "afk";
    setAfk(i.guild.id, i.user.id, reason);
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "✦ you are afk",
          description: `> **reason**: *${reason}*\n> reward: **+100 xp** when you come back`,
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "afk",
  data: new SlashCommandBuilder().setName("away").setDescription("alias for /afk")
    .addStringOption((o) => o.setName("reason").setDescription("why are you away?")),
  async execute(i) {
    if (!i.guild) return;
    const reason = i.options.getString("reason") ?? "afk";
    setAfk(i.guild.id, i.user.id, reason);
    await i.reply({
      embeds: [aetherEmbed({ title: "✦ you are away", description: `> *${reason}*`, color: COLORS.accent })],
    });
  },
});

// shared helper called from messageCreate to clear an AFK and reward
export function clearAndRewardAfk(guildId: string, userId: string) {
  const prev = clearAfk(guildId, userId);
  if (!prev) return null;
  addXp(guildId, userId, 100);
  return prev;
}

export function buildReturnEmbed(prev: { reason: string; since: number; mentions: number }) {
  return aetherEmbed({
    title: "# welcome back",
    description: [
      `> you were away for **${formatDuration(Date.now() - prev.since)}**`,
      `> reason: *${prev.reason}*`,
      `> pings while away: **${prev.mentions}**`,
      `> reward: \`+100 xp\``,
    ].join("\n"),
    color: COLORS.accent,
  });
}

export { successEmbed };
