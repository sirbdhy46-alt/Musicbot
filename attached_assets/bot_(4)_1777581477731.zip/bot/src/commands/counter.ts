import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("counter")
    .setDescription("voice channel that displays a stat")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand((s) =>
      s
        .setName("create")
        .setDescription("create a counter voice channel")
        .addStringOption((o) =>
          o
            .setName("type")
            .setDescription("what to count")
            .setRequired(true)
            .addChoices(
              { name: "all members", value: "members" },
              { name: "humans", value: "humans" },
              { name: "bots", value: "bots" },
              { name: "boosts", value: "boosts" },
              { name: "online", value: "online" },
            ),
        )
        .addStringOption((o) =>
          o
            .setName("template")
            .setDescription("name template — use {count}")
            .setRequired(false),
        ),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list counters"))
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("delete a counter")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("the counter channel").setRequired(true),
        ),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "create") {
      const type = i.options.getString("type", true);
      const template = i.options.getString("template") ?? defaultTemplate(type);
      try {
        const ch = await i.guild.channels.create({
          name: renderTemplate(template, computeCount(i.guild, type)),
          type: ChannelType.GuildVoice,
          permissionOverwrites: [{ id: i.guild.id, deny: ["Connect"] }],
        });
        db.prepare(
          "INSERT INTO counters (guild_id, channel_id, type, template) VALUES (?, ?, ?, ?)",
        ).run(i.guild.id, ch.id, type, template);
        await i.reply({ embeds: [successEmbed(`counter created → <#${ch.id}>`)] });
      } catch (err) {
        await i.reply({ embeds: [errorEmbed((err as Error).message)] });
      }
      return;
    }
    if (sub === "list") {
      const rows = db.prepare("SELECT channel_id, type FROM counters WHERE guild_id = ?").all(i.guild.id) as {
        channel_id: string;
        type: string;
      }[];
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "counters",
            description: rows.length ? rows.map((r) => `> <#${r.channel_id}> · **${r.type}**`).join("\n") : "> _none_",
            color: COLORS.accent,
          }),
        ],
      });
      return;
    }
    const ch = i.options.getChannel("channel", true);
    db.prepare("DELETE FROM counters WHERE guild_id = ? AND channel_id = ?").run(i.guild.id, ch.id);
    await i.guild.channels.delete(ch.id, "counter removed").catch(() => null);
    await i.reply({ embeds: [successEmbed("counter removed")] });
  },
});

function defaultTemplate(type: string): string {
  switch (type) {
    case "members":
      return "✦ members: {count}";
    case "humans":
      return "✦ humans: {count}";
    case "bots":
      return "✦ bots: {count}";
    case "boosts":
      return "✦ boosts: {count}";
    case "online":
      return "✦ online: {count}";
    default:
      return "✦ count: {count}";
  }
}

export function renderTemplate(tpl: string, count: number): string {
  return tpl.replace(/\{count\}/g, String(count));
}

export function computeCount(guild: import("discord.js").Guild, type: string): number {
  switch (type) {
    case "members":
      return guild.memberCount;
    case "humans":
      return guild.members.cache.filter((m) => !m.user.bot).size;
    case "bots":
      return guild.members.cache.filter((m) => m.user.bot).size;
    case "boosts":
      return guild.premiumSubscriptionCount ?? 0;
    case "online":
      return guild.members.cache.filter((m) => m.presence?.status === "online").size;
    default:
      return 0;
  }
}
