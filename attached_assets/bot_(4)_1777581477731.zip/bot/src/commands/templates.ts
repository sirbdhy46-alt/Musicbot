import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { TEMPLATES, findTemplate } from "../data/templates.ts";
import { applyTemplate } from "../services/templateApply.ts";
import { aetherEmbed, errorEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { chunk } from "../util.ts";

register({
  category: "templates",
  data: new SlashCommandBuilder()
    .setName("template")
    .setDescription(`50+ aesthetic server templates`)
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName("list")
        .setDescription("browse all templates")
        .addIntegerOption((o) => o.setName("page").setDescription("page (1-N)").setMinValue(1)),
    )
    .addSubcommand((s) =>
      s
        .setName("preview")
        .setDescription("preview a template's structure")
        .addStringOption((o) => o.setName("id").setDescription("template id").setRequired(true).setAutocomplete(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("apply")
        .setDescription("ADD this template's roles + categories on top of current server")
        .addStringOption((o) => o.setName("id").setDescription("template id").setRequired(true).setAutocomplete(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("wipe-apply")
        .setDescription("⚠ WIPES current channels & roles, then applies template")
        .addStringOption((o) => o.setName("id").setDescription("template id").setRequired(true).setAutocomplete(true)),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "list") {
      const page = i.options.getInteger("page") ?? 1;
      const pages = chunk(TEMPLATES, 12);
      const p = pages[page - 1] ?? pages[0];
      await i.reply({
        embeds: [
          aetherEmbed({
            title: `# templates ${"" /* */}`,
            description: [
              `> **${TEMPLATES.length}** total templates`,
              `> use \`/template preview <id>\` to inspect`,
              ``,
              ...p.map((t) => `\`${t.id.padEnd(16)}\` ${t.vibe}`),
              ``,
              `> page **${page}/${pages.length}**`,
            ].join("\n"),
            color: COLORS.accent,
          }),
        ],
      });
    } else if (sub === "preview") {
      const id = i.options.getString("id", true);
      const t = findTemplate(id);
      if (!t) {
        await i.reply({ embeds: [errorEmbed(`unknown template \`${id}\``)], ephemeral: true });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: `# ${t.name}`,
            description: [
              `> *${t.vibe}*`,
              ``,
              `**roles** _(${t.roles.length})_`,
              t.roles.map((r) => `> \`#${r.color.toString(16).padStart(6, "0")}\` ${r.name}`).join("\n"),
              ``,
              `**channels** _(${t.categories.reduce((acc, c) => acc + c.channels.length, 0)})_`,
              t.categories
                .map(
                  (c) => `> **${c.name}**\n${c.channels.map((ch) => `>  ${ch.type === "voice" ? "🔊" : "#"} ${ch.name}`).join("\n")}`,
                )
                .join("\n"),
            ].join("\n"),
            color: t.palette[0],
          }),
        ],
      });
    } else if (sub === "apply" || sub === "wipe-apply") {
      const id = i.options.getString("id", true);
      const t = findTemplate(id);
      if (!t) {
        await i.reply({ embeds: [errorEmbed(`unknown template \`${id}\``)], ephemeral: true });
        return;
      }
      const wipe = sub === "wipe-apply";
      const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`tpl-confirm:${t.id}:${wipe ? "1" : "0"}`).setLabel(wipe ? "WIPE & APPLY" : "apply").setStyle(wipe ? ButtonStyle.Danger : ButtonStyle.Success),
        new ButtonBuilder().setCustomId("tpl-cancel").setLabel("cancel").setStyle(ButtonStyle.Secondary),
      );
      await i.reply({
        embeds: [
          aetherEmbed({
            title: wipe ? "# ⚠ confirm WIPE & apply" : "# confirm apply",
            description: [
              `> template: **${t.name}**`,
              `> vibe: *${t.vibe}*`,
              wipe
                ? `> **THIS WILL DELETE all current channels & roles you can manage**`
                : `> existing channels/roles will be kept; new ones will be added`,
            ].join("\n"),
            color: wipe ? COLORS.danger : COLORS.accent,
          }),
        ],
        components: [confirmRow],
      });

      const reply = await i.fetchReply();
      try {
        const press = await reply.awaitMessageComponent({
          componentType: ComponentType.Button,
          time: 30_000,
          filter: (b) => b.user.id === i.user.id,
        });
        if (press.customId === "tpl-cancel") {
          await press.update({ embeds: [aetherEmbed({ description: "> cancelled" })], components: [] });
          return;
        }
        await press.update({
          embeds: [aetherEmbed({ description: "◐ building...", color: COLORS.ghost })],
          components: [],
        });
        const result = await applyTemplate(i.guild, t, { wipe });
        await i.editReply({
          embeds: [
            aetherEmbed({
              title: "✓ template applied",
              description: [
                `> roles created: **${result.rolesCreated}**`,
                `> channels created: **${result.channelsCreated}**`,
                result.errors.length ? `> errors: \`${result.errors.length}\`` : "> no errors",
              ].join("\n"),
              color: COLORS.success,
            }),
          ],
        });
      } catch {
        await i.editReply({
          embeds: [aetherEmbed({ description: "> confirmation timed out" })],
          components: [],
        });
      }
    }
  },
});
