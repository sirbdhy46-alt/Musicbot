import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import fs from "node:fs/promises";
import path from "node:path";
import { register } from "../commandRegistry.ts";
import { aetherEmbed, successEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

const ASSETS_DIR = path.resolve("assets/emojis");

register({
  category: "templates",
  data: new SlashCommandBuilder()
    .setName("uploademojis")
    .setDescription("upload the entire AETHER aesthetic emoji pack to this server (admin only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuildExpressions)
    .addBooleanOption((o) =>
      o
        .setName("overwrite")
        .setDescription("re-upload emojis that already exist (default: skip existing)"),
    ),
  async execute(i) {
    if (!i.guild) return;
    const overwrite = i.options.getBoolean("overwrite") ?? false;

    if (
      !i.guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuildExpressions) &&
      !i.guild.members.me?.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)
    ) {
      await i.reply({
        embeds: [errorEmbed("AETHER needs **Manage Expressions** to upload emojis here")],
        ephemeral: true,
      });
      return;
    }

    let files: string[];
    try {
      files = await fs.readdir(ASSETS_DIR);
    } catch {
      await i.reply({
        embeds: [errorEmbed(`emoji pack folder not found: \`${ASSETS_DIR}\``)],
        ephemeral: true,
      });
      return;
    }

    const candidates = files.filter((f) => /\.(png|gif|jpe?g|webp)$/i.test(f));
    if (candidates.length === 0) {
      await i.reply({
        embeds: [errorEmbed("no emoji files found in the asset folder")],
        ephemeral: true,
      });
      return;
    }

    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# ◐ uploading emoji pack...",
          description: `> processing **${candidates.length}** emoji(s) — please wait`,
          color: COLORS.ghost,
        }),
      ],
    });

    let uploaded = 0;
    let skipped = 0;
    let failed = 0;
    const errors: string[] = [];

    // Discord guild emoji limit per tier: 50/100/150/250
    const tierLimits = [50, 100, 150, 250];
    const limit = tierLimits[i.guild.premiumTier] ?? 50;
    const currentCount = i.guild.emojis.cache.size;
    let remaining = limit - currentCount;

    for (const file of candidates) {
      const name = path
        .basename(file, path.extname(file))
        .toLowerCase()
        .replace(/[^a-z0-9_]/g, "_")
        .slice(0, 32);

      const existing = i.guild.emojis.cache.find((e) => e.name === name);
      if (existing && !overwrite) {
        skipped++;
        continue;
      }
      if (remaining <= 0) {
        failed++;
        errors.push(`${name}: server emoji limit reached`);
        continue;
      }
      try {
        if (existing && overwrite) {
          await existing.delete("uploademojis overwrite").catch(() => null);
        }
        const buf = await fs.readFile(path.join(ASSETS_DIR, file));
        await i.guild.emojis.create({ attachment: buf, name });
        uploaded++;
        remaining--;
      } catch (e) {
        failed++;
        const msg = (e as Error).message.slice(0, 80);
        errors.push(`${name}: ${msg}`);
      }
    }

    await i.editReply({
      embeds: [
        successEmbed(
          [
            `**emoji pack uploaded**`,
            `> uploaded: **${uploaded}**`,
            `> skipped (already existed): **${skipped}**`,
            failed ? `> failed: **${failed}**` : `> no failures`,
            `> server slots used: **${currentCount + uploaded} / ${limit}**`,
            errors.length
              ? `\n\`\`\`\n${errors.slice(0, 6).join("\n")}\n\`\`\``
              : "",
          ].join("\n"),
        ),
      ],
    });
  },
});
