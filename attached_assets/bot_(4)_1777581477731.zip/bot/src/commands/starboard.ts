import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { successEmbed, aetherEmbed } from "../embeds.ts";

register({
  category: "starboard",
  data: new SlashCommandBuilder()
    .setName("starboard")
    .setDescription("starboard config")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("channel")
        .setDescription("set starboard channel")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("threshold")
        .setDescription("set ⭐ threshold")
        .addIntegerOption((o) => o.setName("count").setDescription("count").setMinValue(1).setRequired(true)),
    )
    .addSubcommand((s) => s.setName("status").setDescription("show config")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "channel") {
      const ch = i.options.getChannel("channel", true);
      db.prepare("UPDATE guild_config SET starboard_channel = ? WHERE guild_id = ?").run(ch.id, i.guild.id);
      await i.reply({ embeds: [successEmbed(`starboard → <#${ch.id}>`)] });
    } else if (sub === "threshold") {
      const c = i.options.getInteger("count", true);
      db.prepare("UPDATE guild_config SET starboard_threshold = ? WHERE guild_id = ?").run(c, i.guild.id);
      await i.reply({ embeds: [successEmbed(`threshold = ${c}`)] });
    } else if (sub === "status") {
      const cfg = db
        .prepare("SELECT starboard_channel, starboard_threshold FROM guild_config WHERE guild_id = ?")
        .get(i.guild.id) as { starboard_channel: string | null; starboard_threshold: number } | undefined;
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# starboard",
            description: `> **channel**: ${cfg?.starboard_channel ? `<#${cfg.starboard_channel}>` : "_none_"}\n> **threshold**: ${cfg?.starboard_threshold ?? 3} ⭐`,
          }),
        ],
      });
    }
  },
});
