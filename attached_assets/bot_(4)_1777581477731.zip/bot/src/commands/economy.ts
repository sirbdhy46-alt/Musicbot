import { SlashCommandBuilder } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { formatDuration } from "../util.ts";

function getWallet(guildId: string, userId: string) {
  let row = db
    .prepare("SELECT * FROM economy WHERE guild_id = ? AND user_id = ?")
    .get(guildId, userId) as
    | { coins: number; bank: number; last_daily: number; last_work: number }
    | undefined;
  if (!row) {
    db.prepare(
      "INSERT INTO economy (guild_id, user_id, coins, bank, last_daily, last_work) VALUES (?, ?, 0, 0, 0, 0)",
    ).run(guildId, userId);
    row = { coins: 0, bank: 0, last_daily: 0, last_work: 0 };
  }
  return row;
}

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("show your coins")
    .addUserOption((o) => o.setName("user").setDescription("user")),
  async execute(i) {
    if (!i.guild) return;
    const u = i.options.getUser("user") ?? i.user;
    const w = getWallet(i.guild.id, u.id);
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# ${u.username}'s wallet`,
          description: `> **wallet** \`${w.coins}\` coins\n> **bank** \`${w.bank}\` coins`,
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder().setName("daily").setDescription("claim your daily 250 coins"),
  async execute(i) {
    if (!i.guild) return;
    const w = getWallet(i.guild.id, i.user.id);
    const cooldown = 86_400_000;
    if (Date.now() - w.last_daily < cooldown) {
      await i.reply({
        embeds: [errorEmbed(`come back in **${formatDuration(cooldown - (Date.now() - w.last_daily))}**`)],
        ephemeral: true,
      });
      return;
    }
    db.prepare("UPDATE economy SET coins = coins + 250, last_daily = ? WHERE guild_id = ? AND user_id = ?").run(
      Date.now(),
      i.guild.id,
      i.user.id,
    );
    await i.reply({ embeds: [aetherEmbed({ description: "> +**250** coins claimed", color: COLORS.success })] });
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder().setName("work").setDescription("work for some coins"),
  async execute(i) {
    if (!i.guild) return;
    const w = getWallet(i.guild.id, i.user.id);
    const cooldown = 1_800_000;
    if (Date.now() - w.last_work < cooldown) {
      await i.reply({
        embeds: [errorEmbed(`rest for **${formatDuration(cooldown - (Date.now() - w.last_work))}**`)],
        ephemeral: true,
      });
      return;
    }
    const earned = 50 + Math.floor(Math.random() * 150);
    db.prepare("UPDATE economy SET coins = coins + ?, last_work = ? WHERE guild_id = ? AND user_id = ?").run(
      earned,
      Date.now(),
      i.guild.id,
      i.user.id,
    );
    const jobs = [
      "drove a delivery",
      "live-streamed for 4 hours",
      "ran an aesthetic discord raid (legally)",
      "freelanced a logo",
      "DJ'd a basement set",
      "wrote 3 hot takes",
    ];
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# work",
          description: `> ${jobs[Math.floor(Math.random() * jobs.length)]}\n> earned **${earned}** coins`,
          color: COLORS.success,
        }),
      ],
    });
  },
});
