import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { successEmbed, errorEmbed, aetherEmbed } from "../embeds.ts";
import { handleJoin } from "../services/welcome.ts";

register({
  category: "welcome",
  data: new SlashCommandBuilder()
    .setName("welcome")
    .setDescription("welcome system setup")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("enable")
        .setDescription("toggle welcome on/off")
        .addBooleanOption((o) => o.setName("on").setDescription("enabled?").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("channel")
        .setDescription("set welcome channel")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("message")
        .setDescription("custom welcome message (use {user}, {server}, {member.count})")
        .addStringOption((o) => o.setName("text").setDescription("message").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("gif")
        .setDescription("welcome gif search query")
        .addStringOption((o) => o.setName("query").setDescription("e.g. 'anime welcome'").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("test").setDescription("preview welcome message with you"))
    .addSubcommand((s) => s.setName("status").setDescription("show welcome config")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "enable") {
      const on = i.options.getBoolean("on", true);
      db.prepare("UPDATE guild_config SET welcome_enabled = ? WHERE guild_id = ?").run(on ? 1 : 0, i.guild.id);
      await i.reply({ embeds: [successEmbed(`welcome ${on ? "enabled" : "disabled"}`)] });
    } else if (sub === "channel") {
      const ch = i.options.getChannel("channel", true);
      db.prepare("UPDATE guild_config SET welcome_channel = ? WHERE guild_id = ?").run(ch.id, i.guild.id);
      await i.reply({ embeds: [successEmbed(`welcome channel → <#${ch.id}>`)] });
    } else if (sub === "message") {
      const text = i.options.getString("text", true);
      db.prepare("UPDATE guild_config SET welcome_message = ? WHERE guild_id = ?").run(text, i.guild.id);
      await i.reply({ embeds: [successEmbed("welcome message updated")] });
    } else if (sub === "gif") {
      const q = i.options.getString("query", true);
      db.prepare("UPDATE guild_config SET welcome_gif_query = ? WHERE guild_id = ?").run(q, i.guild.id);
      await i.reply({ embeds: [successEmbed(`welcome gif query = \`${q}\``)] });
    } else if (sub === "test") {
      await i.deferReply({ ephemeral: true });
      const member = await i.guild.members.fetch(i.user.id);
      await handleJoin(member);
      await i.editReply({ embeds: [successEmbed("test sent")] });
    } else if (sub === "status") {
      const cfg = db
        .prepare(
          "SELECT welcome_enabled, welcome_channel, welcome_message, welcome_gif_query FROM guild_config WHERE guild_id = ?",
        )
        .get(i.guild.id) as
        | {
            welcome_enabled: number;
            welcome_channel: string | null;
            welcome_message: string | null;
            welcome_gif_query: string | null;
          }
        | undefined;
      if (!cfg) {
        await i.reply({ embeds: [errorEmbed("no config")] });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# welcome status",
            description: [
              `> **enabled**: ${cfg.welcome_enabled ? "yes" : "no"}`,
              `> **channel**: ${cfg.welcome_channel ? `<#${cfg.welcome_channel}>` : "_none_"}`,
              `> **gif query**: \`${cfg.welcome_gif_query ?? "welcome"}\``,
              ``,
              `> **message**:`,
              `\`\`\`${cfg.welcome_message ?? "(default)"}\`\`\``,
            ].join("\n"),
          }),
        ],
      });
    }
  },
});

register({
  category: "welcome",
  data: new SlashCommandBuilder()
    .setName("leave")
    .setDescription("leave/goodbye system setup")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("enable")
        .setDescription("toggle leave message on/off")
        .addBooleanOption((o) => o.setName("on").setDescription("enabled?").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("channel")
        .setDescription("set leave channel")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("message")
        .setDescription("custom leave message")
        .addStringOption((o) => o.setName("text").setDescription("message").setRequired(true)),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "enable") {
      const on = i.options.getBoolean("on", true);
      db.prepare("UPDATE guild_config SET leave_enabled = ? WHERE guild_id = ?").run(on ? 1 : 0, i.guild.id);
      await i.reply({ embeds: [successEmbed(`leave ${on ? "enabled" : "disabled"}`)] });
    } else if (sub === "channel") {
      const ch = i.options.getChannel("channel", true);
      db.prepare("UPDATE guild_config SET leave_channel = ? WHERE guild_id = ?").run(ch.id, i.guild.id);
      await i.reply({ embeds: [successEmbed(`leave channel → <#${ch.id}>`)] });
    } else if (sub === "message") {
      const text = i.options.getString("text", true);
      db.prepare("UPDATE guild_config SET leave_message = ? WHERE guild_id = ?").run(text, i.guild.id);
      await i.reply({ embeds: [successEmbed("leave message updated")] });
    }
  },
});
