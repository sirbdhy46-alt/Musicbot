import { SlashCommandBuilder } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("highlight")
    .setDescription("get notified when keywords are mentioned")
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("add a keyword to track")
        .addStringOption((o) => o.setName("word").setDescription("keyword").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("remove a keyword")
        .addStringOption((o) => o.setName("word").setDescription("keyword").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list your keywords"))
    .addSubcommand((s) => s.setName("clear").setDescription("clear all keywords")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "add") {
      const w = i.options.getString("word", true).toLowerCase().slice(0, 60);
      db.prepare("INSERT OR IGNORE INTO highlights (user_id, guild_id, word) VALUES (?, ?, ?)").run(
        i.user.id,
        i.guild.id,
        w,
      );
      await i.reply({ embeds: [successEmbed(`tracking \`${w}\``)], ephemeral: true });
      return;
    }
    if (sub === "remove") {
      const w = i.options.getString("word", true).toLowerCase();
      db.prepare("DELETE FROM highlights WHERE user_id = ? AND guild_id = ? AND word = ?").run(
        i.user.id,
        i.guild.id,
        w,
      );
      await i.reply({ embeds: [successEmbed(`removed \`${w}\``)], ephemeral: true });
      return;
    }
    if (sub === "clear") {
      db.prepare("DELETE FROM highlights WHERE user_id = ? AND guild_id = ?").run(i.user.id, i.guild.id);
      await i.reply({ embeds: [successEmbed("all highlights cleared")], ephemeral: true });
      return;
    }
    const rows = db
      .prepare("SELECT word FROM highlights WHERE user_id = ? AND guild_id = ?")
      .all(i.user.id, i.guild.id) as { word: string }[];
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "your highlights",
          description: rows.length ? rows.map((r) => `> ${r.word}`).join("\n") : "> _none_",
          color: COLORS.accent,
        }),
      ],
      ephemeral: true,
    });
  },
});
