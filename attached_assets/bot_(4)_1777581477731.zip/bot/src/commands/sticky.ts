import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("sticky")
    .setDescription("sticky message in this channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand((s) =>
      s
        .setName("set")
        .setDescription("set the sticky")
        .addStringOption((o) => o.setName("content").setDescription("text to stick").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("remove").setDescription("remove the sticky"))
    .addSubcommand((s) => s.setName("show").setDescription("show the current sticky")),
  async execute(i) {
    if (!i.guild || !i.channel) return;
    const sub = i.options.getSubcommand();
    if (sub === "set") {
      if (i.channel.type !== ChannelType.GuildText) return;
      const content = i.options.getString("content", true);
      db.prepare(
        "INSERT INTO stickies (channel_id, guild_id, content, last_message_id, msg_count) VALUES (?, ?, ?, NULL, 0) ON CONFLICT(channel_id) DO UPDATE SET content = excluded.content, last_message_id = NULL, msg_count = 0",
      ).run(i.channel.id, i.guild.id, content);
      await i.reply({ embeds: [successEmbed("sticky set in this channel")] });
      return;
    }
    if (sub === "remove") {
      const row = db.prepare("SELECT last_message_id FROM stickies WHERE channel_id = ?").get(i.channel.id) as
        | { last_message_id: string | null }
        | undefined;
      db.prepare("DELETE FROM stickies WHERE channel_id = ?").run(i.channel.id);
      if (row?.last_message_id && i.channel.type === ChannelType.GuildText) {
        await i.channel.messages.delete(row.last_message_id).catch(() => null);
      }
      await i.reply({ embeds: [successEmbed("sticky removed")] });
      return;
    }
    const cur = db.prepare("SELECT content FROM stickies WHERE channel_id = ?").get(i.channel.id) as
      | { content: string }
      | undefined;
    await i.reply({
      embeds: [aetherEmbed({ description: cur ? `> ${cur.content}` : "> _no sticky here_", color: COLORS.ghost })],
    });
  },
});
