import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed } from "../embeds.ts";

register({
  category: "autoresponder",
  data: new SlashCommandBuilder()
    .setName("ar")
    .setDescription("autoresponder triggers")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("trigger a response")
        .addStringOption((o) => o.setName("trigger").setDescription("trigger phrase").setRequired(true))
        .addStringOption((o) => o.setName("response").setDescription("bot reply").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("remove a trigger")
        .addStringOption((o) => o.setName("trigger").setDescription("trigger").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list autoresponders")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "add") {
      const t = i.options.getString("trigger", true).toLowerCase();
      const r = i.options.getString("response", true);
      db.prepare(
        `INSERT INTO auto_responders (guild_id, trigger, response) VALUES (?, ?, ?)
         ON CONFLICT(guild_id, trigger) DO UPDATE SET response = excluded.response`,
      ).run(i.guild.id, t, r);
      await i.reply({ embeds: [successEmbed(`added \`${t}\` → ${r.slice(0, 80)}`)] });
    } else if (sub === "remove") {
      const t = i.options.getString("trigger", true).toLowerCase();
      db.prepare("DELETE FROM auto_responders WHERE guild_id = ? AND trigger = ?").run(i.guild.id, t);
      await i.reply({ embeds: [successEmbed(`removed \`${t}\``)] });
    } else if (sub === "list") {
      const rows = db
        .prepare("SELECT trigger, response FROM auto_responders WHERE guild_id = ?")
        .all(i.guild.id) as { trigger: string; response: string }[];
      if (!rows.length) {
        await i.reply({ embeds: [aetherEmbed({ description: "> no triggers" })] });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# autoresponders",
            description: rows.map((r) => `\`${r.trigger}\` → ${r.response.slice(0, 60)}`).join("\n"),
          }),
        ],
      });
    }
  },
});
