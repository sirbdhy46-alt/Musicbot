import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ComponentType,
  type Guild,
  type CategoryChannel,
  type Role,
  type GuildBasedChannel,
  type ColorResolvable,
} from "discord.js";
import fs from "node:fs";
import path from "node:path";
import { register } from "../commandRegistry.ts";
import { aetherEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { actionReply } from "../services/banners.ts";
import {
  COLOR_ROLES,
  colorRoleHexToInt,
  makeColorPaletteImage,
  makeServerInfoImage,
  makeAnimatedWelcomeGif,
  makeCategoryBanner,
  makeSelfrolePanelImage,
  THEMES,
  getTheme,
} from "../services/setupImages.ts";
import { db } from "../db.ts";
import { emoji } from "../services/emojis.ts";

interface RoleSpec {
  name: string;
  color: number;
  hoist: boolean;
  mentionable?: boolean;
  permissions?: bigint;
}

interface ChannelSpec {
  name: string;
  type: "text" | "voice";
  topic?: string;
  slowmode?: number;
  nsfw?: boolean;
}

interface CategorySpec {
  name: string;
  staffOnly?: boolean;
  channels: ChannelSpec[];
}

const ADMIN_PERMS = PermissionFlagsBits.Administrator;
const MOD_PERMS =
  PermissionFlagsBits.ManageMessages |
  PermissionFlagsBits.KickMembers |
  PermissionFlagsBits.BanMembers |
  PermissionFlagsBits.ModerateMembers |
  PermissionFlagsBits.ManageChannels |
  PermissionFlagsBits.MuteMembers |
  PermissionFlagsBits.DeafenMembers |
  PermissionFlagsBits.MoveMembers;
const HELPER_PERMS =
  PermissionFlagsBits.ManageMessages | PermissionFlagsBits.ModerateMembers | PermissionFlagsBits.MuteMembers;

const STAFF_ROLES: RoleSpec[] = [
  { name: "✦ founder", color: 0x7f1d1d, hoist: true, permissions: ADMIN_PERMS },
  { name: "✦ co-owner", color: 0x991b1b, hoist: true, permissions: ADMIN_PERMS },
  { name: "✦ head admin", color: 0xb91c1c, hoist: true, permissions: ADMIN_PERMS },
  { name: "✦ admin", color: 0xdc2626, hoist: true, permissions: ADMIN_PERMS },
  { name: "✦ head mod", color: 0xea580c, hoist: true, permissions: MOD_PERMS | PermissionFlagsBits.ManageRoles },
  { name: "✦ senior mod", color: 0xf97316, hoist: true, permissions: MOD_PERMS },
  { name: "✦ moderator", color: 0xfb923c, hoist: true, permissions: MOD_PERMS },
  { name: "✦ junior mod", color: 0xfdba74, hoist: true, permissions: HELPER_PERMS },
  { name: "✦ helper", color: 0xfde68a, hoist: true, permissions: HELPER_PERMS },
  { name: "✦ event manager", color: 0xa855f7, hoist: true, permissions: PermissionFlagsBits.ManageEvents | PermissionFlagsBits.MentionEveryone },
  { name: "✦ giveaway manager", color: 0xc026d3, hoist: true, permissions: PermissionFlagsBits.ManageMessages },
  { name: "✦ ticket manager", color: 0x0ea5e9, hoist: true, permissions: PermissionFlagsBits.ManageThreads },
  { name: "✦ vip", color: 0xfacc15, hoist: true },
  { name: "✦ booster", color: 0xec4899, hoist: true },
  { name: "✦ member", color: 0xe5e7eb, hoist: false },
  { name: "✦ bot", color: 0x6366f1, hoist: false },
  { name: "✦ muted", color: 0x374151, hoist: false },
];

const STAFF_ROLE_NAMES = new Set([
  "✦ founder",
  "✦ co-owner",
  "✦ head admin",
  "✦ admin",
  "✦ head mod",
  "✦ senior mod",
  "✦ moderator",
  "✦ junior mod",
  "✦ helper",
]);

const STRUCTURE: CategorySpec[] = [
  {
    name: "📋 INFORMATION",
    channels: [
      { name: "rules", type: "text", topic: "Read these before posting." },
      { name: "announcements", type: "text", topic: "Server-wide news and updates." },
      { name: "server-info", type: "text", topic: "About this server." },
      { name: "roles", type: "text", topic: "Pick your color and notification roles." },
      { name: "changelog", type: "text", topic: "Server changes and additions." },
    ],
  },
  {
    name: "👋 WELCOME",
    channels: [
      { name: "welcome", type: "text", topic: "New members appear here." },
      { name: "introductions", type: "text", topic: "Introduce yourself to the community." },
      { name: "leavers", type: "text", topic: "Members who left." },
    ],
  },
  {
    name: "💬 COMMUNITY",
    channels: [
      { name: "chat", type: "text", topic: "General conversation." },
      { name: "off-topic", type: "text", topic: "Anything goes (within rules)." },
      { name: "memes", type: "text", topic: "Drop your best memes." },
      { name: "media", type: "text", topic: "Share photos and videos." },
      { name: "art", type: "text", topic: "Showcase your creative work." },
      { name: "music-share", type: "text", topic: "Share what you're listening to." },
    ],
  },
  {
    name: "🎮 FUN",
    channels: [
      { name: "bot-commands", type: "text", topic: "Use AETHER's slash commands here." },
      { name: "counting", type: "text", topic: "Count up by 1. Don't break the chain." },
      { name: "games", type: "text", topic: "Play games with the bot." },
      { name: "polls", type: "text", topic: "Run polls with /poll." },
      { name: "suggestions", type: "text", topic: "Suggest improvements for the server." },
    ],
  },
  {
    name: "🎫 SUPPORT",
    channels: [
      { name: "open-ticket", type: "text", topic: "Use /ticket here to get help." },
      { name: "faq", type: "text", topic: "Frequently asked questions." },
    ],
  },
  {
    name: "📈 LEVELS",
    channels: [
      { name: "leaderboard", type: "text", topic: "See the top chatters with /leaderboard." },
      { name: "level-ups", type: "text", topic: "Level-up announcements." },
    ],
  },
  {
    name: "🎉 EVENTS",
    channels: [
      { name: "events", type: "text", topic: "Upcoming events and tournaments." },
      { name: "giveaways", type: "text", topic: "Active giveaways." },
    ],
  },
  {
    name: "🔨 STAFF",
    staffOnly: true,
    channels: [
      { name: "staff-chat", type: "text", topic: "Private staff discussion." },
      { name: "mod-logs", type: "text", topic: "Moderation actions log." },
      { name: "audit-logs", type: "text", topic: "Audit trail of server changes." },
      { name: "reports", type: "text", topic: "User reports land here." },
      { name: "mod-commands", type: "text", topic: "Staff command testing." },
      { name: "staff-voice", type: "voice" },
    ],
  },
  {
    name: "🔊 VOICE",
    channels: [
      { name: "General", type: "voice" },
      { name: "Music", type: "voice" },
      { name: "Gaming", type: "voice" },
      { name: "Chill", type: "voice" },
      { name: "Study", type: "voice" },
      { name: "AFK", type: "voice" },
    ],
  },
  {
    name: "📦 ARCHIVE",
    staffOnly: true,
    channels: [{ name: "archive", type: "text", topic: "Old / archived channels." }],
  },
];

interface SetupResult {
  rolesCreated: number;
  channelsCreated: number;
  categoriesCreated: number;
  errors: string[];
}

async function wipeGuild(guild: Guild) {
  for (const ch of guild.channels.cache.values()) {
    if ("deletable" in ch && ch.deletable && ch.id !== guild.systemChannelId) {
      await ch.delete("autosetup wipe").catch(() => null);
    }
  }
  for (const r of guild.roles.cache.values()) {
    if (r.editable && !r.managed && r.id !== guild.id) {
      await r.delete("autosetup wipe").catch(() => null);
    }
  }
}

async function ensureRole(guild: Guild, spec: RoleSpec): Promise<Role | null> {
  const existing = guild.roles.cache.find((r) => r.name === spec.name);
  if (existing) return existing;
  try {
    return await guild.roles.create({
      name: spec.name,
      color: spec.color as ColorResolvable,
      hoist: spec.hoist,
      mentionable: spec.mentionable ?? false,
      permissions: spec.permissions,
      reason: "autosetup",
    });
  } catch {
    return null;
  }
}

async function runAutoSetup(
  guild: Guild,
  opts: { wipe: boolean; themeId?: string },
): Promise<SetupResult> {
  const result: SetupResult = { rolesCreated: 0, channelsCreated: 0, categoriesCreated: 0, errors: [] };

  if (opts.wipe) await wipeGuild(guild);

  const staffRoleIds: string[] = [];
  for (const spec of STAFF_ROLES) {
    const before = guild.roles.cache.size;
    const role = await ensureRole(guild, spec);
    if (role) {
      if (guild.roles.cache.size > before) result.rolesCreated++;
      if (STAFF_ROLE_NAMES.has(spec.name)) {
        staffRoleIds.push(role.id);
      }
    } else {
      result.errors.push(`role ${spec.name}`);
    }
  }

  for (const c of COLOR_ROLES) {
    const before = guild.roles.cache.size;
    const role = await ensureRole(guild, {
      name: c.name,
      color: colorRoleHexToInt(c.hex),
      hoist: false,
    });
    if (role && guild.roles.cache.size > before) result.rolesCreated++;
    if (!role) result.errors.push(`color role ${c.name}`);
  }

  const mutedRole = guild.roles.cache.find((r) => r.name === "✦ muted");

  const createdChannels: Record<string, GuildBasedChannel> = {};

  for (const cat of STRUCTURE) {
    try {
      const existingCat = guild.channels.cache.find(
        (c) => c.type === ChannelType.GuildCategory && c.name === cat.name,
      ) as CategoryChannel | undefined;

      const permissionOverwrites = cat.staffOnly
        ? [
            { id: guild.roles.everyone.id, deny: PermissionFlagsBits.ViewChannel },
            ...staffRoleIds.map((rid) => ({
              id: rid,
              allow: PermissionFlagsBits.ViewChannel | PermissionFlagsBits.SendMessages,
            })),
          ]
        : undefined;

      let category: CategoryChannel;
      let isNewCategory = false;
      if (existingCat) {
        category = existingCat;
      } else {
        category = await guild.channels.create({
          name: cat.name,
          type: ChannelType.GuildCategory,
          permissionOverwrites,
          reason: "autosetup",
        });
        result.categoriesCreated++;
        isNewCategory = true;
      }

      const firstTextChannelName = cat.channels.find((c) => c.type === "text")?.name;

      for (const ch of cat.channels) {
        const exists = guild.channels.cache.find(
          (c) => c.parentId === category.id && c.name === ch.name.toLowerCase(),
        );
        if (exists) {
          createdChannels[ch.name] = exists;
          continue;
        }
        const created = await guild.channels.create({
          name: ch.name,
          type: ch.type === "voice" ? ChannelType.GuildVoice : ChannelType.GuildText,
          parent: category.id,
          topic: ch.topic,
          rateLimitPerUser: ch.slowmode,
          nsfw: ch.nsfw,
          reason: "autosetup",
        });
        createdChannels[ch.name] = created;
        result.channelsCreated++;

        if (mutedRole && ch.type === "text") {
          await created.permissionOverwrites
            .create(mutedRole, { SendMessages: false, AddReactions: false, SendMessagesInThreads: false })
            .catch(() => null);
        }
      }

      if (isNewCategory && firstTextChannelName) {
        const headerCh = createdChannels[firstTextChannelName];
        if (headerCh && headerCh.type === ChannelType.GuildText) {
          try {
            const subtitle = cat.staffOnly
              ? getTheme(opts.themeId).vibe + " · staff only"
              : getTheme(opts.themeId).vibe;
            const banner = await makeCategoryBanner(cat.name, subtitle, opts.themeId);
            await headerCh.send({ files: [banner] }).catch(() => null);
          } catch {
            // ignore banner failures
          }
        }
      }
    } catch (e) {
      result.errors.push(`category ${cat.name}: ${(e as Error).message}`);
    }
  }

  const afk = createdChannels["AFK"];
  if (afk && afk.type === ChannelType.GuildVoice) {
    await guild.setAFKChannel(afk.id, "autosetup").catch(() => null);
    await guild.setAFKTimeout(300, "autosetup").catch(() => null);
  }

  const sys = createdChannels["welcome"];
  if (sys && sys.type === ChannelType.GuildText) {
    await guild.setSystemChannel(sys.id, "autosetup").catch(() => null);
  }

  await postSeedContent(guild, createdChannels, opts.themeId).catch((e) => {
    result.errors.push(`seed posts: ${(e as Error).message}`);
  });

  return result;
}

function buildColorRoleRows(roleMap: Map<string, string>): ActionRowBuilder<ButtonBuilder>[] {
  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  let row = new ActionRowBuilder<ButtonBuilder>();
  let count = 0;
  for (const c of COLOR_ROLES) {
    const roleId = roleMap.get(c.name);
    if (!roleId) continue;
    const btn = new ButtonBuilder()
      .setCustomId(`crole:${roleId}`)
      .setLabel(c.name.replace("✦ ", ""))
      .setStyle(ButtonStyle.Secondary);
    row.addComponents(btn);
    count++;
    if (count % 5 === 0) {
      rows.push(row);
      row = new ActionRowBuilder<ButtonBuilder>();
    }
    if (rows.length >= 4) break; // Discord max 5 rows; leave one for clear button
  }
  if (row.components.length && rows.length < 5) rows.push(row);
  // clear color row
  const clear = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("crole:clear")
      .setLabel("✕ remove my color")
      .setStyle(ButtonStyle.Danger),
  );
  if (rows.length < 5) rows.push(clear);
  return rows;
}

async function postSeedContent(
  guild: Guild,
  ch: Record<string, GuildBasedChannel>,
  themeId?: string,
) {
  const theme = getTheme(themeId);
  const rules = ch["rules"];
  if (rules && rules.type === ChannelType.GuildText) {
    await rules.send({
      embeds: [
        aetherEmbed({
          title: "# 📜 server rules",
          description: [
            "> following these keeps the realm civil",
            "",
            "**1.** be respectful — no harassment, hate, slurs, or doxxing",
            "**2.** no spam, raids, or self-promotion without permission",
            "**3.** no nsfw outside designated channels",
            "**4.** keep politics and religious debates out of public channels",
            "**5.** use channels for their intended purpose",
            "**6.** discord ToS applies — underage accounts will be removed",
            "**7.** staff decisions are final · appeal in `#open-ticket`",
            "",
            "> breaking rules → warn → mute → kick → ban",
          ].join("\n"),
          color: COLORS.danger,
        }),
      ],
    });
  }

  const info = ch["server-info"];
  if (info && info.type === ChannelType.GuildText) {
    const banner = await makeServerInfoImage(guild, themeId);
    await info.send({
      embeds: [
        aetherEmbed({
          title: `# about ${guild.name}`,
          description: [
            "> a community powered by **AETHER**",
            "",
            "**get started**",
            "> `1.` read `#rules`",
            "> `2.` introduce yourself in `#introductions`",
            "> `3.` grab a color in `#roles`",
            "> `4.` jump into `#chat` or a voice room",
            "",
            "**need help?** open a ticket in `#open-ticket`",
          ].join("\n"),
          image: "attachment://server-info.png",
          color: COLORS.accent,
        }),
      ],
      files: [banner],
    });
  }

  const roles = ch["roles"];
  if (roles && roles.type === ChannelType.GuildText) {
    const palette = await makeColorPaletteImage(themeId);
    // Map color role name → role id (so buttons can toggle them)
    const roleMap = new Map<string, string>();
    for (const c of COLOR_ROLES) {
      const r = guild.roles.cache.find((rr) => rr.name === c.name);
      if (r) roleMap.set(c.name, r.id);
    }
    const buttonRows = buildColorRoleRows(roleMap);
    await roles.send({
      embeds: [
        aetherEmbed({
          title: `# choose your hue`,
          description: [
            `> ${theme.vibe} · tap a button to claim a color`,
            "> tap the same button again to remove it",
            "",
            "**only one color at a time** — picking a new one swaps it",
          ].join("\n"),
          image: "attachment://color-palette.png",
          color: COLORS.info,
        }),
      ],
      files: [palette],
      components: buttonRows,
    });
  }

  // Auto-post the ticket panel in #open-ticket
  const ticketCh = ch["open-ticket"];
  if (ticketCh && ticketCh.type === ChannelType.GuildText) {
    // Find or create ticket category + staff role
    const ticketCat = guild.channels.cache.find(
      (c) => c.type === ChannelType.GuildCategory && c.name.toLowerCase().includes("ticket"),
    );
    const staffRole =
      guild.roles.cache.find((r) => r.name === "✦ ticket manager") ||
      guild.roles.cache.find((r) => r.name === "✦ moderator") ||
      guild.roles.cache.find((r) => r.name === "✦ admin");

    if (ticketCat && staffRole) {
      db.prepare(
        "INSERT INTO ticket_config (guild_id, panel_channel, category, staff_role, log_channel, prompt) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET panel_channel = excluded.panel_channel, category = excluded.category, staff_role = excluded.staff_role, prompt = excluded.prompt",
      ).run(
        guild.id,
        ticketCh.id,
        ticketCat.id,
        staffRole.id,
        null,
        `${theme.vibe} · click below to open a private ticket with staff`,
      );
      const ticketRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId("ticket-open")
          .setLabel("open a ticket")
          .setEmoji("🎫")
          .setStyle(ButtonStyle.Danger),
      );
      await ticketCh.send({
        embeds: [
          aetherEmbed({
            title: `# ${emoji("aether_ticket")} need help?`,
            description: [
              `> ${theme.vibe}`,
              "",
              `> ${emoji("aether_ticket")} a private channel just for you & staff`,
              `> ${emoji("aether_lock")} other members can't see it`,
              `> ${emoji("aether_check")} a staff member will respond as soon as possible`,
            ].join("\n"),
            color: COLORS.accent,
          }),
        ],
        components: [ticketRow],
      });
    }
  }

  // Selfrole vibe panel in #roles below color picker
  if (ch["roles"]?.type === ChannelType.GuildText) {
    const selfPanel = await makeSelfrolePanelImage("self roles", themeId);
    await (ch["roles"] as import("discord.js").TextChannel)
      .send({ files: [selfPanel] })
      .catch(() => null);
  }

  const welcome = ch["welcome"];
  if (welcome && welcome.type === ChannelType.GuildText) {
    const animated = await makeAnimatedWelcomeGif(guild, themeId).catch(() => null);
    const fallback = path.resolve(process.cwd(), "artifacts/bot/assets/welcome_banner.png");
    const files = animated
      ? [animated]
      : fs.existsSync(fallback)
        ? [{ attachment: fallback, name: "welcome.png" }]
        : undefined;
    const imgName = animated ? "attachment://welcome.gif" : files ? "attachment://welcome.png" : undefined;
    await welcome.send({
      embeds: [
        aetherEmbed({
          title: `# welcome to ${guild.name}`,
          description: [
            "> the gates are open",
            "",
            "new members appear here automatically.",
            "use `/welcome` to customize the greeter.",
          ].join("\n"),
          image: imgName,
          color: COLORS.accent,
        }),
      ],
      files,
    });
  }

  const bots = ch["bot-commands"];
  if (bots && bots.type === ChannelType.GuildText) {
    await bots.send({
      embeds: [
        aetherEmbed({
          title: "# AETHER · bot commands",
          description: [
            "> use slash commands here to keep other channels clean",
            "",
            "**try these**",
            "> `/help` — full command index",
            "> `/8ball <q>` · `/coinflip` · `/rps`",
            "> `/hug @user` · `/slap @user` · `/ship @a @b`",
            "> `/poll` · `/giveaway` · `/remind`",
            "> `/level` · `/leaderboard`",
          ].join("\n"),
          color: COLORS.info,
        }),
      ],
    });
  }

  const announce = ch["announcements"];
  if (announce && announce.type === ChannelType.GuildText) {
    await announce.send({
      embeds: [
        aetherEmbed({
          title: "# 📢 server is live",
          description: [
            `> **${guild.name}** has been auto-configured by AETHER`,
            "",
            "> categories, channels, roles, and color palette are ready",
            "> staff can tweak anything from here",
          ].join("\n"),
          color: COLORS.success,
        }),
      ],
    });
  }
}

register({
  category: "templates",
  data: new SlashCommandBuilder()
    .setName("autosetup")
    .setDescription("auto-build the entire server: channels, roles, color roles, info image, palette, AFK, perms")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((o) =>
      o
        .setName("theme")
        .setDescription("aesthetic theme for all banners & images")
        .addChoices(...THEMES.map((t) => ({ name: t.name, value: t.id }))),
    )
    .addBooleanOption((o) =>
      o
        .setName("wipe")
        .setDescription("⚠ wipe all current channels & roles before setup (dangerous)"),
    ),
  async execute(i) {
    if (!i.guild) return;
    if (!i.guild.members.me?.permissions.has(PermissionFlagsBits.Administrator)) {
      await i.reply({
        embeds: [errorEmbed("AETHER needs the **Administrator** permission to auto-setup this server.")],
        ephemeral: true,
      });
      return;
    }
    const wipe = i.options.getBoolean("wipe") ?? false;
    const themeId = i.options.getString("theme") ?? "blood-rose";
    const theme = getTheme(themeId);

    const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("autosetup-go")
        .setLabel(wipe ? "WIPE & BUILD" : "build")
        .setStyle(wipe ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder().setCustomId("autosetup-cancel").setLabel("cancel").setStyle(ButtonStyle.Secondary),
    );

    const totalChannels = STRUCTURE.reduce((acc, c) => acc + c.channels.length, 0);
    const totalRoles = STAFF_ROLES.length + COLOR_ROLES.length;

    await i.reply({
      embeds: [
        aetherEmbed({
          title: wipe ? "# ⚠ confirm WIPE & auto-setup" : "# confirm auto-setup",
          description: [
            wipe
              ? "> **this will delete every channel and role AETHER can manage, then rebuild**"
              : "> existing channels/roles will be kept; only missing ones will be added",
            "",
            `**plan**`,
            `> categories: **${STRUCTURE.length}**`,
            `> channels: **${totalChannels}** (text + voice)`,
            `> roles: **${totalRoles}** (${STAFF_ROLES.length} staff/utility + ${COLOR_ROLES.length} color)`,
            `> theme: **${theme.name}** · *${theme.vibe}*`,
            `> bonus: **AFK channel**, **muted role perms**, **server-info image**, **color palette w/ buttons**, **auto ticket panel**, **seeded rules + welcome + announcements**`,
            "",
            "> press a button within 30s",
          ].join("\n"),
          color: wipe ? COLORS.danger : COLORS.accent,
        }),
      ],
      components: [confirmRow],
    });

    const reply = await i.fetchReply();
    try {
      const press = await reply.awaitMessageComponent({
        componentType: ComponentType.Button,
        time: 30_000,
        filter: (b) => b.user.id === i.user.id,
      });
      if (press.customId === "autosetup-cancel") {
        await press.update({ embeds: [aetherEmbed({ description: "> cancelled" })], components: [] });
        return;
      }
      await press.update({
        embeds: [
          aetherEmbed({
            title: "# ◐ building your server...",
            description: "> this may take 30-90 seconds depending on size",
            color: COLORS.ghost,
          }),
        ],
        components: [],
      });
      const result = await runAutoSetup(i.guild, { wipe, themeId });
      await i.editReply(
        actionReply("unlock", {
          title: "# ✓ server auto-setup complete",
          description: [
            `> categories created: **${result.categoriesCreated}**`,
            `> channels created: **${result.channelsCreated}**`,
            `> roles created: **${result.rolesCreated}**`,
            result.errors.length ? `> errors: \`${result.errors.length}\`` : "> no errors",
            "",
            "> seeded **#rules**, **#server-info**, **#roles**, **#welcome**, **#bot-commands**, **#announcements**",
            "> AFK channel + muted role permissions configured",
          ].join("\n"),
          color: COLORS.success,
        }),
      );
    } catch {
      await i.editReply({
        embeds: [aetherEmbed({ description: "> confirmation timed out" })],
        components: [],
      });
    }
  },
});
