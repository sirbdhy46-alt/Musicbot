import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

const EVENTS = [
  "messageDelete",
  "messageEdit",
  "memberJoin",
  "memberLeave",
  "memberBan",
  "memberKick",
  "memberTimeout",
  "channelCreate",
  "channelDelete",
  "roleCreate",
  "roleDelete",
  "voiceJoin",
  "voiceLeave",
];

register({
  category: "logging",
  data: new SlashCommandBuilder()
    .setName("log")
    .setDescription("server logging configuration")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("channel")
        .setDescription("set the log channel")
        .addChannelOption((o) => o.setName("channel").setDescription("channel").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("event")
        .setDescription("toggle a log event")
        .addStringOption((o) =>
          o
            .setName("event")
            .setDescription("event name")
            .setRequired(true)
            .addChoices(...EVENTS.map((e) => ({ name: e, value: e }))),
        ),
    )
    .addSubcommand((s) => s.setName("status").setDescription("show logging status"))
    .addSubcommand((s) => s.setName("disable").setDescription("disable all logging")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    const cfg = (db.prepare("SELECT channel_id, events FROM log_config WHERE guild_id = ?").get(i.guild.id) as
      | { channel_id: string | null; events: string }
      | undefined) ?? { channel_id: null, events: "[]" };
    let events: string[] = JSON.parse(cfg.events);

    if (sub === "channel") {
      const ch = i.options.getChannel("channel", true);
      db.prepare(
        "INSERT INTO log_config (guild_id, channel_id, events) VALUES (?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET channel_id = excluded.channel_id",
      ).run(i.guild.id, ch.id, JSON.stringify(events));
      await i.reply({ embeds: [successEmbed(`log channel → <#${ch.id}>`)] });
      return;
    }
    if (sub === "event") {
      const ev = i.options.getString("event", true);
      const had = events.includes(ev);
      events = had ? events.filter((e) => e !== ev) : [...events, ev];
      db.prepare(
        "INSERT INTO log_config (guild_id, channel_id, events) VALUES (?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET events = excluded.events",
      ).run(i.guild.id, cfg.channel_id, JSON.stringify(events));
      await i.reply({ embeds: [successEmbed(`event \`${ev}\` ${had ? "disabled" : "enabled"}`)] });
      return;
    }
    if (sub === "disable") {
      db.prepare("DELETE FROM log_config WHERE guild_id = ?").run(i.guild.id);
      await i.reply({ embeds: [successEmbed("logging disabled")] });
      return;
    }
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "logging",
          description: `> channel: ${cfg.channel_id ? `<#${cfg.channel_id}>` : "_none_"}\n> events: ${events.length ? events.join(", ") : "_none_"}`,
          color: COLORS.accent,
        }),
      ],
    });
  },
});
