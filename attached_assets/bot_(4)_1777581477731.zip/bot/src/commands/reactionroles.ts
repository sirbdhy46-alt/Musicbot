import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  type GuildTextBasedChannel,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { successEmbed, errorEmbed } from "../embeds.ts";

register({
  category: "selfroles",
  data: new SlashCommandBuilder()
    .setName("reactionrole")
    .setDescription("classic emoji-reaction roles")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("bind an emoji on a message to grant a role")
        .addStringOption((o) => o.setName("message-id").setDescription("message id (in this channel)").setRequired(true))
        .addStringOption((o) => o.setName("emoji").setDescription("emoji").setRequired(true))
        .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("remove a reaction role binding")
        .addStringOption((o) => o.setName("message-id").setDescription("message id").setRequired(true))
        .addStringOption((o) => o.setName("emoji").setDescription("emoji").setRequired(true)),
    ),
  async execute(i) {
    if (!i.guild || !i.channel) return;
    const sub = i.options.getSubcommand();
    if (sub === "add") {
      const messageId = i.options.getString("message-id", true);
      const emoji = i.options.getString("emoji", true);
      const role = i.options.getRole("role", true);
      const ch = i.channel as GuildTextBasedChannel;
      const msg = await ch.messages.fetch(messageId).catch(() => null);
      if (!msg) {
        await i.reply({ embeds: [errorEmbed("message not found in this channel")], ephemeral: true });
        return;
      }
      try {
        await msg.react(emoji);
      } catch {
        await i.reply({ embeds: [errorEmbed("can't react with that emoji")], ephemeral: true });
        return;
      }
      db.prepare(
        `INSERT OR REPLACE INTO reaction_roles (guild_id, message_id, emoji, role_id) VALUES (?, ?, ?, ?)`,
      ).run(i.guild.id, messageId, emoji, role.id);
      await i.reply({ embeds: [successEmbed(`bound ${emoji} → <@&${role.id}>`)] });
    } else if (sub === "remove") {
      const messageId = i.options.getString("message-id", true);
      const emoji = i.options.getString("emoji", true);
      db.prepare("DELETE FROM reaction_roles WHERE message_id = ? AND emoji = ?").run(messageId, emoji);
      await i.reply({ embeds: [successEmbed("removed")] });
    }
  },
});
