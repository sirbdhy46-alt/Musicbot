import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder,
  type GuildTextBasedChannel,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, errorEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

function buildFromOptions(o: {
  title?: string | null;
  description?: string | null;
  color?: string | null;
  thumbnail?: string | null;
  image?: string | null;
  footer?: string | null;
  author?: string | null;
}): EmbedBuilder {
  const e = new EmbedBuilder();
  if (o.title) e.setTitle(o.title);
  if (o.description) e.setDescription(o.description.replaceAll("\\n", "\n"));
  if (o.color) {
    const c = parseInt(o.color.replace("#", ""), 16);
    if (!Number.isNaN(c)) e.setColor(c);
  } else {
    e.setColor(COLORS.accent);
  }
  if (o.thumbnail) e.setThumbnail(o.thumbnail);
  if (o.image) e.setImage(o.image);
  if (o.footer) e.setFooter({ text: o.footer });
  if (o.author) e.setAuthor({ name: o.author });
  return e;
}

register({
  category: "embed",
  data: new SlashCommandBuilder()
    .setName("embed")
    .setDescription("custom embed builder")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand((s) =>
      s
        .setName("send")
        .setDescription("send a custom embed")
        .addChannelOption((o) =>
          o.setName("channel").setDescription("channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        )
        .addStringOption((o) => o.setName("title").setDescription("title (use # in description for big bold)"))
        .addStringOption((o) =>
          o.setName("description").setDescription("description — use \\n for newline, # text for bold header, **text** for bold"),
        )
        .addStringOption((o) => o.setName("color").setDescription("hex color e.g. #b91c1c"))
        .addStringOption((o) => o.setName("thumbnail").setDescription("thumbnail url"))
        .addStringOption((o) => o.setName("image").setDescription("image url"))
        .addStringOption((o) => o.setName("footer").setDescription("footer text"))
        .addStringOption((o) => o.setName("author").setDescription("author text"))
        .addStringOption((o) => o.setName("content").setDescription("plain text above embed (e.g. role ping)")),
    )
    .addSubcommand((s) =>
      s
        .setName("save")
        .setDescription("save an embed by name to reuse later")
        .addStringOption((o) => o.setName("name").setDescription("embed name").setRequired(true))
        .addStringOption((o) => o.setName("title").setDescription("title"))
        .addStringOption((o) => o.setName("description").setDescription("description"))
        .addStringOption((o) => o.setName("color").setDescription("hex"))
        .addStringOption((o) => o.setName("thumbnail").setDescription("thumbnail url"))
        .addStringOption((o) => o.setName("image").setDescription("image url"))
        .addStringOption((o) => o.setName("footer").setDescription("footer"))
        .addStringOption((o) => o.setName("author").setDescription("author")),
    )
    .addSubcommand((s) =>
      s
        .setName("post")
        .setDescription("post a saved embed")
        .addStringOption((o) => o.setName("name").setDescription("name").setRequired(true).setAutocomplete(true))
        .addChannelOption((o) =>
          o.setName("channel").setDescription("channel").addChannelTypes(ChannelType.GuildText).setRequired(true),
        ),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list saved embeds"))
    .addSubcommand((s) =>
      s
        .setName("delete")
        .setDescription("delete a saved embed")
        .addStringOption((o) => o.setName("name").setDescription("name").setRequired(true).setAutocomplete(true)),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "send") {
      const ch = i.options.getChannel("channel", true);
      const channel = (await i.guild.channels.fetch(ch.id)) as GuildTextBasedChannel;
      const embed = buildFromOptions({
        title: i.options.getString("title"),
        description: i.options.getString("description"),
        color: i.options.getString("color"),
        thumbnail: i.options.getString("thumbnail"),
        image: i.options.getString("image"),
        footer: i.options.getString("footer"),
        author: i.options.getString("author"),
      });
      const content = i.options.getString("content") ?? undefined;
      try {
        await channel.send({ content, embeds: [embed] });
        await i.reply({ embeds: [successEmbed(`sent to <#${ch.id}>`)], ephemeral: true });
      } catch (e) {
        await i.reply({ embeds: [errorEmbed((e as Error).message)], ephemeral: true });
      }
    } else if (sub === "save") {
      const name = i.options.getString("name", true);
      const data = {
        title: i.options.getString("title"),
        description: i.options.getString("description"),
        color: i.options.getString("color"),
        thumbnail: i.options.getString("thumbnail"),
        image: i.options.getString("image"),
        footer: i.options.getString("footer"),
        author: i.options.getString("author"),
      };
      db.prepare(
        `INSERT INTO embeds (guild_id, name, json, author_id) VALUES (?, ?, ?, ?)
         ON CONFLICT(guild_id, name) DO UPDATE SET json = excluded.json, author_id = excluded.author_id`,
      ).run(i.guild.id, name, JSON.stringify(data), i.user.id);
      await i.reply({ embeds: [successEmbed(`saved embed \`${name}\``)] });
    } else if (sub === "post") {
      const name = i.options.getString("name", true);
      const ch = i.options.getChannel("channel", true);
      const row = db
        .prepare("SELECT json FROM embeds WHERE guild_id = ? AND name = ?")
        .get(i.guild.id, name) as { json: string } | undefined;
      if (!row) {
        await i.reply({ embeds: [errorEmbed(`no embed \`${name}\``)], ephemeral: true });
        return;
      }
      const channel = (await i.guild.channels.fetch(ch.id)) as GuildTextBasedChannel;
      const embed = buildFromOptions(JSON.parse(row.json));
      await channel.send({ embeds: [embed] });
      await i.reply({ embeds: [successEmbed(`posted to <#${ch.id}>`)], ephemeral: true });
    } else if (sub === "list") {
      const rows = db
        .prepare("SELECT name, author_id FROM embeds WHERE guild_id = ?")
        .all(i.guild.id) as { name: string; author_id: string }[];
      if (!rows.length) {
        await i.reply({ embeds: [aetherEmbed({ description: "> no saved embeds" })] });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# saved embeds",
            description: rows.map((r) => `\`${r.name}\` — by <@${r.author_id}>`).join("\n"),
          }),
        ],
      });
    } else if (sub === "delete") {
      const name = i.options.getString("name", true);
      db.prepare("DELETE FROM embeds WHERE guild_id = ? AND name = ?").run(i.guild.id, name);
      await i.reply({ embeds: [successEmbed(`deleted \`${name}\``)] });
    }
  },
});
