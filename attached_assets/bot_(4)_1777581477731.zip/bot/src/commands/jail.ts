import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db, getGuildConfig } from "../db.ts";
import { successEmbed, errorEmbed, aetherEmbed } from "../embeds.ts";
import { vibeGif } from "../services/giphy.ts";
import { COLORS } from "../config.ts";
import { actionBanner } from "../services/banners.ts";

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("jail-setup")
    .setDescription("create jail role + jail channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async execute(i) {
    if (!i.guild) return;
    await i.deferReply();
    const role = await i.guild.roles.create({
      name: "jailed",
      color: 0x111111,
      reason: "jail setup",
    });
    const everyone = i.guild.roles.everyone;
    const jailLog = await i.guild.channels.create({
      name: "jail-log",
      type: ChannelType.GuildText,
      permissionOverwrites: [{ id: everyone.id, deny: [PermissionFlagsBits.ViewChannel] }],
    });
    const jailChannel = await i.guild.channels.create({
      name: "jail",
      type: ChannelType.GuildText,
      permissionOverwrites: [
        { id: everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: role.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
          deny: [PermissionFlagsBits.SendMessages],
        },
      ],
    });

    // strip jailed role from every other channel
    for (const ch of i.guild.channels.cache.values()) {
      if (ch.id === jailChannel.id || ch.id === jailLog.id) continue;
      if ("permissionOverwrites" in ch) {
        await ch.permissionOverwrites
          .edit(role.id, {
            ViewChannel: false,
            SendMessages: false,
            ReadMessageHistory: false,
          })
          .catch(() => null);
      }
    }

    db.prepare(
      "UPDATE guild_config SET jail_role = ?, jail_channel = ?, jail_log_channel = ? WHERE guild_id = ?",
    ).run(role.id, jailChannel.id, jailLog.id, i.guild.id);

    await i.editReply({
      embeds: [
        successEmbed(
          `jail ready\n> role: <@&${role.id}>\n> channel: <#${jailChannel.id}>\n> log: <#${jailLog.id}>`,
        ),
      ],
    });
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("jail")
    .setDescription("send a member to jail")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("reason"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(i) {
    if (!i.guild) return;
    const cfg = getGuildConfig(i.guild.id) as {
      jail_role: string | null;
      jail_channel: string | null;
      jail_log_channel: string | null;
    };
    if (!cfg.jail_role) {
      await i.reply({ embeds: [errorEmbed("run `/jail-setup` first")], ephemeral: true });
      return;
    }
    const user = i.options.getUser("user", true);
    const reason = i.options.getString("reason") ?? "no reason";
    const m = await i.guild.members.fetch(user.id).catch(() => null);
    if (!m) {
      await i.reply({ embeds: [errorEmbed("not in server")], ephemeral: true });
      return;
    }
    const previous = m.roles.cache.filter((r) => r.id !== i.guild!.id).map((r) => r.id);
    db.prepare(
      `INSERT INTO mod_cases (guild_id, user_id, mod_id, type, reason, ts) VALUES (?, ?, ?, 'jail', ?, ?)`,
    ).run(i.guild.id, user.id, i.user.id, JSON.stringify({ reason, prev: previous }), Date.now());
    await m.roles.set([cfg.jail_role], `jailed by ${i.user.tag}: ${reason}`).catch(() => null);

    // Welcome message in the jail channel itself — first message includes the fixed welcome GIF
    if (cfg.jail_channel) {
      const jailCh = await i.guild.channels.fetch(cfg.jail_channel).catch(() => null);
      if (jailCh?.isTextBased()) {
        const banner = actionBanner("jail");
        const welcomeEmbed = aetherEmbed({
          title: "# welcome to the jail",
          description:
            `> ${user}, you have been confined.\n` +
            `> **mod**: ${i.user}\n` +
            `> **reason**: ${reason}\n` +
            `> wait quietly — a moderator will release you when ready.`,
          color: COLORS.danger,
          image: banner?.image,
          timestamp: true,
        });
        await jailCh
          .send({
            content: `<@${user.id}>`,
            embeds: [welcomeEmbed],
            files: banner ? [banner.attachment] : [],
          })
          .catch(() => null);
      }
    }

    if (cfg.jail_log_channel) {
      const log = await i.guild.channels.fetch(cfg.jail_log_channel).catch(() => null);
      if (log?.isTextBased()) {
        await log.send({
          embeds: [
            aetherEmbed({
              title: "# member jailed",
              description: `> **target**: ${user}\n> **mod**: ${i.user}\n> **reason**: ${reason}`,
            }),
          ],
        });
      }
    }
    const replyBanner = actionBanner("jail");
    const gif = await vibeGif("jail");
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# member jailed",
          description: `> **${user.tag}** confined\n> **reason**: ${reason}`,
          color: COLORS.danger,
          image: gif,
          thumbnail: replyBanner?.image,
        }),
      ],
      files: replyBanner ? [replyBanner.attachment] : [],
    });
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("unjail")
    .setDescription("release someone from jail")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(i) {
    if (!i.guild) return;
    const cfg = getGuildConfig(i.guild.id) as { jail_role: string | null };
    if (!cfg.jail_role) {
      await i.reply({ embeds: [errorEmbed("run `/jail-setup` first")], ephemeral: true });
      return;
    }
    const user = i.options.getUser("user", true);
    const m = await i.guild.members.fetch(user.id).catch(() => null);
    if (!m) {
      await i.reply({ embeds: [errorEmbed("not in server")], ephemeral: true });
      return;
    }
    const lastJail = db
      .prepare(
        "SELECT reason FROM mod_cases WHERE guild_id = ? AND user_id = ? AND type = 'jail' ORDER BY ts DESC LIMIT 1",
      )
      .get(i.guild.id, user.id) as { reason: string } | undefined;
    let prev: string[] = [];
    if (lastJail) {
      try {
        const data = JSON.parse(lastJail.reason);
        if (Array.isArray(data.prev)) prev = data.prev as string[];
      } catch {
        /* ignore */
      }
    }
    await m.roles.set(prev, `unjailed by ${i.user.tag}`).catch(() => null);
    const banner = actionBanner("unjail");
    const gif = await vibeGif("unjail");
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# released from jail",
          description: `> **${user.tag}** is free again`,
          color: COLORS.success,
          image: gif,
          thumbnail: banner?.image,
        }),
      ],
      files: banner ? [banner.attachment] : [],
    });
  },
});
