import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("customrole")
    .setDescription("personal custom role (booster perk)")
    .addSubcommand((s) =>
      s
        .setName("setup")
        .setDescription("configure")
        .addRoleOption((o) => o.setName("base_role").setDescription("position to insert above").setRequired(true))
        .addRoleOption((o) => o.setName("required_role").setDescription("role required to claim (e.g. booster role)").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("create")
        .setDescription("create your custom role")
        .addStringOption((o) => o.setName("name").setDescription("role name").setRequired(true))
        .addStringOption((o) => o.setName("color").setDescription("hex like #ff0044")),
    )
    .addSubcommand((s) =>
      s
        .setName("edit")
        .setDescription("edit your custom role")
        .addStringOption((o) => o.setName("name").setDescription("new name"))
        .addStringOption((o) => o.setName("color").setDescription("hex color")),
    )
    .addSubcommand((s) => s.setName("delete").setDescription("delete your custom role")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "setup") {
      if (!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        await i.reply({ embeds: [errorEmbed("manage server required")], ephemeral: true });
        return;
      }
      const base = i.options.getRole("base_role", true);
      const req = i.options.getRole("required_role", true);
      db.prepare(
        "INSERT INTO customrole_config (guild_id, base_role, required_role) VALUES (?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET base_role = excluded.base_role, required_role = excluded.required_role",
      ).run(i.guild.id, base.id, req.id);
      await i.reply({ embeds: [successEmbed(`custom role config saved · req <@&${req.id}>`)] });
      return;
    }

    const cfg = db
      .prepare("SELECT base_role, required_role FROM customrole_config WHERE guild_id = ?")
      .get(i.guild.id) as { base_role: string; required_role: string } | undefined;
    if (!cfg) {
      await i.reply({ embeds: [errorEmbed("custom roles not set up")], ephemeral: true });
      return;
    }
    const member = await i.guild.members.fetch(i.user.id);
    if (!member.roles.cache.has(cfg.required_role)) {
      await i.reply({
        embeds: [errorEmbed(`you need <@&${cfg.required_role}> to use custom roles`)],
        ephemeral: true,
      });
      return;
    }

    const existing = db
      .prepare("SELECT role_id FROM custom_roles WHERE guild_id = ? AND user_id = ?")
      .get(i.guild.id, i.user.id) as { role_id: string } | undefined;

    if (sub === "delete") {
      if (existing) {
        await i.guild.roles.delete(existing.role_id, "custom role delete").catch(() => null);
        db.prepare("DELETE FROM custom_roles WHERE guild_id = ? AND user_id = ?").run(i.guild.id, i.user.id);
      }
      await i.reply({ embeds: [successEmbed("your custom role is gone")] });
      return;
    }
    if (sub === "create") {
      if (existing) {
        await i.reply({ embeds: [errorEmbed("you already have one — use `/customrole edit`")], ephemeral: true });
        return;
      }
      const name = i.options.getString("name", true).slice(0, 32);
      const colorStr = i.options.getString("color") ?? "#ffffff";
      const color = parseInt(colorStr.replace("#", ""), 16) || 0xffffff;
      const baseRole = i.guild.roles.cache.get(cfg.base_role);
      const role = await i.guild.roles.create({ name, color, reason: "custom role" });
      if (baseRole) await role.setPosition(baseRole.position).catch(() => null);
      await member.roles.add(role.id, "custom role").catch(() => null);
      db.prepare("INSERT INTO custom_roles (guild_id, user_id, role_id) VALUES (?, ?, ?)").run(
        i.guild.id,
        i.user.id,
        role.id,
      );
      await i.reply({ embeds: [successEmbed(`custom role created → <@&${role.id}>`)] });
      return;
    }
    if (sub === "edit") {
      if (!existing) {
        await i.reply({ embeds: [errorEmbed("create one first")], ephemeral: true });
        return;
      }
      const role = i.guild.roles.cache.get(existing.role_id);
      if (!role) {
        await i.reply({ embeds: [errorEmbed("role missing — recreate it")], ephemeral: true });
        return;
      }
      const name = i.options.getString("name");
      const colorStr = i.options.getString("color");
      if (name) await role.setName(name.slice(0, 32)).catch(() => null);
      if (colorStr) {
        const color = parseInt(colorStr.replace("#", ""), 16);
        if (!isNaN(color)) await role.setColor(color).catch(() => null);
      }
      await i.reply({ embeds: [successEmbed("custom role updated")] });
    }
  },
});
