import { SlashCommandBuilder } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { emoji } from "../services/emojis.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("invites")
    .setDescription("invite tracking")
    .addSubcommand((s) =>
      s
        .setName("user")
        .setDescription("show a user's invite stats")
        .addUserOption((o) => o.setName("user").setDescription("user")),
    )
    .addSubcommand((s) => s.setName("leaderboard").setDescription("top inviters"))
    .addSubcommand((s) =>
      s
        .setName("inviter")
        .setDescription("show who invited a user")
        .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "user") {
      const u = i.options.getUser("user") ?? i.user;
      const row = db
        .prepare("SELECT total, left FROM invite_counts WHERE guild_id = ? AND user_id = ?")
        .get(i.guild.id, u.id) as { total: number; left: number } | undefined;
      const total = row?.total ?? 0;
      const left = row?.left ?? 0;
      await i.reply({
        embeds: [
          aetherEmbed({
            title: `${emoji("aether_dot")} ${u.username}'s invites`,
            description: `> joined: **${total}**\n> left: **${left}**\n> net: **${total - left}**`,
            color: COLORS.accent,
          }),
        ],
      });
      return;
    }
    if (sub === "leaderboard") {
      const rows = db
        .prepare(
          "SELECT user_id, total, left FROM invite_counts WHERE guild_id = ? ORDER BY (total - left) DESC LIMIT 10",
        )
        .all(i.guild.id) as { user_id: string; total: number; left: number }[];
      await i.reply({
        embeds: [
          aetherEmbed({
            title: `# invite leaderboard`,
            description: rows.length
              ? rows
                  .map(
                    (r, idx) =>
                      `> **${idx + 1}.** <@${r.user_id}> · **${r.total - r.left}** net (${r.total}/${r.left})`,
                  )
                  .join("\n")
              : "> _no invites tracked yet_",
            color: COLORS.accent,
          }),
        ],
      });
      return;
    }
    const u = i.options.getUser("user", true);
    const row = db
      .prepare("SELECT inviter_id, joined_at FROM invite_tracking WHERE guild_id = ? AND user_id = ?")
      .get(i.guild.id, u.id) as { inviter_id: string | null; joined_at: number } | undefined;
    await i.reply({
      embeds: [
        aetherEmbed({
          description: row?.inviter_id
            ? `> **${u.tag}** was invited by <@${row.inviter_id}>\n> joined <t:${Math.floor(row.joined_at / 1000)}:R>`
            : `> no invite data for **${u.tag}**`,
          color: COLORS.accent,
        }),
      ],
    });
  },
});
