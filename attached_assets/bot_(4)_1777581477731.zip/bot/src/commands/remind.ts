import { SlashCommandBuilder } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { formatDuration, parseDuration } from "../util.ts";
import { emoji } from "../services/emojis.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("remind")
    .setDescription("personal reminders")
    .addSubcommand((s) =>
      s
        .setName("me")
        .setDescription("set a reminder")
        .addStringOption((o) => o.setName("when").setDescription("e.g. 30m, 2h, 1d").setRequired(true))
        .addStringOption((o) => o.setName("about").setDescription("what to remind").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list your reminders"))
    .addSubcommand((s) =>
      s
        .setName("delete")
        .setDescription("delete a reminder by id")
        .addIntegerOption((o) => o.setName("id").setDescription("reminder id").setRequired(true)),
    ),
  async execute(i) {
    const sub = i.options.getSubcommand();
    if (sub === "me") {
      const dur = parseDuration(i.options.getString("when", true));
      if (!dur) {
        await i.reply({ embeds: [errorEmbed("invalid duration")], ephemeral: true });
        return;
      }
      const text = i.options.getString("about", true);
      db.prepare(
        "INSERT INTO reminders (user_id, channel_id, guild_id, message, remind_at) VALUES (?, ?, ?, ?, ?)",
      ).run(i.user.id, i.channelId ?? "", i.guildId, text, Date.now() + dur);
      await i.reply({
        embeds: [successEmbed(`${emoji("aether_moon")} reminder set for ${formatDuration(dur)}`)],
        ephemeral: true,
      });
      return;
    }
    if (sub === "list") {
      const rows = db
        .prepare("SELECT id, message, remind_at FROM reminders WHERE user_id = ? AND fired = 0 ORDER BY remind_at ASC LIMIT 20")
        .all(i.user.id) as { id: number; message: string; remind_at: number }[];
      await i.reply({
        embeds: [
          aetherEmbed({
            title: `${emoji("aether_moon")} your reminders`,
            description: rows.length
              ? rows
                  .map((r) => `> \`#${r.id}\` <t:${Math.floor(r.remind_at / 1000)}:R> — ${r.message}`)
                  .join("\n")
              : "> _no active reminders_",
            color: COLORS.accent,
          }),
        ],
        ephemeral: true,
      });
      return;
    }
    const id = i.options.getInteger("id", true);
    const result = db
      .prepare("DELETE FROM reminders WHERE id = ? AND user_id = ?")
      .run(id, i.user.id);
    await i.reply({
      embeds: [
        result.changes
          ? successEmbed(`reminder #${id} deleted`)
          : errorEmbed("not found or not yours"),
      ],
      ephemeral: true,
    });
  },
});
