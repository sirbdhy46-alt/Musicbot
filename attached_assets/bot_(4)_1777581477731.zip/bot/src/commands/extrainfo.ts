import { SlashCommandBuilder, ChannelType } from "discord.js";
import { register } from "../commandRegistry.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { emoji } from "../services/emojis.ts";

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("firstmessage")
    .setDescription("link to the first message in this channel"),
  async execute(i) {
    if (!i.channel || i.channel.type !== ChannelType.GuildText) return;
    await i.deferReply();
    const msgs = await i.channel.messages.fetch({ after: "0", limit: 1 }).catch(() => null);
    const first = msgs?.first();
    if (!first) {
      await i.editReply("couldn't find first message");
      return;
    }
    await i.editReply({
      embeds: [
        aetherEmbed({
          description: `# first message\n> by ${first.author}\n> [jump →](${first.url})\n> *${first.content || "_no content_"}*`,
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("inrole")
    .setDescription("list members in a role")
    .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true)),
  async execute(i) {
    if (!i.guild) return;
    const r = i.options.getRole("role", true);
    const role = i.guild.roles.cache.get(r.id);
    if (!role) return;
    const members = role.members.map((m) => `<@${m.id}>`).slice(0, 50);
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `${emoji("aether_dot")} ${role.name} · ${role.members.size} member(s)`,
          description: members.length ? members.join(" ") : "_none_",
          color: role.color || COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("membercount")
    .setDescription("show member statistics"),
  async execute(i) {
    if (!i.guild) return;
    const total = i.guild.memberCount;
    const bots = i.guild.members.cache.filter((m) => m.user.bot).size;
    const online = i.guild.members.cache.filter((m) => m.presence?.status === "online").size;
    await i.reply({
      embeds: [
        aetherEmbed({
          description: `# ${i.guild.name}\n> total: **${total}**\n> humans: **${total - bots}**\n> bots: **${bots}**\n> online: **${online}**`,
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("oldest")
    .setDescription("show oldest accounts in the server"),
  async execute(i) {
    if (!i.guild) return;
    const sorted = [...i.guild.members.cache.values()]
      .sort((a, b) => a.user.createdTimestamp - b.user.createdTimestamp)
      .slice(0, 10);
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# oldest accounts",
          description: sorted
            .map((m, idx) => `> **${idx + 1}.** <@${m.id}> · <t:${Math.floor(m.user.createdTimestamp / 1000)}:R>`)
            .join("\n"),
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("youngest")
    .setDescription("show youngest accounts in the server"),
  async execute(i) {
    if (!i.guild) return;
    const sorted = [...i.guild.members.cache.values()]
      .sort((a, b) => b.user.createdTimestamp - a.user.createdTimestamp)
      .slice(0, 10);
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# youngest accounts",
          description: sorted
            .map((m, idx) => `> **${idx + 1}.** <@${m.id}> · <t:${Math.floor(m.user.createdTimestamp / 1000)}:R>`)
            .join("\n"),
          color: COLORS.danger,
        }),
      ],
    });
  },
});

register({
  category: "info",
  data: new SlashCommandBuilder()
    .setName("emojipack")
    .setDescription("show the AETHER emoji pack status"),
  async execute(i) {
    const { getEmojiStatus } = await import("../services/emojis.ts");
    const s = getEmojiStatus();
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# AETHER emoji pack`,
          description: `> ${emoji("aether_check")} loaded: **${s.loaded.length}**\n> ${emoji("aether_x")} missing: **${s.missing.length}**\n\n**missing names** (upload these to the dev portal → Emojis tab):\n\`\`\`\n${s.missing.length ? s.missing.join("\n") : "(all uploaded ✓)"}\n\`\`\``,
          color: COLORS.accent,
        }),
      ],
      ephemeral: true,
    });
  },
});
