import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("autorole")
    .setDescription("auto-assign roles when members join")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((s) =>
      s
        .setName("add")
        .setDescription("add an autorole")
        .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true))
        .addBooleanOption((o) => o.setName("bots_only").setDescription("only assign to bots")),
    )
    .addSubcommand((s) =>
      s
        .setName("remove")
        .setDescription("remove an autorole")
        .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list autoroles")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "add") {
      const r = i.options.getRole("role", true);
      const botsOnly = i.options.getBoolean("bots_only") ? 1 : 0;
      db.prepare("INSERT OR REPLACE INTO autoroles (guild_id, role_id, bots_only) VALUES (?, ?, ?)").run(
        i.guild.id,
        r.id,
        botsOnly,
      );
      await i.reply({ embeds: [successEmbed(`autorole added: <@&${r.id}>${botsOnly ? " (bots only)" : ""}`)] });
      return;
    }
    if (sub === "remove") {
      const r = i.options.getRole("role", true);
      db.prepare("DELETE FROM autoroles WHERE guild_id = ? AND role_id = ?").run(i.guild.id, r.id);
      await i.reply({ embeds: [successEmbed(`autorole removed`)] });
      return;
    }
    const rows = db
      .prepare("SELECT role_id, bots_only FROM autoroles WHERE guild_id = ?")
      .all(i.guild.id) as { role_id: string; bots_only: number }[];
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "autoroles",
          description: rows.length
            ? rows.map((r) => `> <@&${r.role_id}>${r.bots_only ? " · bots only" : ""}`).join("\n")
            : "> _none_",
          color: COLORS.accent,
        }),
      ],
    });
  },
});
