import { SlashCommandBuilder } from "discord.js";
import { register } from "../commandRegistry.ts";
import { getDeleted, getEdited } from "../services/snipe.ts";
import { aetherEmbed, errorEmbed } from "../embeds.ts";
import { formatDuration } from "../util.ts";
import { COLORS } from "../config.ts";

register({
  category: "snipe",
  data: new SlashCommandBuilder()
    .setName("snipe")
    .setDescription("show recently deleted message in this channel")
    .addIntegerOption((o) => o.setName("index").setDescription("0 = latest").setMinValue(0).setMaxValue(9)),
  async execute(i) {
    if (!i.channel) return;
    const idx = i.options.getInteger("index") ?? 0;
    const s = getDeleted(i.channel.id, idx);
    if (!s) {
      await i.reply({ embeds: [errorEmbed("nothing to snipe")], ephemeral: true });
      return;
    }
    await i.reply({
      embeds: [
        aetherEmbed({
          author: { name: s.authorTag, iconURL: s.authorAvatar },
          description: s.content || "_(no text — attachments only)_",
          image: s.attachments[0],
          color: COLORS.ghost,
          footer: `deleted ${formatDuration(Date.now() - s.ts)} ago`,
        }),
      ],
    });
  },
});

register({
  category: "snipe",
  data: new SlashCommandBuilder()
    .setName("esnipe")
    .setDescription("show recently edited message in this channel")
    .addIntegerOption((o) => o.setName("index").setDescription("0 = latest").setMinValue(0).setMaxValue(9)),
  async execute(i) {
    if (!i.channel) return;
    const idx = i.options.getInteger("index") ?? 0;
    const s = getEdited(i.channel.id, idx);
    if (!s) {
      await i.reply({ embeds: [errorEmbed("nothing edited recently")], ephemeral: true });
      return;
    }
    await i.reply({
      embeds: [
        aetherEmbed({
          author: { name: s.authorTag, iconURL: s.authorAvatar },
          fields: [
            { name: "before", value: s.before || "_(empty)_" },
            { name: "after", value: s.after || "_(empty)_" },
          ],
          color: COLORS.warning,
          footer: `edited ${formatDuration(Date.now() - s.ts)} ago`,
        }),
      ],
    });
  },
});
