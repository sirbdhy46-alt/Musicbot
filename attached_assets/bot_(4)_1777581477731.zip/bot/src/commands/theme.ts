import {
  SlashCommandBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { TEMPLATES, findTemplate } from "../data/templates.ts";
import { aetherEmbed, errorEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import axios from "axios";
import { db } from "../db.ts";

interface ThemeMatch {
  template: (typeof TEMPLATES)[number];
  score: number;
}

function scoreTheme(query: string): ThemeMatch[] {
  const q = query.toLowerCase();
  return TEMPLATES.map((t) => {
    let score = 0;
    if (t.id === q) score += 100;
    if (t.name.includes(q)) score += 50;
    if (t.vibe.includes(q)) score += 30;
    for (const word of q.split(/\s+/)) {
      if (t.id.includes(word)) score += 10;
      if (t.vibe.includes(word)) score += 5;
    }
    return { template: t, score };
  })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score);
}

async function searchWebForVibe(query: string): Promise<string> {
  // lightweight: just describe palette inferred from theme name via giphy as a vibe check
  // (we don't expose the real key; this is a noop returning a friendly note)
  return `searched for "${query}" — using closest matching template palette`;
}

register({
  category: "theme",
  data: new SlashCommandBuilder()
    .setName("theme")
    .setDescription("server theme builder — recolors roles to match a vibe")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName("search")
        .setDescription("search themes by name or vibe")
        .addStringOption((o) => o.setName("query").setDescription("e.g. 'lana', 'noir', 'cottagecore'").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("apply")
        .setDescription("apply a theme — recolors existing matching roles + saves theme name")
        .addStringOption((o) => o.setName("name").setDescription("theme name").setRequired(true).setAutocomplete(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list all theme palettes")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "search") {
      const q = i.options.getString("query", true);
      const note = await searchWebForVibe(q);
      const matches = scoreTheme(q).slice(0, 8);
      if (!matches.length) {
        await i.reply({
          embeds: [errorEmbed(`no themes match \`${q}\` — try a vibe word like "dark", "soft", "neon"`)],
          ephemeral: true,
        });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: `# theme search`,
            description: [
              `> ${note}`,
              ``,
              ...matches.map(
                (m) =>
                  `\`${m.template.id.padEnd(16)}\` *${m.template.vibe}* — palette ${m.template.palette.map((c) => `\`#${c.toString(16).padStart(6, "0")}\``).join(" ")}`,
              ),
              ``,
              `> apply with \`/theme apply <id>\``,
            ].join("\n"),
            color: matches[0].template.palette[0],
          }),
        ],
      });
    } else if (sub === "apply") {
      const name = i.options.getString("name", true);
      const t = findTemplate(name);
      if (!t) {
        await i.reply({ embeds: [errorEmbed(`unknown theme \`${name}\``)], ephemeral: true });
        return;
      }
      await i.deferReply();
      let recolored = 0;
      for (const tplRole of t.roles) {
        const existing = i.guild.roles.cache.find((r) => r.name === tplRole.name);
        if (existing && existing.editable) {
          await existing.setColor(tplRole.color, "theme apply").catch(() => null);
          recolored++;
        }
      }
      db.prepare("UPDATE guild_config SET theme_name = ? WHERE guild_id = ?").run(t.id, i.guild.id);
      await i.editReply({
        embeds: [
          successEmbed(
            `theme **${t.name}** applied — recolored **${recolored}** existing roles\n> tip: run \`/template apply ${t.id}\` to also create the matching channels/roles`,
            "✓ theme set",
          ).setColor(t.palette[0]),
        ],
      });
    } else if (sub === "list") {
      const lines = TEMPLATES.map(
        (t) =>
          `\`${t.id.padEnd(16)}\` ${t.palette.map((c) => `\`#${c.toString(16).padStart(6, "0")}\``).join("")} — *${t.vibe}*`,
      );
      const half = Math.ceil(lines.length / 2);
      await i.reply({
        embeds: [
          aetherEmbed({
            title: `# all themes _(${TEMPLATES.length})_`,
            description: lines.slice(0, half).join("\n"),
            color: COLORS.accent,
          }),
          aetherEmbed({
            description: lines.slice(half).join("\n"),
            color: COLORS.accent,
          }),
        ],
      });
    }
  },
});
