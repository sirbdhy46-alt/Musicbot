import { SlashCommandBuilder } from "discord.js";
import { register } from "../commandRegistry.ts";
import { aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { parseDuration } from "../util.ts";

const NUMS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("poll")
    .setDescription("create a quick poll")
    .addStringOption((o) => o.setName("question").setDescription("the question").setRequired(true))
    .addStringOption((o) =>
      o.setName("options").setDescription("options separated by | (max 10)").setRequired(true),
    )
    .addStringOption((o) => o.setName("duration").setDescription("e.g. 1h, 30m"))
    .addBooleanOption((o) => o.setName("yesno").setDescription("force yes/no poll")),
  async execute(i) {
    const q = i.options.getString("question", true);
    const yesno = i.options.getBoolean("yesno");
    const optsStr = i.options.getString("options", true);
    const dur = parseDuration(i.options.getString("duration") ?? "");
    const options = yesno
      ? ["yes", "no"]
      : optsStr.split("|").map((s) => s.trim()).filter(Boolean).slice(0, 10);
    if (options.length < 2) {
      await i.reply({ content: "need at least 2 options", ephemeral: true });
      return;
    }
    const desc = options.map((o, idx) => `${NUMS[idx]} ${o}`).join("\n\n");
    const embed = aetherEmbed({
      description: `# ${q}\n\n${desc}${dur ? `\n\n*ends <t:${Math.floor((Date.now() + dur) / 1000)}:R>*` : ""}`,
      color: COLORS.accent,
      footer: `poll by ${i.user.tag}`,
    });
    await i.reply({ embeds: [embed] });
    const msg = await i.fetchReply();
    for (let idx = 0; idx < options.length; idx++) {
      await msg.react(NUMS[idx]).catch(() => null);
    }
  },
});
