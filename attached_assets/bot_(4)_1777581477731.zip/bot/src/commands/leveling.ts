import {
  SlashCommandBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import {
  getUserLevel,
  getRank,
  getLeaderboard,
  setUserXp,
  addLevelReward,
  removeLevelReward,
  getLevelRewards,
  levelFromXp,
  xpForLevel,
} from "../services/leveling.ts";
import { aetherEmbed, errorEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { progressBar } from "../util.ts";
import { db } from "../db.ts";

register({
  category: "leveling",
  data: new SlashCommandBuilder()
    .setName("rank")
    .setDescription("show your rank or someone else's")
    .addUserOption((o) => o.setName("user").setDescription("user")),
  async execute(i) {
    if (!i.guild) return;
    const target = i.options.getUser("user") ?? i.user;
    const data = getUserLevel(i.guild.id, target.id);
    const { level, remaining, needed } = levelFromXp(data.xp);
    const rank = getRank(i.guild.id, target.id);
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# ${target.username}`,
          thumbnail: target.displayAvatarURL({ size: 256 }),
          color: COLORS.accent,
          description: [
            `> **rank** \`#${rank}\``,
            `> **level** \`${level}\``,
            `> **xp** \`${remaining} / ${needed}\``,
            ``,
            `${progressBar(remaining, needed)} \`${Math.floor((remaining / needed) * 100)}%\``,
          ].join("\n"),
        }),
      ],
    });
  },
});

register({
  category: "leveling",
  data: new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("server xp leaderboard"),
  async execute(i) {
    if (!i.guild) return;
    const top = getLeaderboard(i.guild.id, 10);
    if (!top.length) {
      await i.reply({ embeds: [aetherEmbed({ description: "> no one has any xp yet" })] });
      return;
    }
    const lines = top.map((row, idx) => {
      const medal = idx === 0 ? "♛" : idx === 1 ? "✧" : idx === 2 ? "✦" : `\`#${idx + 1}\``;
      return `${medal} <@${row.user_id}> ` + "·" + ` lvl **${row.level}** · ${row.xp} xp`;
    });
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# ${i.guild.name} leaderboard`,
          description: lines.join("\n"),
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "leveling",
  data: new SlashCommandBuilder()
    .setName("setxp")
    .setDescription("set a user's xp")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addIntegerOption((o) => o.setName("xp").setDescription("xp value").setRequired(true).setMinValue(0))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(i) {
    if (!i.guild) return;
    const u = i.options.getUser("user", true);
    const xp = i.options.getInteger("xp", true);
    setUserXp(i.guild.id, u.id, xp);
    const { level } = levelFromXp(xp);
    await i.reply({ embeds: [successEmbed(`set ${u} to ${xp} xp (level ${level})`)] });
  },
});

register({
  category: "leveling",
  data: new SlashCommandBuilder()
    .setName("levels")
    .setDescription("leveling system configuration")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("reward")
        .setDescription("set a level role reward")
        .addIntegerOption((o) => o.setName("level").setDescription("level").setRequired(true).setMinValue(1))
        .addRoleOption((o) => o.setName("role").setDescription("role").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("remove-reward")
        .setDescription("remove a level role reward")
        .addIntegerOption((o) => o.setName("level").setDescription("level").setRequired(true).setMinValue(1)),
    )
    .addSubcommand((s) =>
      s
        .setName("stack")
        .setDescription("toggle stacking of level reward roles")
        .addBooleanOption((o) => o.setName("on").setDescription("stack?").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("announce")
        .setDescription("toggle level-up announcements")
        .addBooleanOption((o) => o.setName("on").setDescription("on?").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("channel")
        .setDescription("dedicated levelup channel (none = current)")
        .addChannelOption((o) => o.setName("channel").setDescription("channel")),
    )
    .addSubcommand((s) =>
      s
        .setName("enable")
        .setDescription("toggle the leveling system")
        .addBooleanOption((o) => o.setName("on").setDescription("on?").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("rewards").setDescription("show all level rewards")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "reward") {
      const level = i.options.getInteger("level", true);
      const role = i.options.getRole("role", true);
      addLevelReward(i.guild.id, level, role.id);
      await i.reply({ embeds: [successEmbed(`level **${level}** → <@&${role.id}>`)] });
    } else if (sub === "remove-reward") {
      const level = i.options.getInteger("level", true);
      removeLevelReward(i.guild.id, level);
      await i.reply({ embeds: [successEmbed(`removed reward for level ${level}`)] });
    } else if (sub === "stack") {
      const on = i.options.getBoolean("on", true);
      db.prepare("UPDATE guild_config SET leveling_stack = ? WHERE guild_id = ?").run(on ? 1 : 0, i.guild.id);
      await i.reply({ embeds: [successEmbed(`stack mode = ${on}`)] });
    } else if (sub === "announce") {
      const on = i.options.getBoolean("on", true);
      db.prepare("UPDATE guild_config SET leveling_announce = ? WHERE guild_id = ?").run(on ? 1 : 0, i.guild.id);
      await i.reply({ embeds: [successEmbed(`announcements = ${on}`)] });
    } else if (sub === "channel") {
      const ch = i.options.getChannel("channel");
      db.prepare("UPDATE guild_config SET leveling_channel = ? WHERE guild_id = ?").run(
        ch?.id ?? null,
        i.guild.id,
      );
      await i.reply({ embeds: [successEmbed(`levelup channel = ${ch ? `<#${ch.id}>` : "current"}`)] });
    } else if (sub === "enable") {
      const on = i.options.getBoolean("on", true);
      db.prepare("UPDATE guild_config SET leveling_enabled = ? WHERE guild_id = ?").run(on ? 1 : 0, i.guild.id);
      await i.reply({ embeds: [successEmbed(`leveling = ${on}`)] });
    } else if (sub === "rewards") {
      const r = getLevelRewards(i.guild.id);
      if (!r.length) {
        await i.reply({ embeds: [errorEmbed("no rewards set")] });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# level rewards",
            description: r.map((x) => `> level **${x.level}** → <@&${x.role_id}> (${xpForLevel(x.level)} xp)`).join("\n"),
            color: COLORS.accent,
          }),
        ],
      });
    }
  },
});
