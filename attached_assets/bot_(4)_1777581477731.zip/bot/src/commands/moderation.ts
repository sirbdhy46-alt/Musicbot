import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  type GuildTextBasedChannel,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { successEmbed, errorEmbed, aetherEmbed } from "../embeds.ts";
import { db } from "../db.ts";
import { COLORS } from "../config.ts";
import { actionReply } from "../services/banners.ts";
import { vibeGif } from "../services/giphy.ts";

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("ban a member")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("reason"))
    .addIntegerOption((o) => o.setName("delete-days").setDescription("delete msg days 0-7"))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(i) {
    if (!i.guild) return;
    const user = i.options.getUser("user", true);
    const reason = i.options.getString("reason") ?? "no reason";
    const days = i.options.getInteger("delete-days") ?? 0;
    try {
      await i.guild.bans.create(user.id, {
        reason: `${i.user.tag}: ${reason}`,
        deleteMessageSeconds: Math.min(7, Math.max(0, days)) * 86400,
      });
      db.prepare(
        "INSERT INTO mod_cases (guild_id, user_id, mod_id, type, reason, ts) VALUES (?, ?, ?, 'ban', ?, ?)",
      ).run(i.guild.id, user.id, i.user.id, reason, Date.now());
      const gif = await vibeGif("ban");
      await i.reply(
        actionReply("ban", {
          title: "# member banned",
          description: `> **target**: ${user}\n> **mod**: ${i.user}\n> **reason**: ${reason}`,
          color: COLORS.danger,
          timestamp: true,
          vibeGif: gif,
        }),
      );
    } catch (e) {
      await i.reply({ embeds: [errorEmbed(`couldn't ban: ${(e as Error).message}`)], ephemeral: true });
    }
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("unban a user by id")
    .addStringOption((o) => o.setName("user-id").setDescription("user id").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(i) {
    if (!i.guild) return;
    const id = i.options.getString("user-id", true);
    try {
      await i.guild.bans.remove(id, `${i.user.tag} unbanned`);
      const gif = await vibeGif("unban");
      await i.reply(
        actionReply("unban", {
          title: "# member unbanned",
          description: `> <@${id}> can rejoin the server\n> **mod**: ${i.user}`,
          color: COLORS.success,
          vibeGif: gif,
        }),
      );
    } catch (e) {
      await i.reply({ embeds: [errorEmbed((e as Error).message)], ephemeral: true });
    }
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("kick a member")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("reason"))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(i) {
    if (!i.guild) return;
    const user = i.options.getUser("user", true);
    const reason = i.options.getString("reason") ?? "no reason";
    const m = await i.guild.members.fetch(user.id).catch(() => null);
    if (!m) {
      await i.reply({ embeds: [errorEmbed("user not in this server")], ephemeral: true });
      return;
    }
    try {
      await m.kick(`${i.user.tag}: ${reason}`);
      db.prepare(
        "INSERT INTO mod_cases (guild_id, user_id, mod_id, type, reason, ts) VALUES (?, ?, ?, 'kick', ?, ?)",
      ).run(i.guild.id, user.id, i.user.id, reason, Date.now());
      const gif = await vibeGif("kick");
      await i.reply(
        actionReply("kick", {
          title: "# member kicked",
          description: `> **target**: ${user}\n> **mod**: ${i.user}\n> **reason**: ${reason}`,
          color: COLORS.warning,
          timestamp: true,
          vibeGif: gif,
        }),
      );
    } catch (e) {
      await i.reply({ embeds: [errorEmbed((e as Error).message)], ephemeral: true });
    }
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("timeout a member")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addIntegerOption((o) =>
      o.setName("minutes").setDescription("duration in minutes").setRequired(true),
    )
    .addStringOption((o) => o.setName("reason").setDescription("reason"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(i) {
    if (!i.guild) return;
    const user = i.options.getUser("user", true);
    const minutes = i.options.getInteger("minutes", true);
    const reason = i.options.getString("reason") ?? "no reason";
    const member = await i.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      await i.reply({ embeds: [errorEmbed("not in server")], ephemeral: true });
      return;
    }
    try {
      await member.timeout(minutes * 60_000, `${i.user.tag}: ${reason}`);
      db.prepare(
        "INSERT INTO mod_cases (guild_id, user_id, mod_id, type, reason, ts) VALUES (?, ?, ?, 'mute', ?, ?)",
      ).run(i.guild.id, user.id, i.user.id, `${minutes}m: ${reason}`, Date.now());
      const gif = await vibeGif("mute");
      await i.reply(
        actionReply("mute", {
          title: "# member muted",
          description: `> **target**: ${user}\n> **mod**: ${i.user}\n> **duration**: ${minutes}m\n> **reason**: ${reason}`,
          color: COLORS.warning,
          timestamp: true,
          vibeGif: gif,
        }),
      );
    } catch (e) {
      await i.reply({ embeds: [errorEmbed((e as Error).message)], ephemeral: true });
    }
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("unmute")
    .setDescription("remove timeout")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(i) {
    if (!i.guild) return;
    const user = i.options.getUser("user", true);
    const member = await i.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      await i.reply({ embeds: [errorEmbed("not in server")], ephemeral: true });
      return;
    }
    await member.timeout(null, `${i.user.tag}: unmute`);
    const gif = await vibeGif("unmute");
    await i.reply(
      actionReply("unmute", {
        title: "# member unmuted",
        description: `> **${user.tag}** can speak again`,
        color: COLORS.success,
        vibeGif: gif,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("warn a member")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("reason").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(i) {
    if (!i.guild) return;
    const user = i.options.getUser("user", true);
    const reason = i.options.getString("reason", true);
    db.prepare(
      "INSERT INTO warnings (guild_id, user_id, mod_id, reason, ts) VALUES (?, ?, ?, ?, ?)",
    ).run(i.guild.id, user.id, i.user.id, reason, Date.now());
    const count = (db
      .prepare("SELECT COUNT(*) as c FROM warnings WHERE guild_id = ? AND user_id = ?")
      .get(i.guild.id, user.id) as { c: number }).c;
    const gif = await vibeGif("warn");
    await i.reply(
      actionReply("warn", {
        title: "# member warned",
        description: `> **target**: ${user}\n> **mod**: ${i.user}\n> **reason**: ${reason}\n> **total warnings**: ${count}`,
        color: COLORS.warning,
        timestamp: true,
        vibeGif: gif,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("list warnings for a user")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(i) {
    if (!i.guild) return;
    const u = i.options.getUser("user", true);
    const rows = db
      .prepare("SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY ts DESC LIMIT 15")
      .all(i.guild.id, u.id) as { id: number; reason: string; mod_id: string; ts: number }[];
    if (!rows.length) {
      await i.reply({ embeds: [aetherEmbed({ description: `> ${u.tag} has no warnings` })] });
      return;
    }
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `# ${u.tag}'s warnings`,
          description: rows
            .map(
              (r) => `\`#${r.id}\` <@${r.mod_id}> <t:${Math.floor(r.ts / 1000)}:R>\n> *${r.reason}*`,
            )
            .join("\n\n"),
          color: COLORS.warning,
        }),
      ],
    });
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("clear")
    .setDescription("bulk delete recent messages")
    .addIntegerOption((o) =>
      o.setName("amount").setDescription("how many (1-100)").setRequired(true).setMinValue(1).setMaxValue(100),
    )
    .addUserOption((o) => o.setName("user").setDescription("only this user's"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(i) {
    if (!i.guild || !i.channel || i.channel.type !== ChannelType.GuildText) return;
    const ch = i.channel as GuildTextBasedChannel;
    const amount = i.options.getInteger("amount", true);
    const user = i.options.getUser("user");
    await i.deferReply({ ephemeral: true });
    const messages = await ch.messages.fetch({ limit: 100 });
    const target = (user
      ? messages.filter((m) => m.author.id === user.id)
      : messages
    )
      .first(amount)
      .filter((m) => Date.now() - m.createdTimestamp < 14 * 86_400_000);
    const deleted = await ch.bulkDelete(target, true).catch(() => null);
    await i.editReply(
      actionReply("clear", {
        title: "# messages cleared",
        description: `> wiped **${deleted?.size ?? 0}** messages\n> **mod**: ${i.user}${user ? `\n> **filter**: ${user}` : ""}`,
        color: COLORS.info,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("nuke")
    .setDescription("clone & delete this channel (clears all msgs)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(i) {
    if (!i.channel || i.channel.type !== ChannelType.GuildText) {
      await i.reply({ embeds: [errorEmbed("text channels only")], ephemeral: true });
      return;
    }
    const ch = i.channel as GuildTextBasedChannel & { clone: Function; delete: Function; position: number };
    const cloned = await ch.clone();
    await cloned.setPosition(ch.position);
    await ch.delete("nuke");
    await cloned.send(
      actionReply("nuke", {
        title: "# channel nuked",
        description: `> this channel got a fresh start\n> **mod**: ${i.user}`,
        color: COLORS.danger,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("lock")
    .setDescription("lock the current channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(i) {
    if (!i.guild || !i.channel || i.channel.type !== ChannelType.GuildText) return;
    const ch = i.channel as import("discord.js").TextChannel;
    await ch.permissionOverwrites.edit(i.guild.id, { SendMessages: false });
    await i.reply(
      actionReply("lock", {
        title: "# channel locked",
        description: `> sealed by ${i.user}\n> only mods can speak`,
        color: COLORS.danger,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("unlock")
    .setDescription("unlock the current channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(i) {
    if (!i.guild || !i.channel || i.channel.type !== ChannelType.GuildText) return;
    const ch = i.channel as import("discord.js").TextChannel;
    await ch.permissionOverwrites.edit(i.guild.id, { SendMessages: null });
    await i.reply(
      actionReply("unlock", {
        title: "# channel unlocked",
        description: `> reopened by ${i.user}`,
        color: COLORS.success,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("slowmode")
    .setDescription("set slowmode for current channel")
    .addIntegerOption((o) =>
      o
        .setName("seconds")
        .setDescription("0 to disable, max 21600")
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(21600),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(i) {
    if (!i.channel || i.channel.type !== ChannelType.GuildText) return;
    const s = i.options.getInteger("seconds", true);
    await (i.channel as GuildTextBasedChannel).setRateLimitPerUser(s);
    await i.reply(
      actionReply("slowmode", {
        title: "# slowmode updated",
        description: s === 0 ? "> slowmode disabled" : `> slowmode set to **${s}s**`,
        color: COLORS.info,
      }),
    );
  },
});
