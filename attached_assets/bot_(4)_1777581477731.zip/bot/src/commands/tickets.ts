import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { emoji } from "../services/emojis.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("tickets")
    .setDescription("ticket system")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("setup")
        .setDescription("configure ticket system")
        .addChannelOption((o) =>
          o.setName("category").setDescription("category for new tickets").setRequired(true),
        )
        .addRoleOption((o) => o.setName("staff_role").setDescription("staff role").setRequired(true))
        .addChannelOption((o) => o.setName("log_channel").setDescription("log channel"))
        .addStringOption((o) => o.setName("prompt").setDescription("panel prompt text")),
    )
    .addSubcommand((s) =>
      s
        .setName("panel")
        .setDescription("send the ticket panel here"),
    )
    .addSubcommand((s) => s.setName("close").setDescription("close this ticket")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "setup") {
      const category = i.options.getChannel("category", true);
      const staff = i.options.getRole("staff_role", true);
      const log = i.options.getChannel("log_channel");
      const prompt = i.options.getString("prompt") ?? "# need help?\n> click the button to open a private ticket";
      db.prepare(
        "INSERT INTO ticket_config (guild_id, panel_channel, category, staff_role, log_channel, prompt) VALUES (?, NULL, ?, ?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET category = excluded.category, staff_role = excluded.staff_role, log_channel = excluded.log_channel, prompt = excluded.prompt",
      ).run(i.guild.id, category.id, staff.id, log?.id ?? null, prompt);
      await i.reply({ embeds: [successEmbed(`tickets configured · category <#${category.id}>`)] });
      return;
    }
    if (sub === "panel") {
      const cfg = db.prepare("SELECT prompt FROM ticket_config WHERE guild_id = ?").get(i.guild.id) as
        | { prompt: string }
        | undefined;
      if (!cfg) {
        await i.reply({ embeds: [errorEmbed("run `/tickets setup` first")], ephemeral: true });
        return;
      }
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ticket-open").setLabel("open ticket").setStyle(ButtonStyle.Secondary).setEmoji("✉"),
      );
      if (i.channel?.isTextBased() && "send" in i.channel) {
        await i.channel.send({
          embeds: [aetherEmbed({ description: cfg.prompt, color: COLORS.accent })],
          components: [row],
        });
      }
      await i.reply({ embeds: [successEmbed("panel posted")], ephemeral: true });
      return;
    }
    if (sub === "close") {
      if (!i.channel || i.channel.type !== ChannelType.GuildText) return;
      const t = db.prepare("SELECT user_id FROM tickets WHERE channel_id = ?").get(i.channel.id) as
        | { user_id: string }
        | undefined;
      if (!t) {
        await i.reply({ embeds: [errorEmbed("not a ticket")], ephemeral: true });
        return;
      }
      const cfg = db.prepare("SELECT log_channel FROM ticket_config WHERE guild_id = ?").get(i.guild.id) as
        | { log_channel: string | null }
        | undefined;
      await i.reply({
        embeds: [aetherEmbed({ description: `${emoji("aether_ticket")} closing ticket in 5s...`, color: COLORS.ghost })],
      });
      setTimeout(async () => {
        if (cfg?.log_channel) {
          const log = await i.guild!.channels.fetch(cfg.log_channel).catch(() => null);
          if (log?.isTextBased() && "send" in log) {
            await log.send({
              embeds: [
                aetherEmbed({
                  description: `# ticket closed\n> opened by <@${t.user_id}>\n> closed by ${i.user}`,
                  color: COLORS.ghost,
                }),
              ],
            });
          }
        }
        db.prepare("DELETE FROM tickets WHERE channel_id = ?").run(i.channel!.id);
        await i.channel!.delete().catch(() => null);
      }, 5000);
      return;
    }
  },
});
