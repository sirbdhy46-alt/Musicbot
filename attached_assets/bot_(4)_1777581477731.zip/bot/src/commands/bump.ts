import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("bump")
    .setDescription("disboard bump reminders")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("setup")
        .setDescription("configure bump reminders")
        .addChannelOption((o) => o.setName("channel").setDescription("channel to remind in").setRequired(true))
        .addRoleOption((o) => o.setName("role").setDescription("role to ping")),
    )
    .addSubcommand((s) => s.setName("disable").setDescription("disable bump reminders"))
    .addSubcommand((s) => s.setName("status").setDescription("show config")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "setup") {
      const ch = i.options.getChannel("channel", true);
      const role = i.options.getRole("role");
      db.prepare(
        "INSERT INTO bump_config (guild_id, channel_id, role_id, next_bump) VALUES (?, ?, ?, 0) ON CONFLICT(guild_id) DO UPDATE SET channel_id = excluded.channel_id, role_id = excluded.role_id",
      ).run(i.guild.id, ch.id, role?.id ?? null);
      await i.reply({ embeds: [successEmbed(`bump reminders → <#${ch.id}>${role ? ` · pings <@&${role.id}>` : ""}`)] });
      return;
    }
    if (sub === "disable") {
      db.prepare("DELETE FROM bump_config WHERE guild_id = ?").run(i.guild.id);
      await i.reply({ embeds: [successEmbed("bump reminders disabled")] });
      return;
    }
    const cfg = db
      .prepare("SELECT channel_id, role_id, next_bump FROM bump_config WHERE guild_id = ?")
      .get(i.guild.id) as { channel_id: string; role_id: string | null; next_bump: number } | undefined;
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "bump status",
          description: cfg
            ? `> channel: <#${cfg.channel_id}>\n> role: ${cfg.role_id ? `<@&${cfg.role_id}>` : "_none_"}\n> next: ${cfg.next_bump > Date.now() ? `<t:${Math.floor(cfg.next_bump / 1000)}:R>` : "_ready now_"}`
            : "> _not configured_",
          color: COLORS.accent,
        }),
      ],
    });
  },
});
