import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed, errorEmbed, warnEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { emoji } from "../services/emojis.ts";
import { searchGif } from "../services/giphy.ts";
import { actionReply, actionBanner } from "../services/banners.ts";

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("hardban")
    .setDescription("ban + auto-rejoin protection")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("reason")),
  async execute(i) {
    if (!i.guild) return;
    const u = i.options.getUser("user", true);
    const reason = i.options.getString("reason") ?? "hardban";
    try {
      await i.guild.bans.create(u.id, { reason: `[hardban] ${i.user.tag}: ${reason}` });
      db.prepare("INSERT OR IGNORE INTO hardban_list (guild_id, user_id) VALUES (?, ?)").run(i.guild.id, u.id);
      await i.reply(
        actionReply("hardban", {
          title: "# hardbanned",
          description: `> **target**: ${u}\n> **mod**: ${i.user}\n> **reason**: ${reason}\n> ${emoji("aether_skull_pulse")} cannot rejoin`,
          color: COLORS.danger,
          timestamp: true,
        }),
      );
    } catch (err) {
      await i.reply({ embeds: [errorEmbed((err as Error).message)] });
    }
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("unhardban")
    .setDescription("remove hardban (allow rejoin)")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((o) => o.setName("user_id").setDescription("user id").setRequired(true)),
  async execute(i) {
    if (!i.guild) return;
    const id = i.options.getString("user_id", true);
    db.prepare("DELETE FROM hardban_list WHERE guild_id = ? AND user_id = ?").run(i.guild.id, id);
    await i.guild.bans.remove(id, `unhardban by ${i.user.tag}`).catch(() => null);
    await i.reply(
      actionReply("unban", {
        title: "# hardban removed",
        description: `> <@${id}> can rejoin again\n> **mod**: ${i.user}`,
        color: COLORS.success,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("unban a user by id")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((o) => o.setName("user_id").setDescription("user id").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("reason")),
  async execute(i) {
    if (!i.guild) return;
    const id = i.options.getString("user_id", true);
    try {
      const reason = i.options.getString("reason") ?? "unban";
      await i.guild.bans.remove(id, `${i.user.tag}: ${reason}`);
      await i.reply(
        actionReply("unban", {
          title: "# member unbanned",
          description: `> <@${id}> can rejoin\n> **mod**: ${i.user}\n> **reason**: ${reason}`,
          color: COLORS.success,
        }),
      );
    } catch {
      await i.reply({ embeds: [errorEmbed("not banned or invalid id")] });
    }
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("banlist")
    .setDescription("show recent bans")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(i) {
    if (!i.guild) return;
    const bans = await i.guild.bans.fetch({ limit: 25 });
    await i.reply({
      embeds: [
        aetherEmbed({
          title: `${emoji("aether_ban")} ban list (${bans.size})`,
          description:
            bans
              .map((b) => `> **${b.user.tag}** \`${b.user.id}\` — ${b.reason ?? "_no reason_"}`)
              .join("\n")
              .slice(0, 4000) || "> _no bans_",
          color: COLORS.danger,
        }),
      ],
    });
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("untimeout")
    .setDescription("remove a timeout")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
  async execute(i) {
    if (!i.guild) return;
    const u = i.options.getUser("user", true);
    const m = await i.guild.members.fetch(u.id).catch(() => null);
    if (!m) {
      await i.reply({ embeds: [errorEmbed("user not in server")], ephemeral: true });
      return;
    }
    await m.timeout(null, `untimeout by ${i.user.tag}`).catch(() => null);
    await i.reply(
      actionReply("unmute", {
        title: "# timeout removed",
        description: `> ${u} can speak again\n> **mod**: ${i.user}`,
        color: COLORS.success,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("forcenick")
    .setDescription("lock a user's nickname")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames)
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addStringOption((o) => o.setName("nick").setDescription("nickname (omit to unlock)")),
  async execute(i) {
    if (!i.guild) return;
    const u = i.options.getUser("user", true);
    const nick = i.options.getString("nick");
    const m = await i.guild.members.fetch(u.id).catch(() => null);
    if (!m) return;
    if (nick) {
      db.prepare(
        "INSERT INTO forcenicks (guild_id, user_id, nick) VALUES (?, ?, ?) ON CONFLICT DO UPDATE SET nick = excluded.nick",
      ).run(i.guild.id, u.id, nick);
      await m.setNickname(nick, "force-nick").catch(() => null);
      await i.reply(
        actionReply("forcenick", {
          title: "# nickname locked",
          description: `> **target**: ${u}\n> **new name**: \`${nick}\`\n> **mod**: ${i.user}`,
          color: COLORS.warning,
        }),
      );
    } else {
      db.prepare("DELETE FROM forcenicks WHERE guild_id = ? AND user_id = ?").run(i.guild.id, u.id);
      await m.setNickname(null, "force-nick removed").catch(() => null);
      await i.reply(
        actionReply("forcenick", {
          title: "# nickname unlocked",
          description: `> ${u} can choose their own name again`,
          color: COLORS.success,
        }),
      );
    }
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("lockdown")
    .setDescription("lock all text channels (raid response)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((o) =>
      o
        .setName("mode")
        .setDescription("mode")
        .addChoices({ name: "lock", value: "lock" }, { name: "unlock", value: "unlock" })
        .setRequired(true),
    ),
  async execute(i) {
    if (!i.guild) return;
    const mode = i.options.getString("mode", true);
    let count = 0;
    for (const ch of i.guild.channels.cache.values()) {
      if (ch.type === ChannelType.GuildText) {
        await ch.permissionOverwrites
          .edit(i.guild.id, { SendMessages: mode === "lock" ? false : null })
          .catch(() => null);
        count++;
      }
    }
    await i.reply(
      actionReply("lockdown", {
        title: mode === "lock" ? "# lockdown engaged" : "# lockdown lifted",
        description:
          mode === "lock"
            ? `> ${count} channels sealed by ${i.user}\n> only mods can speak`
            : `> ${count} channels reopened by ${i.user}`,
        color: mode === "lock" ? COLORS.danger : COLORS.success,
      }),
    );
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("nuke")
    .setDescription("clone + delete this channel (clears all messages)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(i) {
    if (!i.guild || !i.channel) return;
    if (i.channel.type !== ChannelType.GuildText) {
      await i.reply({ embeds: [errorEmbed("text channels only")], ephemeral: true });
      return;
    }
    await i.reply({ embeds: [warnEmbed(`${emoji("aether_fire")} nuking in 3s...`)], ephemeral: true });
    const ch = i.channel;
    setTimeout(async () => {
      try {
        const cloned = await ch.clone({ reason: `nuke by ${i.user.tag}` });
        await cloned.setPosition(ch.position);
        await ch.delete(`nuke by ${i.user.tag}`);
        const banner = actionBanner("nuke");
        const gif = await searchGif("explosion aesthetic");
        // Prefer the local themed banner; fall back to a giphy image.
        await cloned.send({
          embeds: [
            aetherEmbed({
              title: "# channel nuked",
              description: `> wiped clean by ${i.user}\n> ${emoji("aether_alert_pulse")} fresh start`,
              color: COLORS.danger,
              image: banner?.image ?? gif ?? undefined,
            }),
          ],
          files: banner ? [banner.attachment] : [],
        });
      } catch (err) {
        console.error("nuke failed", err);
      }
    }, 3000);
  },
});

register({
  category: "moderation",
  data: new SlashCommandBuilder()
    .setName("isolate")
    .setDescription("strip all roles from a user")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("reason")),
  async execute(i) {
    if (!i.guild) return;
    const u = i.options.getUser("user", true);
    const m = await i.guild.members.fetch(u.id).catch(() => null);
    if (!m) return;
    const roles = m.roles.cache.filter((r) => r.id !== i.guild!.id && r.editable);
    let count = 0;
    for (const r of roles.values()) {
      await m.roles.remove(r.id, `isolate by ${i.user.tag}`).catch(() => null);
      count++;
    }
    const reason = i.options.getString("reason") ?? "no reason";
    await i.reply(
      actionReply("isolate", {
        title: "# member isolated",
        description: `> **target**: ${u}\n> **mod**: ${i.user}\n> **reason**: ${reason}\n> stripped ${count} role(s)`,
        color: COLORS.danger,
      }),
    );
  },
});
