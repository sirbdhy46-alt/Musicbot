import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type GuildTextBasedChannel,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { aetherEmbed, errorEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { parseDuration, formatDuration } from "../util.ts";
import { createGiveaway, endGiveaway } from "../services/giveaway.ts";
import { db } from "../db.ts";

register({
  category: "giveaway",
  data: new SlashCommandBuilder()
    .setName("giveaway")
    .setDescription("host giveaways")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName("start")
        .setDescription("start a giveaway")
        .addStringOption((o) => o.setName("prize").setDescription("prize").setRequired(true))
        .addStringOption((o) => o.setName("duration").setDescription("e.g. 1h30m, 2d").setRequired(true))
        .addIntegerOption((o) => o.setName("winners").setDescription("# winners").setMinValue(1).setMaxValue(20))
        .addChannelOption((o) =>
          o.setName("channel").setDescription("channel").addChannelTypes(ChannelType.GuildText),
        ),
    )
    .addSubcommand((s) =>
      s
        .setName("end")
        .setDescription("end a giveaway by id")
        .addIntegerOption((o) => o.setName("id").setDescription("giveaway id").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("reroll")
        .setDescription("reroll a finished giveaway")
        .addIntegerOption((o) => o.setName("id").setDescription("giveaway id").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("list").setDescription("list active giveaways")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "start") {
      const prize = i.options.getString("prize", true);
      const dur = parseDuration(i.options.getString("duration", true));
      const winners = i.options.getInteger("winners") ?? 1;
      const chOpt = i.options.getChannel("channel");
      if (!dur) {
        await i.reply({ embeds: [errorEmbed("invalid duration — try `1h30m`")], ephemeral: true });
        return;
      }
      const ch = chOpt
        ? ((await i.guild.channels.fetch(chOpt.id)) as GuildTextBasedChannel)
        : (i.channel as GuildTextBasedChannel);
      const endsAt = Date.now() + dur;
      const embed = aetherEmbed({
        title: "# ♛ giveaway",
        description: [
          `# ${prize}`,
          `> **winners**: ${winners}`,
          `> **ends**: <t:${Math.floor(endsAt / 1000)}:R>`,
          `> **hosted by**: ${i.user}`,
          ``,
          `> press **enter** below to join`,
        ].join("\n"),
        color: COLORS.accent,
      });
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("gw-enter").setLabel("enter ♛").setStyle(ButtonStyle.Success),
      );
      const msg = await ch.send({ embeds: [embed], components: [row] });
      const id = createGiveaway({
        guild_id: i.guild.id,
        channel_id: ch.id,
        message_id: msg.id,
        prize,
        winners,
        ends_at: endsAt,
        host_id: i.user.id,
      });
      await i.reply({
        embeds: [successEmbed(`started giveaway \`#${id}\` ending in ${formatDuration(dur)}`)],
        ephemeral: true,
      });
    } else if (sub === "end") {
      const id = i.options.getInteger("id", true);
      await endGiveaway(i.client, id);
      await i.reply({ embeds: [successEmbed(`ended #${id}`)], ephemeral: true });
    } else if (sub === "reroll") {
      const id = i.options.getInteger("id", true);
      const winners = await endGiveaway(i.client, id, true);
      await i.reply({ embeds: [successEmbed(`rerolled — ${winners.length} new winners`)], ephemeral: true });
    } else if (sub === "list") {
      const rows = db
        .prepare("SELECT id, prize, ends_at, winners FROM giveaways WHERE guild_id = ? AND ended = 0 ORDER BY ends_at ASC")
        .all(i.guild.id) as { id: number; prize: string; ends_at: number; winners: number }[];
      if (!rows.length) {
        await i.reply({ embeds: [aetherEmbed({ description: "> no active giveaways" })] });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# active giveaways",
            description: rows
              .map(
                (r) => `\`#${r.id}\` **${r.prize}** — ${r.winners}w — ends <t:${Math.floor(r.ends_at / 1000)}:R>`,
              )
              .join("\n"),
            color: COLORS.accent,
          }),
        ],
      });
    }
  },
});
