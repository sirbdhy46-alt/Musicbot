import {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  type ChatInputCommandInteraction,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { aetherEmbed, errorEmbed, successEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { db } from "../db.ts";
import { searchGif, vibeGif } from "../services/giphy.ts";
import { actionReply, actionBanner } from "../services/banners.ts";

const ROAST_LINES = [
  "your aura has the bandwidth of dial-up",
  "you have the personality of unsalted oatmeal",
  "your vibes are ratio'd by a bot",
  "you're the human version of a typo",
  "your fit check failed every patch since 2019",
  "you're loading at 3% in the group chat",
  "you walked into the room and the wifi got slower",
  "you're a placeholder pretending to be a person",
];

const COMPLIMENTS = [
  "your energy makes the server boot 2x faster",
  "you're the reason the vibe checks pass",
  "your typing indicator alone deserves a role",
  "you radiate main-character signal",
  "even the lurkers stop scrolling for you",
];

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("8ball")
    .setDescription("ask the void a yes/no question")
    .addStringOption((o) => o.setName("question").setDescription("question").setRequired(true)),
  async execute(i) {
    const answers = [
      "yes, obviously",
      "absolutely not",
      "the void says yes",
      "ask me later when the moon turns",
      "cosmically inevitable",
      "you already know the answer",
      "no, and the no is loud",
      "maybe — but probably not for you",
      "the algorithm aligns",
      "the algorithm rejects",
    ];
    const a = answers[Math.floor(Math.random() * answers.length)];
    await i.reply(
      actionReply("8ball", {
        title: "# 🜄 the void answers",
        description: `> *${i.options.getString("question", true)}*\n# ${a}`,
        color: COLORS.accent,
      }),
    );
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("coinflip")
    .setDescription("flip a coin"),
  async execute(i) {
    const heads = Math.random() < 0.5;
    await i.reply(
      actionReply("coinflip", {
        title: "# coin flip",
        description: `> the coin landed on **${heads ? "heads" : "tails"}**`,
        color: heads ? COLORS.info : COLORS.accent,
      }),
    );
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("rps")
    .setDescription("rock paper scissors")
    .addStringOption((o) =>
      o
        .setName("choice")
        .setDescription("your move")
        .setRequired(true)
        .addChoices(
          { name: "rock", value: "rock" },
          { name: "paper", value: "paper" },
          { name: "scissors", value: "scissors" },
        ),
    ),
  async execute(i) {
    const moves = ["rock", "paper", "scissors"] as const;
    const me = moves[Math.floor(Math.random() * 3)];
    const you = i.options.getString("choice", true) as (typeof moves)[number];
    let result = "draw";
    if (
      (you === "rock" && me === "scissors") ||
      (you === "paper" && me === "rock") ||
      (you === "scissors" && me === "paper")
    ) {
      result = "you won";
    } else if (you !== me) result = "you lost";
    await i.reply(
      actionReply("rps", {
        title: "# rock paper scissors",
        description: `> you: **${you}**\n> aether: **${me}**\n# ${result}`,
        color: result === "you won" ? COLORS.success : result === "you lost" ? COLORS.danger : COLORS.warning,
      }),
    );
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("roast")
    .setDescription("roast someone (lighthearted)")
    .addUserOption((o) => o.setName("user").setDescription("victim").setRequired(true)),
  async execute(i) {
    const u = i.options.getUser("user", true);
    const line = ROAST_LINES[Math.floor(Math.random() * ROAST_LINES.length)];
    await i.reply(
      actionReply("roast", {
        title: `# ${u.username} got roasted`,
        description: `> ${line}\n> *— ${i.user}*`,
        color: COLORS.accent,
      }),
    );
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("compliment")
    .setDescription("compliment someone")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
  async execute(i) {
    const u = i.options.getUser("user", true);
    const line = COMPLIMENTS[Math.floor(Math.random() * COMPLIMENTS.length)];
    await i.reply(
      actionReply("compliment", {
        title: `# ${u.username}`,
        description: `> ${line}\n> *— ${i.user}*`,
        color: COLORS.success,
      }),
    );
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("ship")
    .setDescription("ship two members and rate the vibe match")
    .addUserOption((o) => o.setName("a").setDescription("first").setRequired(true))
    .addUserOption((o) => o.setName("b").setDescription("second").setRequired(true)),
  async execute(i) {
    const a = i.options.getUser("a", true);
    const b = i.options.getUser("b", true);
    const seed = (BigInt(a.id) ^ BigInt(b.id)).toString();
    const score = (Number(BigInt(seed) % 101n) + 100) % 101;
    const bar = "▰".repeat(Math.round(score / 10)) + "▱".repeat(10 - Math.round(score / 10));
    const half = Math.floor(a.username.length / 2);
    const ship = a.username.slice(0, half) + b.username.slice(Math.floor(b.username.length / 2));
    await i.reply(
      actionReply("ship", {
        title: `# ${ship}`,
        description: [
          `> ${a} ✦ ${b}`,
          ``,
          `${bar} \`${score}%\``,
          ``,
          `> ${score >= 80 ? "soulmates" : score >= 60 ? "real chemistry" : score >= 40 ? "could work" : score >= 20 ? "rough" : "absolutely not"}`,
        ].join("\n"),
        color: COLORS.accent,
      }),
    );
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("couple")
    .setDescription("couple of the week")
    .addSubcommand((s) =>
      s
        .setName("set")
        .setDescription("set the official server couple of the week")
        .addUserOption((o) => o.setName("a").setDescription("first").setRequired(true))
        .addUserOption((o) => o.setName("b").setDescription("second").setRequired(true)),
    )
    .addSubcommand((s) => s.setName("show").setDescription("show this server's couple")),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "set") {
      const a = i.options.getUser("a", true);
      const b = i.options.getUser("b", true);
      db.prepare(
        `INSERT OR REPLACE INTO couples (guild_id, user_a, user_b, votes, set_ts) VALUES (?, ?, ?, 0, ?)`,
      ).run(i.guild.id, a.id, b.id, Date.now());
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# ♛ couple of the week",
            description: `> ${a} **&** ${b}\n> may your dms stay open and your timezones aligned`,
            color: COLORS.accent,
          }),
        ],
      });
    } else if (sub === "show") {
      const row = db
        .prepare("SELECT user_a, user_b, set_ts FROM couples WHERE guild_id = ?")
        .get(i.guild.id) as { user_a: string; user_b: string; set_ts: number } | undefined;
      if (!row) {
        await i.reply({ embeds: [errorEmbed("no couple set yet")] });
        return;
      }
      await i.reply({
        embeds: [
          aetherEmbed({
            title: "# couple of the week",
            description: `> <@${row.user_a}> **&** <@${row.user_b}>\n> set <t:${Math.floor(row.set_ts / 1000)}:R>`,
            color: COLORS.accent,
          }),
        ],
      });
    }
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("pfpbattle")
    .setDescription("vote on whose pfp is sharper")
    .addUserOption((o) => o.setName("a").setDescription("first").setRequired(true))
    .addUserOption((o) => o.setName("b").setDescription("second").setRequired(true)),
  async execute(i) {
    const a = i.options.getUser("a", true);
    const b = i.options.getUser("b", true);
    let votesA = new Set<string>();
    let votesB = new Set<string>();
    const buildEmbeds = () => [
      aetherEmbed({
        title: `# pfp battle`,
        description: `> ${a} **vs** ${b}\n> **${votesA.size}** ${"▰".repeat(Math.min(10, votesA.size))} : ${"▰".repeat(Math.min(10, votesB.size))} **${votesB.size}**`,
        color: COLORS.accent,
      }),
      aetherEmbed({ title: a.username, image: a.displayAvatarURL({ size: 512 }), color: COLORS.info }),
      aetherEmbed({ title: b.username, image: b.displayAvatarURL({ size: 512 }), color: COLORS.danger }),
    ];
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("pfp-a").setLabel(`vote ${a.username}`).setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("pfp-b").setLabel(`vote ${b.username}`).setStyle(ButtonStyle.Danger),
    );
    await i.reply({ embeds: buildEmbeds(), components: [row] });
    const msg = await i.fetchReply();
    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60_000,
    });
    collector.on("collect", async (b2) => {
      if (b2.customId === "pfp-a") {
        votesB.delete(b2.user.id);
        votesA.add(b2.user.id);
      } else {
        votesA.delete(b2.user.id);
        votesB.add(b2.user.id);
      }
      await b2.update({ embeds: buildEmbeds(), components: [row] });
    });
    collector.on("end", async () => {
      const winner = votesA.size === votesB.size ? "tie" : votesA.size > votesB.size ? a.username : b.username;
      await i
        .editReply({
          embeds: [
            ...buildEmbeds(),
            aetherEmbed({ title: `# winner: ${winner}`, color: COLORS.success }),
          ],
          components: [],
        })
        .catch(() => null);
    });
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("trivia")
    .setDescription("quick trivia question"),
  async execute(i: ChatInputCommandInteraction) {
    const questions = [
      { q: "what is the smallest prime number?", a: "2", w: ["1", "3", "0"] },
      { q: "year discord launched?", a: "2015", w: ["2013", "2017", "2020"] },
      { q: "color you get from red + blue?", a: "purple", w: ["green", "yellow", "orange"] },
      { q: "how many bytes in a kilobyte (binary)?", a: "1024", w: ["1000", "512", "2048"] },
      { q: "currency of japan?", a: "yen", w: ["won", "yuan", "ringgit"] },
    ];
    const q = questions[Math.floor(Math.random() * questions.length)];
    const all = [q.a, ...q.w].sort(() => Math.random() - 0.5);
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      ...all.map((opt) =>
        new ButtonBuilder()
          .setCustomId(`triv:${opt === q.a ? "y" : "n"}`)
          .setLabel(opt)
          .setStyle(ButtonStyle.Secondary),
      ),
    );
    await i.reply({
      embeds: [aetherEmbed({ title: "# trivia", description: `> ${q.q}`, color: COLORS.accent })],
      components: [row],
    });
    const msg = await i.fetchReply();
    try {
      const press = await msg.awaitMessageComponent({
        componentType: ComponentType.Button,
        time: 20_000,
        filter: (b) => b.user.id === i.user.id,
      });
      const correct = press.customId.endsWith(":y");
      await press.update({
        embeds: [
          aetherEmbed({
            title: correct ? "✓ correct" : "✕ wrong",
            description: `> answer: **${q.a}**`,
            color: correct ? COLORS.success : COLORS.danger,
          }),
        ],
        components: [],
      });
    } catch {
      await i.editReply({
        embeds: [aetherEmbed({ description: `> too slow — answer was **${q.a}**` })],
        components: [],
      }).catch(() => null);
    }
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("hug")
    .setDescription("hug someone")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
  async execute(i) {
    const u = i.options.getUser("user", true);
    const gif = await vibeGif("hug");
    const banner = actionBanner("hug");
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# hugged ♡",
          description: `> ${i.user} pulled ${u} into a warm hug`,
          image: gif,
          thumbnail: banner?.image,
          color: COLORS.accent,
        }),
      ],
      files: banner ? [banner.attachment] : [],
    });
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("slap")
    .setDescription("slap someone")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
  async execute(i) {
    const u = i.options.getUser("user", true);
    const gif = await vibeGif("slap");
    const banner = actionBanner("slap");
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# slapped",
          description: `> ${i.user} slapped ${u} across the realm`,
          image: gif,
          thumbnail: banner?.image,
          color: COLORS.danger,
        }),
      ],
      files: banner ? [banner.attachment] : [],
    });
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("kiss")
    .setDescription("kiss someone ♡")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
  async execute(i) {
    const u = i.options.getUser("user", true);
    const gif = await vibeGif("kiss");
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# kissed ♡",
          description: `> ${i.user} kissed ${u} softly`,
          image: gif,
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("pat")
    .setDescription("pat someone")
    .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
  async execute(i) {
    const u = i.options.getUser("user", true);
    const gif = await vibeGif("pat");
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# patted",
          description: `> ${i.user} pat ${u} gently`,
          image: gif,
          color: COLORS.accent,
        }),
      ],
    });
  },
});

register({
  category: "fun",
  data: new SlashCommandBuilder()
    .setName("cry")
    .setDescription("cry it out")
    .addStringOption((o) => o.setName("reason").setDescription("why")),
  async execute(i) {
    const reason = i.options.getString("reason");
    const gif = await vibeGif("cry");
    await i.reply({
      embeds: [
        aetherEmbed({
          title: "# crying",
          description: reason ? `> ${i.user} cries · ${reason}` : `> ${i.user} cries quietly`,
          image: gif,
          color: COLORS.ghost,
        }),
      ],
    });
  },
});
