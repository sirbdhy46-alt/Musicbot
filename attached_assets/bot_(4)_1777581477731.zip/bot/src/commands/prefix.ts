import { SlashCommandBuilder, PermissionFlagsBits } from "discord.js";
import { register } from "../commandRegistry.ts";
import { aetherEmbed, successEmbed } from "../embeds.ts";
import { getPrefix, setPrefix } from "../services/prefix.ts";
import { COLORS } from "../config.ts";
import { emoji } from "../services/emojis.ts";

register({
  category: "core",
  data: new SlashCommandBuilder()
    .setName("prefix")
    .setDescription("manage the server prefix")
    .addSubcommand((s) => s.setName("show").setDescription("show the current prefix"))
    .addSubcommand((s) =>
      s
        .setName("set")
        .setDescription("set a new prefix")
        .addStringOption((o) => o.setName("prefix").setDescription("new prefix (1-4 chars)").setRequired(true))
        .addStringOption((o) => o.setName("reason").setDescription("why")),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "show") {
      await i.reply({
        embeds: [
          aetherEmbed({
            description: `${emoji("aether_arrow")} prefix: \`${getPrefix(i.guild.id)}\``,
            color: COLORS.accent,
          }),
        ],
      });
      return;
    }
    if (!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await i.reply({ content: "manage server required", ephemeral: true });
      return;
    }
    const np = i.options.getString("prefix", true).slice(0, 4);
    setPrefix(i.guild.id, np);
    await i.reply({ embeds: [successEmbed(`prefix set to \`${np}\``)] });
  },
});
