import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { setupVoiceMaster, isOwner, getOwner } from "../services/voicemaster.ts";
import { successEmbed, errorEmbed, aetherEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";

register({
  category: "voicemaster",
  data: new SlashCommandBuilder()
    .setName("vm")
    .setDescription("voicemaster — temporary voice channels")
    .addSubcommand((s) =>
      s.setName("setup").setDescription("create the join-to-create voice + category"),
    )
    .addSubcommand((s) =>
      s
        .setName("name")
        .setDescription("rename your temp channel")
        .addStringOption((o) => o.setName("name").setDescription("new name").setRequired(true)),
    )
    .addSubcommand((s) =>
      s
        .setName("limit")
        .setDescription("set user limit")
        .addIntegerOption((o) => o.setName("limit").setDescription("0-99").setRequired(true).setMinValue(0).setMaxValue(99)),
    )
    .addSubcommand((s) => s.setName("lock").setDescription("lock your channel"))
    .addSubcommand((s) => s.setName("unlock").setDescription("unlock your channel"))
    .addSubcommand((s) => s.setName("hide").setDescription("hide your channel"))
    .addSubcommand((s) => s.setName("unhide").setDescription("unhide your channel"))
    .addSubcommand((s) => s.setName("claim").setDescription("claim ownership if owner left"))
    .addSubcommand((s) =>
      s
        .setName("kick")
        .setDescription("kick a user from your vc")
        .addUserOption((o) => o.setName("user").setDescription("user").setRequired(true)),
    ),
  async execute(i) {
    if (!i.guild) return;
    const sub = i.options.getSubcommand();
    if (sub === "setup") {
      if (!i.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
        await i.reply({ embeds: [errorEmbed("admin only")], ephemeral: true });
        return;
      }
      await i.deferReply();
      const cat = await i.guild.channels.create({
        name: "voice channels",
        type: ChannelType.GuildCategory,
      });
      const join = await i.guild.channels.create({
        name: "▶ join to create",
        type: ChannelType.GuildVoice,
        parent: cat.id,
      });
      setupVoiceMaster(i.guild.id, join.id, cat.id);
      await i.editReply({
        embeds: [
          successEmbed(`voicemaster ready — join <#${join.id}> to spawn your own room`),
        ],
      });
      return;
    }

    const member = await i.guild.members.fetch(i.user.id);
    const ch = member.voice.channel;
    if (!ch) {
      await i.reply({ embeds: [errorEmbed("you must be in a voice channel")], ephemeral: true });
      return;
    }
    if (sub !== "claim" && !isOwner(ch.id, i.user.id)) {
      await i.reply({ embeds: [errorEmbed("you don't own this channel")], ephemeral: true });
      return;
    }

    const everyone = i.guild.roles.everyone.id;
    if (sub === "name") {
      await ch.setName(i.options.getString("name", true)).catch(() => null);
      await i.reply({ embeds: [successEmbed(`renamed`)] });
    } else if (sub === "limit") {
      await ch.setUserLimit(i.options.getInteger("limit", true));
      await i.reply({ embeds: [successEmbed(`limit set`)] });
    } else if (sub === "lock") {
      await ch.permissionOverwrites.edit(everyone, { Connect: false });
      await i.reply({ embeds: [successEmbed("🔒 locked")] });
    } else if (sub === "unlock") {
      await ch.permissionOverwrites.edit(everyone, { Connect: null });
      await i.reply({ embeds: [successEmbed("🔓 unlocked")] });
    } else if (sub === "hide") {
      await ch.permissionOverwrites.edit(everyone, { ViewChannel: false });
      await i.reply({ embeds: [successEmbed("hidden")] });
    } else if (sub === "unhide") {
      await ch.permissionOverwrites.edit(everyone, { ViewChannel: null });
      await i.reply({ embeds: [successEmbed("visible")] });
    } else if (sub === "claim") {
      const owner = getOwner(ch.id);
      if (!owner) {
        await i.reply({ embeds: [errorEmbed("not a vm channel")], ephemeral: true });
        return;
      }
      const ownerStill = ch.members.has(owner);
      if (ownerStill) {
        await i.reply({ embeds: [errorEmbed("owner is still here")], ephemeral: true });
        return;
      }
      const { db } = await import("../db.ts");
      db.prepare("UPDATE voice_owners SET owner_id = ? WHERE channel_id = ?").run(i.user.id, ch.id);
      await i.reply({ embeds: [successEmbed("you are the new owner")] });
    } else if (sub === "kick") {
      const u = i.options.getUser("user", true);
      const m = await i.guild.members.fetch(u.id).catch(() => null);
      if (m?.voice.channelId === ch.id) {
        await m.voice.disconnect("vm kick").catch(() => null);
      }
      await i.reply({ embeds: [successEmbed(`kicked ${u}`)] });
    }
  },
});
