import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from "discord.js";
import { register } from "../commandRegistry.ts";
import { db } from "../db.ts";
import { aetherEmbed, successEmbed, errorEmbed } from "../embeds.ts";
import { COLORS } from "../config.ts";
import { emoji } from "../services/emojis.ts";

register({
  category: "utility",
  data: new SlashCommandBuilder()
    .setName("ticketsetup")
    .setDescription("dedicated wizard to configure & post the AETHER ticket panel in one shot")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) =>
      o
        .setName("category")
        .setDescription("category where new ticket channels will be created")
        .addChannelTypes(ChannelType.GuildCategory)
        .setRequired(true),
    )
    .addRoleOption((o) =>
      o.setName("staff_role").setDescription("staff role with access to tickets").setRequired(true),
    )
    .addChannelOption((o) =>
      o
        .setName("panel_channel")
        .setDescription("channel where the ticket panel will be posted")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true),
    )
    .addChannelOption((o) =>
      o
        .setName("log_channel")
        .setDescription("channel for ticket open/close logs")
        .addChannelTypes(ChannelType.GuildText),
    )
    .addStringOption((o) =>
      o.setName("title").setDescription("panel title (default: 'need help?')"),
    )
    .addStringOption((o) =>
      o.setName("prompt").setDescription("panel description text"),
    )
    .addStringOption((o) =>
      o.setName("button_label").setDescription("button label (default: 'open ticket')"),
    ),
  async execute(i) {
    if (!i.guild) return;
    const category = i.options.getChannel("category", true);
    const staff = i.options.getRole("staff_role", true);
    const panelCh = i.options.getChannel("panel_channel", true);
    const log = i.options.getChannel("log_channel");
    const title = i.options.getString("title") ?? "# need help?";
    const prompt =
      i.options.getString("prompt") ??
      [
        "> click the button below to open a private ticket",
        "",
        "**what to expect**",
        `> ${emoji("aether_ticket")} a private channel just for you & staff`,
        `> ${emoji("aether_lock")} other members can't see it`,
        `> ${emoji("aether_check")} a staff member will respond as soon as possible`,
        "",
        "**before opening**",
        "> · check `#faq` first",
        "> · only one ticket per issue please",
        "> · be respectful — staff are volunteers",
      ].join("\n");
    const buttonLabel = i.options.getString("button_label") ?? "open ticket";

    db.prepare(
      "INSERT INTO ticket_config (guild_id, panel_channel, category, staff_role, log_channel, prompt) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET panel_channel = excluded.panel_channel, category = excluded.category, staff_role = excluded.staff_role, log_channel = excluded.log_channel, prompt = excluded.prompt",
    ).run(i.guild.id, panelCh.id, category.id, staff.id, log?.id ?? null, `${title}\n${prompt}`);

    const target = await i.guild.channels.fetch(panelCh.id).catch(() => null);
    if (!target || !target.isTextBased() || !("send" in target)) {
      await i.reply({
        embeds: [errorEmbed("could not access the panel channel — check my permissions there.")],
        ephemeral: true,
      });
      return;
    }

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("ticket-open")
        .setLabel(buttonLabel)
        .setStyle(ButtonStyle.Danger)
        .setEmoji("✉"),
    );

    await target.send({
      embeds: [
        aetherEmbed({
          description: `${title}\n${prompt}`,
          color: COLORS.accent,
          footer: "AETHER · ticket system",
        }),
      ],
      components: [row],
    });

    await i.reply({
      embeds: [
        successEmbed(
          [
            `panel posted in <#${panelCh.id}>`,
            `> tickets will open under <#${category.id}>`,
            `> staff role: <@&${staff.id}>`,
            log ? `> logs: <#${log.id}>` : "> logs: *(none)*",
          ].join("\n"),
          "✓ ticket system live",
        ),
      ],
      ephemeral: true,
    });
  },
});
