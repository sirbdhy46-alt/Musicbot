// Generate themed banner GIFs for every moderation + fun action.
// Each banner is ~480x180, 12 frames, with an animated glow + label.
// They are saved to artifacts/bot/assets/banners/<name>.gif
// and to artifacts/bot/assets/emojis/ for the new loading emojis.

import sharp from "sharp";
import gifenc from "gifenc";
const { GIFEncoder, quantize, applyPalette } = gifenc;
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const assetsDir = path.resolve(__dirname, "../assets");
const bannersDir = path.join(assetsDir, "banners");
const emojiDir = path.join(assetsDir, "emojis");
fs.mkdirSync(bannersDir, { recursive: true });

const W = 480;
const H = 180;

// All actions get a banner. `name` is the file stem, `label` is the header text,
// `sub` is the small accent line, `color` is an [r,g,b] tuple for the glow.
const ACTIONS = [
  // moderation — angry reds & oranges
  { name: "ban", label: "BANISHED", sub: "removed from this realm", color: [220, 30, 30], emoji: "aether_ban" },
  { name: "hardban", label: "HARDBANNED", sub: "blocked from rejoining", color: [180, 0, 0], emoji: "aether_banhammer" },
  { name: "unban", label: "UNBANNED", sub: "the gates open again", color: [40, 200, 120], emoji: "aether_check" },
  { name: "kick", label: "KICKED", sub: "shown the door", color: [240, 130, 30], emoji: "aether_boot" },
  { name: "mute", label: "MUTED", sub: "the silence is enforced", color: [120, 110, 200], emoji: "aether_mute" },
  { name: "unmute", label: "UNMUTED", sub: "speak freely now", color: [80, 200, 160], emoji: "aether_check" },
  { name: "warn", label: "WARNED", sub: "a final caution", color: [240, 200, 40], emoji: "aether_warn" },
  { name: "unjail", label: "RELEASED", sub: "stepping back into the light", color: [60, 200, 100], emoji: "aether_unlock" },
  { name: "lock", label: "LOCKED", sub: "channel sealed shut", color: [200, 40, 80], emoji: "aether_lock" },
  { name: "unlock", label: "UNLOCKED", sub: "channel reopened", color: [60, 180, 220], emoji: "aether_unlock" },
  { name: "lockdown", label: "LOCKDOWN", sub: "every gate closed", color: [180, 30, 30], emoji: "aether_lock" },
  { name: "isolate", label: "ISOLATED", sub: "cut off completely", color: [80, 60, 180], emoji: "aether_shield" },
  { name: "nuke", label: "CHANNEL NUKED", sub: "wiped from existence", color: [240, 80, 30], emoji: "aether_alert" },
  { name: "clear", label: "CLEARED", sub: "messages purged", color: [120, 200, 220], emoji: "aether_check" },
  { name: "slowmode", label: "SLOWMODE", sub: "the pace has changed", color: [180, 140, 220], emoji: "aether_loading" },
  { name: "forcenick", label: "RENAMED", sub: "given a new name", color: [200, 160, 80], emoji: "aether_warn" },
  // fun — bright & playful
  { name: "hug", label: "HUGGED", sub: "warmth shared", color: [255, 130, 180], emoji: "aether_check" },
  { name: "slap", label: "SLAPPED", sub: "a stinging strike", color: [240, 90, 120], emoji: "aether_alert" },
  { name: "roast", label: "ROASTED", sub: "burned to a crisp", color: [240, 110, 30], emoji: "aether_alert" },
  { name: "compliment", label: "COMPLIMENTED", sub: "kind words given", color: [120, 200, 240], emoji: "aether_check" },
  { name: "ship", label: "SHIPPED", sub: "two souls measured", color: [220, 80, 200], emoji: "aether_check" },
  { name: "8ball", label: "THE 8-BALL", sub: "speaks the truth", color: [80, 80, 220], emoji: "aether_info" },
  { name: "coinflip", label: "COIN TOSS", sub: "fate decides", color: [220, 190, 60], emoji: "aether_info" },
  { name: "rps", label: "ROCK PAPER SCISSORS", sub: "a duel of wits", color: [120, 220, 180], emoji: "aether_info" },
];

function gradientSvg(rgb, label, sub) {
  const [r, g, b] = rgb;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%"  stop-color="rgb(12,12,16)" />
        <stop offset="100%" stop-color="rgb(${Math.floor(r * 0.18)},${Math.floor(g * 0.18)},${Math.floor(b * 0.18)})" />
      </linearGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="2.4" /></filter>
    </defs>
    <rect width="${W}" height="${H}" fill="url(#bg)" />
    <rect x="6" y="6" width="${W - 12}" height="${H - 12}" fill="none" stroke="rgb(${r},${g},${b})" stroke-opacity="0.45" stroke-width="1.5" />
    <text x="${W / 2}" y="${H / 2 - 6}" text-anchor="middle"
          font-family="Impact, 'Arial Black', sans-serif"
          font-size="56" font-weight="900" fill="rgb(${r},${g},${b})"
          filter="url(#glow)">${escapeXml(label)}</text>
    <text x="${W / 2}" y="${H / 2 - 6}" text-anchor="middle"
          font-family="Impact, 'Arial Black', sans-serif"
          font-size="56" font-weight="900" fill="white" fill-opacity="0.95">${escapeXml(label)}</text>
    <text x="${W / 2}" y="${H / 2 + 30}" text-anchor="middle"
          font-family="'Helvetica', sans-serif" letter-spacing="3"
          font-size="13" fill="rgb(220,220,230)">${escapeXml(sub.toUpperCase())}</text>
    <text x="${W - 14}" y="${H - 14}" text-anchor="end"
          font-family="'Helvetica', sans-serif" letter-spacing="2"
          font-size="10" fill="rgb(160,160,180)" fill-opacity="0.7">AETHER</text>
  </svg>`;
}

function escapeXml(s) {
  return String(s).replace(/[<>&'"]/g, (c) => ({
    "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;",
  }[c]));
}

async function buildBanner(action) {
  // Render the static panel once
  const svg = gradientSvg(action.color, action.label, action.sub);
  const baseRaw = await sharp(Buffer.from(svg)).removeAlpha().raw().toBuffer();

  const enc = GIFEncoder();
  const totalFrames = 12;
  for (let f = 0; f < totalFrames; f++) {
    const t = f / totalFrames;
    const pulse = 0.5 + 0.5 * Math.sin(t * Math.PI * 2);
    const rgba = new Uint8Array(W * H * 4);
    for (let i = 0, j = 0; i < baseRaw.length; i += 3, j += 4) {
      const r = baseRaw[i],
        g = baseRaw[i + 1],
        b = baseRaw[i + 2];
      // Add a very subtle warm pulse keyed to the action's color
      rgba[j] = Math.min(255, r + action.color[0] * 0.06 * pulse);
      rgba[j + 1] = Math.min(255, g + action.color[1] * 0.06 * pulse);
      rgba[j + 2] = Math.min(255, b + action.color[2] * 0.06 * pulse);
      rgba[j + 3] = 255;
    }
    const palette = quantize(rgba, 64);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, W, H, { palette, delay: 110 });
  }
  enc.finish();
  const out = path.join(bannersDir, `${action.name}.gif`);
  fs.writeFileSync(out, Buffer.from(enc.bytes()));
  return { name: action.name, size: fs.statSync(out).size };
}

// ---- LOADING BAR (large attachment) -------------------------------------
async function buildLoadingBar() {
  const BW = 420;
  const BH = 60;
  const enc = GIFEncoder();
  const totalFrames = 24;
  for (let f = 0; f < totalFrames; f++) {
    const pct = ((f + 1) / totalFrames) * 100;
    const fillW = Math.floor((BW - 30) * (pct / 100));
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${BW}" height="${BH}">
      <rect width="${BW}" height="${BH}" fill="rgb(10,10,14)" />
      <rect x="14" y="20" width="${BW - 28}" height="20" fill="rgb(28,28,36)" stroke="rgb(80,80,100)" stroke-width="1" />
      <rect x="15" y="21" width="${fillW}" height="18" fill="rgb(180,40,80)" />
      <rect x="15" y="21" width="${fillW}" height="9" fill="rgb(255,90,140)" fill-opacity="0.5" />
      <text x="${BW / 2}" y="14" text-anchor="middle" font-family="Helvetica" font-size="9" letter-spacing="2" fill="rgb(220,220,230)">AETHER · LOADING</text>
      <text x="${BW / 2}" y="55" text-anchor="middle" font-family="Helvetica" font-size="10" font-weight="bold" fill="rgb(255,140,180)">${Math.floor(pct)}%</text>
    </svg>`;
    const rgb = await sharp(Buffer.from(svg)).removeAlpha().raw().toBuffer();
    const rgba = new Uint8Array(BW * BH * 4);
    for (let i = 0, j = 0; i < rgb.length; i += 3, j += 4) {
      rgba[j] = rgb[i]; rgba[j + 1] = rgb[i + 1]; rgba[j + 2] = rgb[i + 2]; rgba[j + 3] = 255;
    }
    const palette = quantize(rgba, 32);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, BW, BH, { palette, delay: 80 });
  }
  enc.finish();
  const out = path.join(assetsDir, "loading_bar.gif");
  fs.writeFileSync(out, Buffer.from(enc.bytes()));
  console.log(`✓ loading_bar.gif ${fs.statSync(out).size} bytes`);
}

// ---- EXTRA ANIMATED LOADING EMOJIS (96x96) -------------------------------
async function buildLoadingEmojis() {
  const SIZE = 96;

  // aether_dots — three pulsing dots (typing indicator style)
  {
    const enc = GIFEncoder();
    const total = 12;
    for (let f = 0; f < total; f++) {
      const phase = (f / total) * Math.PI * 2;
      const a = (i) => 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(phase - i * 0.7));
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${SIZE}" height="${SIZE}">
        <rect width="${SIZE}" height="${SIZE}" fill="rgb(8,8,12)" />
        <circle cx="24" cy="48" r="10" fill="rgb(255,255,255)" fill-opacity="${a(0).toFixed(2)}" />
        <circle cx="48" cy="48" r="10" fill="rgb(255,255,255)" fill-opacity="${a(1).toFixed(2)}" />
        <circle cx="72" cy="48" r="10" fill="rgb(255,255,255)" fill-opacity="${a(2).toFixed(2)}" />
      </svg>`;
      const rgb = await sharp(Buffer.from(svg)).removeAlpha().raw().toBuffer();
      const rgba = new Uint8Array(SIZE * SIZE * 4);
      for (let i = 0, j = 0; i < rgb.length; i += 3, j += 4) { rgba[j] = rgb[i]; rgba[j+1] = rgb[i+1]; rgba[j+2] = rgb[i+2]; rgba[j+3] = 255; }
      const palette = quantize(rgba, 16);
      enc.writeFrame(applyPalette(rgba, palette), SIZE, SIZE, { palette, delay: 100 });
    }
    enc.finish();
    fs.writeFileSync(path.join(emojiDir, "aether_dots.gif"), Buffer.from(enc.bytes()));
  }

  // aether_pulse — single ring pulsing outward
  {
    const enc = GIFEncoder();
    const total = 12;
    for (let f = 0; f < total; f++) {
      const t = f / total;
      const r = 12 + t * 30;
      const opacity = (1 - t).toFixed(2);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${SIZE}" height="${SIZE}">
        <rect width="${SIZE}" height="${SIZE}" fill="rgb(8,8,12)" />
        <circle cx="${SIZE/2}" cy="${SIZE/2}" r="${r}" fill="none" stroke="rgb(255,80,140)" stroke-width="3" stroke-opacity="${opacity}" />
        <circle cx="${SIZE/2}" cy="${SIZE/2}" r="8" fill="rgb(255,80,140)" />
      </svg>`;
      const rgb = await sharp(Buffer.from(svg)).removeAlpha().raw().toBuffer();
      const rgba = new Uint8Array(SIZE * SIZE * 4);
      for (let i = 0, j = 0; i < rgb.length; i += 3, j += 4) { rgba[j] = rgb[i]; rgba[j+1] = rgb[i+1]; rgba[j+2] = rgb[i+2]; rgba[j+3] = 255; }
      const palette = quantize(rgba, 16);
      enc.writeFrame(applyPalette(rgba, palette), SIZE, SIZE, { palette, delay: 90 });
    }
    enc.finish();
    fs.writeFileSync(path.join(emojiDir, "aether_pulse.gif"), Buffer.from(enc.bytes()));
  }

  // aether_loadbar — tiny inline progress bar 96x96 (bar fills 0->100%)
  {
    const enc = GIFEncoder();
    const total = 16;
    for (let f = 0; f < total; f++) {
      const pct = ((f + 1) / total);
      const fillW = Math.floor(70 * pct);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${SIZE}" height="${SIZE}">
        <rect width="${SIZE}" height="${SIZE}" fill="rgb(8,8,12)" />
        <rect x="13" y="40" width="70" height="16" fill="rgb(28,28,36)" stroke="rgb(80,80,100)" stroke-width="1.5" />
        <rect x="14" y="41" width="${fillW}" height="14" fill="rgb(180,40,80)" />
        <rect x="14" y="41" width="${fillW}" height="6" fill="rgb(255,120,160)" fill-opacity="0.6" />
      </svg>`;
      const rgb = await sharp(Buffer.from(svg)).removeAlpha().raw().toBuffer();
      const rgba = new Uint8Array(SIZE * SIZE * 4);
      for (let i = 0, j = 0; i < rgb.length; i += 3, j += 4) { rgba[j] = rgb[i]; rgba[j+1] = rgb[i+1]; rgba[j+2] = rgb[i+2]; rgba[j+3] = 255; }
      const palette = quantize(rgba, 16);
      enc.writeFrame(applyPalette(rgba, palette), SIZE, SIZE, { palette, delay: 90 });
    }
    enc.finish();
    fs.writeFileSync(path.join(emojiDir, "aether_loadbar.gif"), Buffer.from(enc.bytes()));
  }

  // aether_skull_pulse — for ban actions
  {
    const skullPath = path.join(emojiDir, "aether_banhammer.png");
    const base = await sharp(skullPath).resize(SIZE, SIZE, { fit: "cover" }).removeAlpha().raw().toBuffer();
    const enc = GIFEncoder();
    const total = 14;
    for (let f = 0; f < total; f++) {
      const t = f / total;
      const pulse = 0.5 + 0.5 * Math.sin(t * Math.PI * 2);
      const rgba = new Uint8Array(SIZE * SIZE * 4);
      for (let i = 0, j = 0; i < base.length; i += 3, j += 4) {
        rgba[j] = Math.min(255, base[i] + 80 * pulse);
        rgba[j + 1] = Math.max(0, base[i + 1] - 20 * pulse);
        rgba[j + 2] = Math.max(0, base[i + 2] - 20 * pulse);
        rgba[j + 3] = 255;
      }
      const palette = quantize(rgba, 32);
      enc.writeFrame(applyPalette(rgba, palette), SIZE, SIZE, { palette, delay: 100 });
    }
    enc.finish();
    fs.writeFileSync(path.join(emojiDir, "aether_skull_pulse.gif"), Buffer.from(enc.bytes()));
  }

  console.log("✓ extra animated emojis: aether_dots, aether_pulse, aether_loadbar, aether_skull_pulse");
}

// ---- MAIN ----------------------------------------------------------------
console.log("✦ generating action banners...");
for (const a of ACTIONS) {
  const r = await buildBanner(a);
  console.log(`  ✓ ${r.name}.gif ${(r.size / 1024).toFixed(1)}KB`);
}

console.log("\n✦ generating loading bar...");
await buildLoadingBar();

console.log("\n✦ generating extra animated loading emojis...");
await buildLoadingEmojis();

console.log("\nfinal banners directory:");
for (const f of fs.readdirSync(bannersDir).sort()) {
  console.log(`  ${f} ${fs.statSync(path.join(bannersDir, f)).size}`);
}
