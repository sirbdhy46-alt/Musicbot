import sharp from "sharp";
import gifenc from "gifenc";
const { GIFEncoder, quantize, applyPalette } = gifenc;
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.resolve(__dirname, "../assets");
const emojiOut = path.join(outDir, "emojis");

async function buildWelcomeBanner() {
  const W = 480,
    H = 220;
  const base = await sharp(path.join(outDir, "welcome_banner.png"))
    .resize(W, H, { fit: "cover" })
    .removeAlpha()
    .raw()
    .toBuffer();

  const enc = GIFEncoder();
  const totalFrames = 16;
  for (let f = 0; f < totalFrames; f++) {
    const t = f / totalFrames;
    const pulse = 0.15 + 0.3 * (0.5 + 0.5 * Math.sin(t * Math.PI * 2));
    const rgba = new Uint8Array(W * H * 4);
    for (let i = 0, j = 0; i < base.length; i += 3, j += 4) {
      const r = base[i],
        g = base[i + 1],
        b = base[i + 2];
      rgba[j] = Math.min(255, r + 70 * pulse);
      rgba[j + 1] = Math.max(0, g - 35 * pulse);
      rgba[j + 2] = Math.max(0, b - 35 * pulse);
      rgba[j + 3] = 255;
    }
    const palette = quantize(rgba, 64);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, W, H, { palette, delay: 100 });
  }
  enc.finish();
  fs.writeFileSync(path.join(outDir, "jail_welcome.gif"), Buffer.from(enc.bytes()));
  console.log("✓ jail_welcome.gif", fs.statSync(path.join(outDir, "jail_welcome.gif")).size, "bytes");
}

async function buildSpinEmoji(srcName, outName, frames = 16) {
  const W = 96,
    H = 96;
  const enc = GIFEncoder();
  for (let f = 0; f < frames; f++) {
    const angle = (360 * f) / frames;
    const rotated = await sharp(path.join(emojiOut, srcName))
      .resize(W, H, { fit: "cover" })
      .rotate(angle, { background: { r: 0, g: 0, b: 0, alpha: 1 } })
      .resize(W, H, { fit: "cover" })
      .removeAlpha()
      .raw()
      .toBuffer();
    const rgba = new Uint8Array(W * H * 4);
    for (let i = 0, j = 0; i < rotated.length; i += 3, j += 4) {
      rgba[j] = rotated[i];
      rgba[j + 1] = rotated[i + 1];
      rgba[j + 2] = rotated[i + 2];
      rgba[j + 3] = 255;
    }
    const palette = quantize(rgba, 256);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, W, H, { palette, delay: 60 });
  }
  enc.finish();
  fs.writeFileSync(path.join(emojiOut, outName), Buffer.from(enc.bytes()));
  console.log("✓", outName, fs.statSync(path.join(emojiOut, outName)).size, "bytes");
}

async function buildPulseEmoji(srcName, outName, frames = 16) {
  const W = 96,
    H = 96;
  const enc = GIFEncoder();
  for (let f = 0; f < frames; f++) {
    const t = f / frames;
    const scale = 0.78 + 0.18 * (0.5 + 0.5 * Math.sin(t * Math.PI * 2));
    const inner = Math.max(2, Math.round(W * scale));
    const top = Math.floor((H - inner) / 2);
    const bottom = H - inner - top;
    const left = Math.floor((W - inner) / 2);
    const right = W - inner - left;
    const buf = await sharp(path.join(emojiOut, srcName))
      .resize(inner, inner, { fit: "cover" })
      .extend({
        top,
        bottom,
        left,
        right,
        background: { r: 0, g: 0, b: 0, alpha: 1 },
      })
      .removeAlpha()
      .raw()
      .toBuffer();
    const rgba = new Uint8Array(W * H * 4);
    for (let i = 0, j = 0; i < buf.length; i += 3, j += 4) {
      rgba[j] = buf[i];
      rgba[j + 1] = buf[i + 1];
      rgba[j + 2] = buf[i + 2];
      rgba[j + 3] = 255;
    }
    const palette = quantize(rgba, 256);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, W, H, { palette, delay: 80 });
  }
  enc.finish();
  fs.writeFileSync(path.join(emojiOut, outName), Buffer.from(enc.bytes()));
  console.log("✓", outName, fs.statSync(path.join(emojiOut, outName)).size, "bytes");
}

async function buildHueEmoji(srcName, outName, frames = 12) {
  const W = 96,
    H = 96;
  const enc = GIFEncoder();
  for (let f = 0; f < frames; f++) {
    const hue = (360 * f) / frames;
    const buf = await sharp(path.join(emojiOut, srcName))
      .resize(W, H, { fit: "cover" })
      .modulate({ hue })
      .removeAlpha()
      .raw()
      .toBuffer();
    const rgba = new Uint8Array(W * H * 4);
    for (let i = 0, j = 0; i < buf.length; i += 3, j += 4) {
      rgba[j] = buf[i];
      rgba[j + 1] = buf[i + 1];
      rgba[j + 2] = buf[i + 2];
      rgba[j + 3] = 255;
    }
    const palette = quantize(rgba, 256);
    const indexed = applyPalette(rgba, palette);
    enc.writeFrame(indexed, W, H, { palette, delay: 90 });
  }
  enc.finish();
  fs.writeFileSync(path.join(emojiOut, outName), Buffer.from(enc.bytes()));
  console.log("✓", outName, fs.statSync(path.join(emojiOut, outName)).size, "bytes");
}

await buildWelcomeBanner();
await buildSpinEmoji("aether_loading.png", "aether_loading_spin.gif");
await buildPulseEmoji("aether_alert.png", "aether_alert_pulse.gif");
await buildHueEmoji("aether_logo.png", "aether_logo_glow.gif");
await buildHueEmoji("aether_avatar.png", "aether_avatar_glow.gif");

console.log("\nFinal emoji directory:");
for (const f of fs.readdirSync(emojiOut).sort()) {
  console.log(" ", f, fs.statSync(path.join(emojiOut, f)).size);
}
